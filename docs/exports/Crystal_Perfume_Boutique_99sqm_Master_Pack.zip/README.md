# Crystal & Perfume Boutique - REV.03

Contest #2801401. Current delivery: bright native Blender 5.1.1 Cycles views, exact-camera clay/Freestyle proofs, paint-only wall specification and editable CAD / Blender sources.

Open `index.html` for the local presentation, `review/previews/board1_cycles_gallery_views_preview_1200x900.jpg` for the cover, or `exports/Crystal_Perfume_Boutique_99sqm_Master_Pack.zip` for the complete current pack. `docs/` contains the matching static web mirror and [REV.03 build/provenance notes](docs/REV03.md).

- Six 1920 x 1200 Blender images: gallery, VIP lounge, two same-camera proofs, vitrine close-up, cutaway.
- Four 3200 x 2400 JPEG boards in `deliverables/`, four 1200 x 900 previews, and a four-page A3 PDF.
- OC-17 White Dove / OC-85 Pale Oak matte paint, roughness 0.85. Four CAD-footprint structural columns. No stone or wood wall cladding.
- `exports/render_manifest.json` records version, cameras, evaluated geometry and file hashes. Composition rejects changed render files.
- AI image generation is not used for the interior renders. Client-supplied product references are labelled separately, with their original source marks retained.

The source label is 99.27 sqm; CAD coordinates yield 98.43105 sqm excluding the existing service core. Perspective and CAD fit-out models retain separate ceiling/furniture assumptions, detailed in the revision notes. No construction-readiness or manual-only-authorship claim is made.

Build: `scripts/build_blender_boutique.py` + `scripts/render_blender.py`; CAD axonometric: `scripts/render_cad_axonometric.py`; boards/web/package: `scripts/compose_boards.py`. Current source geometry: `layout_geometry.json` (millimetres). Use the exact rebuild commands in the revision notes.
