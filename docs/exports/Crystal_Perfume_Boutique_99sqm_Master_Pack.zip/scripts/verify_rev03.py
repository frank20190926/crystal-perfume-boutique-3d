"""Verify REV.03 handover bytes, camera pairs, packaging and local web mirrors."""
from pathlib import Path
import hashlib,json,zipfile
from PIL import Image
from pypdf import PdfReader
ROOT=Path(__file__).resolve().parents[1]
manifest=json.loads((ROOT/'exports/render_manifest.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert manifest['blender_version']=='5.1.1'
assert len(manifest['renders'])==6
assert sha(ROOT/manifest['native_blend'])==manifest['native_blend_sha256']
for script,h in manifest['scripts'].items():assert sha(ROOT/script)==h,script
stats=[]
for r in manifest['renders']:
 p=ROOT/r['file'];assert sha(p)==r['sha256'],p
 with Image.open(p) as im:
  assert im.size==(1920,1200),(p,im.size)
  # Brightness is measured, not used as a substitute for visual review.
  gray=im.convert('L');hist=gray.histogram();total=sum(hist)
  stats.append(dict(file=r['file'],mean_luminance=round(sum(i*n for i,n in enumerate(hist))/total,2),dark_fraction=round(sum(hist[:40])/total,5)))
for i in [1,2]:
 pair=[r for r in manifest['renders'] if r['view']==i]
 assert len(pair)==2 and pair[0]['camera']==pair[1]['camera'] and pair[0]['geometry']==pair[1]['geometry']
boards=['board1_cycles_gallery_views','board2_floorplan_axon','board3_elevations_paint_spec','board4_vip_blender_proof']
for b in boards:
 p=ROOT/'deliverables'/f'{b}.jpg'
 assert Image.open(p).size==(3200,2400)
 assert Image.open(ROOT/'review/previews'/f'{b}_preview_1200x900.jpg').size==(1200,900)
 assert sha(p)==sha(ROOT/f'{b}.jpg')==sha(ROOT/'docs/deliverables'/f'{b}.jpg')
pdf=ROOT/'exports/Crystal_Perfume_Boutique_99sqm_Submission_A3.pdf';reader=PdfReader(pdf)
assert len(reader.pages)==4
for page in reader.pages:
 assert abs(float(page.mediabox.width)-1190.64)<1 and abs(float(page.mediabox.height)-841.92)<1
zp=ROOT/'exports/Crystal_Perfume_Boutique_99sqm_Master_Pack.zip'
with zipfile.ZipFile(zp) as z:
 assert z.testzip() is None
 names=z.namelist();assert len(names)==len(set(names))
 for name in names:
  assert z.read(name)==(ROOT/name).read_bytes(),name
 assert all('rev03_before' not in n and '__pycache__' not in n for n in names)
 for r in manifest['renders']:assert r['file'] in names
 for n in ['scripts/build_blender_boutique.py','scripts/render_blender.py','docs/REV03.md','exports/render_manifest.json']:assert n in names,n
 for n in ['IMG_4951.PNG','895d2c32-dca2-4d5e-adaa-f6e12dcbcde4.JPG','Gemini_Generated_Image_h21hyah21hyah21h.png','Gemini_Generated_Image_ck9sdbck9sdbck9s.jpg','Gemini_Generated_Image_SQUARE.png']:
  assert 'brief/'+n in names,n
for p in (ROOT/'docs').rglob('*'):
 if p.is_file() and p.name not in ['REV03.md','.nojekyll']:
  original=ROOT/p.relative_to(ROOT/'docs');assert original.exists() and sha(original)==sha(p),p
report=dict(status='pass',render_count=6,same_camera_pairs=2,board_count=4,pdf_pages=4,zip_members=len(names),render_luminance=stats)
(ROOT/'review/rev03_delivery_validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
