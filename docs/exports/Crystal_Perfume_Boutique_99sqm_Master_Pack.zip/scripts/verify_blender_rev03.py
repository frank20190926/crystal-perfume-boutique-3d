"""Run in a fresh Blender process against the saved native perspective scene."""
import bpy,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
m=json.loads((ROOT/'exports/render_manifest.json').read_text())
assert bpy.app.version_string=='5.1.1'
s=bpy.context.scene
assert s['revision']=='REV.03' and not s.render.use_freestyle
for r in m['renders']:
 if r['pass_type']!='CYCLES':continue
 c=bpy.data.objects[r['camera']['name']]
 assert [list(row) for row in c.matrix_world]==r['camera']['matrix_world']
 for attr,key in [('lens','lens_mm'),('sensor_width','sensor_width_mm'),('shift_x','shift_x'),('shift_y','shift_y')]:
  assert getattr(c.data,attr)==r['camera'][key]
for o in m['paint_audit']['painted_architecture']:
 ob=bpy.data.objects[o['name']]
 assert [a.name for a in ob.data.materials]==o['materials']
 for a in ob.data.materials:
  assert abs(a.node_tree.nodes['Principled BSDF'].inputs['Roughness'].default_value-.85)<1e-6
  assert not any(n.type=='TEX_IMAGE' for n in a.node_tree.nodes)
for i in range(1,5):assert bpy.data.objects.get(f'COL-{i:02d}')
assert not bpy.data.collections['02_ARCH_Ceiling'].hide_render
print('REV03 NATIVE REOPEN PASS: Blender 5.1.1, 3 cameras, 4 columns, paint materials, full ceiling')
