#!/usr/local/bin/python3.11
"""Compose BT-01..BT-04 A3 presentation boards (3200x2400 JPEG @95), multi-page PDF,
Master Pack ZIP, index.html and 1200px previews for crystal-perfume-boutique.

Design Read: A3 architectural competition board (Henning Larsen / Foster style) —
warm paper, 1.5px ink perimeter, hairline grid, ISO title block, no web components.
Every number is read from layout_geometry.json / exports/*.json; nothing is hand-typed
except client-supplied specification values (paint codes, LRV, glass, lighting)."""
import io
import json
import subprocess
import sys
import shutil
import hashlib
import zipfile
from decimal import Decimal, ROUND_HALF_UP
from html import escape
from pathlib import Path

from PIL import Image, ImageDraw
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent.parent
A, B, X = ROOT / "assets", ROOT / "brief", ROOT / "exports"
CROPS = A / "board_crops"
GEO = json.loads((ROOT / "layout_geometry.json").read_text())
VER = json.loads((X / "verification.json").read_text())
CADV = json.loads((X / "cad_validation.json").read_text())
BLV = json.loads((X / "blender_validation.json").read_text())
DWGV = json.loads((X / "dwg_validation.json").read_text())

PAPER, INK, RULE, INK2, TINT = "#FFFFFF", "#1E1D1A", "#C8C2B8", "#5A564E", "#EFEBE3"
PROJECT = "LUXURY CRYSTAL &amp; PERFUME BOUTIQUE (99.27 SQM)"
BOARDS = [
    ("BT-01", "board1_cycles_gallery_views", "BRIGHT MATTE-PAINT INTERIORS / NATIVE CYCLES + SAME-CAMERA MESH"),
    ("BT-02", "board2_floorplan_axon", "ARCHITECTURAL FLOOR PLAN, 3D AXONOMETRIC &amp; 5-ZONE SPATIAL SCHEDULE"),
    ("BT-03", "board3_elevations_paint_spec", "INTERIOR WALL ELEVATIONS, VITRINE SECTION &amp; MATTE PAINT SPECIFICATION"),
    ("BT-04", "board4_vip_blender_proof", "VITRINE DETAIL / CUTAWAY / NATIVE BLENDER 5.1.1 PROVENANCE"),
]

# ---------------------------------------------------------------- image prep
def prep_images():
    # Preserve full client reference images, including any original source marks.
    CROPS.mkdir(exist_ok=True)
    out = {}
    sources = [
        ("895d2c32-dca2-4d5e-adaa-f6e12dcbcde4.JPG", "ph_flacons.jpg"),
        ("Gemini_Generated_Image_h21hyah21hyah21h.png", "ph_attar.jpg"),
        ("Gemini_Generated_Image_ck9sdbck9sdbck9s.jpg", "ph_coffret_a.jpg"),
        ("Gemini_Generated_Image_SQUARE.png", "ph_coffret_b.jpg"),
    ]
    for source, name in sources:
        image = Image.open(B / source).convert("RGB")
        image.thumbnail((900, 900), Image.Resampling.LANCZOS)
        image.save(CROPS / name, quality=95)
        out[name] = "assets/board_crops/" + name
    shutil.copy2(A / "cad_elevations_vitrines.png", CROPS / "elev_clean.png")
    out["elev_clean.png"] = "assets/board_crops/elev_clean.png"
    return out

# ---------------------------------------------------------------- shared css/shell
CSS = f"""
@font-face {{ font-family:"Space Grotesk"; src:url("assets/fonts/SpaceGrotesk-600.ttf"); font-weight:600; }}
@font-face {{ font-family:"IBM Plex Sans"; src:url("assets/fonts/IBMPlexSans-400.ttf"); font-weight:400; }}
@font-face {{ font-family:"IBM Plex Sans"; src:url("assets/fonts/IBMPlexSans-600.ttf"); font-weight:600; }}
@font-face {{ font-family:"JetBrains Mono"; src:url("assets/fonts/JetBrainsMono-400.ttf"); font-weight:400; }}
:root {{ --ink:{INK}; --ink2:{INK2}; --rule:{RULE}; --tint:{TINT}; --paper:{PAPER}; }}
* {{ box-sizing:border-box; margin:0; padding:0; }}
html,body {{ width:1600px; height:1200px; background:var(--paper); }}
body {{ font-family:"IBM Plex Sans",sans-serif; color:var(--ink); font-size:11px; line-height:1.4; }}
.sheet {{ position:absolute; inset:16px; border:1.5px solid var(--ink); display:grid; grid-template-rows:50px 1fr 58px; overflow:hidden; }}
.mono,td.n,.num {{ font-family:"JetBrains Mono",monospace; font-variant-numeric:tabular-nums; }}
.disp {{ font-family:"Space Grotesk",sans-serif; font-weight:600; letter-spacing:-0.02em; }}
.head {{ display:flex; align-items:baseline; gap:18px; padding:12px 22px 8px; border-bottom:1px solid var(--ink); }}
.head .id {{ font-size:28px; line-height:1; }}
.head .title {{ font-size:17px; line-height:1.1; }}
.head .sub {{ margin-left:auto; color:var(--ink2); font-size:10.5px; letter-spacing:.05em; text-transform:uppercase; }}
.main {{ min-height:0; min-width:0; position:relative; }}
.lbl {{ display:flex; align-items:baseline; gap:10px; padding-bottom:5px; border-bottom:1px solid var(--rule); margin-bottom:8px; }}
.lbl .tag,.lbl .t {{ font-family:"Space Grotesk",sans-serif; font-weight:600; font-size:11.5px; letter-spacing:.04em; text-transform:uppercase; }}
.lbl .r {{ margin-left:auto; color:var(--ink2); font-size:10px; }}
.frame {{ border:1px solid var(--ink); line-height:0; }}
.frame img {{ width:100%; display:block; }}
.mul {{ mix-blend-mode:multiply; }}
table {{ width:100%; border-collapse:collapse; }}
th {{ font-family:"Space Grotesk",sans-serif; font-weight:600; font-size:9.5px; letter-spacing:.08em; text-transform:uppercase; color:var(--ink2); text-align:left; padding:4px 6px; background:var(--tint); border-top:1px solid var(--ink); border-bottom:1px solid var(--ink); }}
th.n,td.n {{ text-align:right; }}
td {{ padding:3.5px 6px; border-bottom:1px solid var(--rule); font-size:10.5px; line-height:1.3; vertical-align:top; }}
td.tag {{ font-family:"JetBrains Mono",monospace; font-size:10px; white-space:nowrap; }}
td.n {{ font-size:10.5px; white-space:nowrap; }}
tr.tot td {{ border-top:1px solid var(--ink); border-bottom:1px solid var(--ink); background:var(--tint); font-weight:600; }}
.note {{ color:var(--ink2); font-size:10px; line-height:1.35; }}
.tb {{ display:grid; border-top:1px solid var(--ink); grid-template-columns:2.7fr 1.1fr 1.2fr .8fr 2.1fr .9fr; }}
.tb>div {{ padding:6px 12px; border-left:1px solid var(--ink); display:flex; flex-direction:column; justify-content:center; }}
.tb>div:first-child {{ border-left:0; }}
.tb .k {{ font-size:8.5px; letter-spacing:.1em; color:var(--ink2); text-transform:uppercase; }}
.tb .v {{ font-family:"Space Grotesk",sans-serif; font-weight:600; font-size:11.5px; margin-top:2px; }}
.tb .sheetno {{ font-size:22px; line-height:1; letter-spacing:-.03em; }}
.cols {{ position:absolute; inset:0; display:grid; }}
.col {{ padding:14px 18px 12px; min-height:0; min-width:0; }}
.col+.col {{ border-left:1px solid var(--ink); }}
.rowb {{ border-top:1px solid var(--ink); }}
p+p {{ margin-top:5px; }}
"""


def shell(bt, title, body, extra_css=""):
    return f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><title>{bt}</title>
<style>{CSS}{extra_css}</style></head><body><div class="sheet">
<div class="head"><span class="id disp">{bt}</span><span class="title disp">{title}</span>
<span class="sub">REV.03 &middot; Contest #2801401 &middot; Units mm</span></div>
<div class="main">{body}</div>
<div class="tb">
<div><span class="k">Project</span><span class="v">{PROJECT}</span></div>
<div><span class="k">Contest</span><span class="v mono">#2801401</span></div>
<div><span class="k">Scale</span><span class="v">AS SHOWN (GRAPHIC BAR)</span></div>
<div><span class="k">Units</span><span class="v">MM</span></div>
<div><span class="k">Software</span><span class="v">DWG / DXF + BLENDER 5.1.1 CYCLES</span></div>
<div><span class="k">Sheet</span><span class="v sheetno disp">{bt} <span style="font-size:11px;letter-spacing:0">/ 04 · REV.03</span></span></div>
</div></div></body></html>"""

# ---------------------------------------------------------------- data tables
def fx(kind):
    return [f for f in GEO["fixture_schedule"] if f["kind"] == kind]

def dims(f, swap=False):
    x, y, z = f["length_x_mm"], f["length_y_mm"], f["height_mm"]
    # drawing convention: width along wall first (vitrines/shelves are rotated in plan)
    if f["kind"] in ("vitrine", "open_shelf"):
        x, y = y, x
    return f"{x:,} × {y:,} × {z:,}"

def zone_rows():
    names = {"01": "RECEPTION & OLFACTORY DISCOVERY", "02": "MAIN CRYSTAL & PERFUME GALLERY",
             "03": "VIP LOUNGE & HOSPITALITY SALON", "04": "PRIVATE MANAGEMENT OFFICE",
             "05": "HIDDEN STOCK & PACKAGING STORE"}
    hu = lambda v: str(Decimal(str(v)).quantize(Decimal("0.01"), ROUND_HALF_UP))
    rows = "".join(f'<tr><td class="tag">{z["id"]}</td><td>{names[z["id"]]}</td><td class="n">{hu(z["area_m2"])}</td></tr>' for z in GEO["zones"])
    ar = GEO["area_reconciliation"]
    rows += f'<tr><td class="tag">EX</td><td>EXISTING SERVICE CORE (PANTRY / WC / SHAFT)</td><td class="n">{ar["service_core_m2"]:.2f}</td></tr>'
    rows += f'<tr class="tot"><td class="tag">Σ</td><td>COORDINATE ENVELOPE (5 ZONES + CORE)</td><td class="n">{ar["coordinate_envelope_m2"]:.2f}</td></tr>'
    return rows, ar

def fixture_rows():
    r = []
    def row(tag, item, qty, dm, fin):
        r.append(f'<tr><td class="tag">{tag}</td><td>{item}</td><td class="n">{qty}</td><td class="n">{dm}</td><td class="tag">{fin}</td></tr>')
    vit = fx("vitrine"); ped = fx("pedestal"); ope = fx("open_shelf"); stk = fx("rack")
    row("V-01..04", "Lockable low-iron glass vitrine", 4, dims(vit[0]), "MET-01")
    row("V-05..06", "Lockable low-iron glass vitrine", 2, dims(vit[4]), "MET-01")
    row("P-01..03", "Feature crystal pedestal", len(ped), dims(ped[0]), "MET-01")
    row("O-01..04", "Open tactile shelving unit", len(ope), dims(ope[0]), "OC-17")
    i = fx("discovery")[0]; c = fx("reception")[0]
    row("I-01", "Olfactory discovery island", 1, dims(i), "OC-85")
    row("R-01", "Cash / wrap console", 1, dims(c), "OC-85")
    row("T-01..04", "Discovery stools", len(fx("stool")), dims(fx("stool")[0]), "OC-17")
    sofa = next(f for f in GEO["fixture_schedule"] if f["id"] == "VIP-SOFA")
    row("VIP", "Salon suite: sofa, 2 armchairs, table, credenza, rug", "1 set", f"sofa {dims(sofa)}", "OC-17/85")
    desk = next(f for f in GEO["fixture_schedule"] if f["id"] == "OF-D")
    row("OF", "Office suite: desk, credenza, task + 2 visitor chairs", "1 set", f"desk {dims(desk)}", "OC-17/85")
    row("S-01..03", "Stock racks (+ PKG-01 packing table)", len(stk) - 1, "3,500 / 2,600 × 450 × 2,200", "OC-17")
    return "".join(r)

# ---------------------------------------------------------------- BT-01
def bt01(im):
    zr, ar = zone_rows()
    css = """.cols{grid-template-columns:52fr 48fr}.plan{display:flex;justify-content:center}.plan img{height:963px}
    .axo{height:468px;display:flex;justify-content:center}.axo img{height:100%}"""
    return css, f"""<div class="cols">
<div class="col"><div class="lbl"><span class="tag">01</span><span class="t">2D CAD floor plan, 5 zones, fixture tags, doors, dimensions</span><span class="r">North up &middot; graphic scale bar</span></div>
<div class="plan"><img class="mul" src="assets/cad_floorplan_99sqm.png" alt="floor plan"></div></div>
<div class="col"><div class="lbl"><span class="tag">02</span><span class="t">Orthographic 3D cutaway axonometric</span><span class="r">Same coordinates as plan 01 &middot; sun alt. 35°</span></div>
<div class="axo"><img class="mul" src="assets/cad_3d_axonometric.png" alt="axonometric"></div>
<div class="lbl" style="margin-top:6px"><span class="tag">03</span><span class="t">Area reconciliation &amp; fixture schedule</span><span class="r">Areas: coordinate footprint, m²</span></div>
<table><tr><th style="width:38px">Zone</th><th>Description</th><th class="n" style="width:60px">m²</th></tr>{zr}
<tr><td class="tag">LBL</td><td>SOURCE RASTER LABEL (NOT NORMALISED)</td><td class="n">{ar['source_label_m2']:.2f}</td></tr>
<tr><td class="tag">Δ</td><td>5-ZONE TOTAL {ar['five_zone_coordinate_total_m2']:.2f} vs LABEL</td><td class="n">{ar['difference_from_source_label_m2']:+.2f}</td></tr></table>
<table style="margin-top:6px"><tr><th style="width:62px">Tag</th><th>Item</th><th class="n" style="width:36px">Qty</th><th class="n" style="width:176px">W × D × H mm</th><th style="width:56px">Finish</th></tr>{fixture_rows()}</table>
<p class="note" style="margin-top:4px">Envelope 8,800 × 14,200 mm less core = 98.43 m² (source label 99.27 m²); CAD footprint screening: no fixture/column overlap; fit-out and site clearances remain subject to coordination.</p>
</div></div>"""

# ---------------------------------------------------------------- BT-02
def leader_svg(w, h, strip, pts):
    """pts: (px%,py%,label_x_px). Lines from point on image down to label strip."""
    s = f'<svg width="{w}" height="{h + strip}" style="position:absolute;left:0;top:0;overflow:visible" viewBox="0 0 {w} {h + strip}">'
    for px, py, lx in pts:
        x, y = px / 100 * w, py / 100 * h
        s += f'<line x1="{x:.1f}" y1="{y:.1f}" x2="{lx}" y2="{h + 6}" stroke="{INK}" stroke-width="0.9"/><circle cx="{x:.1f}" cy="{y:.1f}" r="2.2" fill="{INK}"/>'
    return s + "</svg>"

def bt02(im):
    css = """
    .sheet{inset:4px;grid-template-rows:24px 1fr 24px}
    .head{padding:2px 8px;gap:12px}.head .id{font-size:20px}.head .title{font-size:13px}.head .sub{font-size:9px}
    .tb>div{padding:0 6px;flex-direction:row;align-items:center;gap:6px}.tb .k{font-size:6px}.tb .v{font-size:8px;margin:0}.tb .sheetno{font-size:11px}
    .cover{padding:0 2px;height:100%;display:grid;grid-template-rows:507px 507px 108px 19px;gap:0}
    .hero-pair{display:grid;grid-template-columns:1fr 1fr;gap:4px}
    .caption{height:12px;font-size:9px;line-height:11px;font-weight:600;letter-spacing:.025em;padding:1px 4px;white-space:nowrap}
    .hero-pair img{display:block;width:100%;height:495px;object-fit:contain}
    .proofs{display:grid;grid-template-columns:1fr 1fr;gap:4px}
    .proofs img{display:block;width:100%;height:495px;object-fit:contain}
    .reference-strip{display:grid;grid-template-columns:92px repeat(4,145px) 1fr 1fr;gap:4px}.reference-strip .caption{font-size:7px}
    .reference-strip img{display:block;width:100%;height:96px;object-fit:contain;background:#f8f7f4}
    .callout{font-size:10px;font-weight:600;text-align:center;padding-top:2px;border-top:1px solid var(--ink)}
    """
    references = ''.join(f'<div><div class="caption">CLIENT PRODUCT REF {n+1} / NOT A RENDER</div><img src="{im[k]}" alt="Unaltered client-supplied product reference"></div>' for n,k in enumerate(['ph_flacons.jpg','ph_attar.jpg','ph_coffret_a.jpg','ph_coffret_b.jpg']))
    return css, f"""<div class="cover">
    <div class="hero-pair">
    <div><div class="caption">VIEW 01 — MAIN DISPLAY GALLERY (NATIVE BLENDER 5.1.1 CYCLES)</div><img src="assets/blender_view1_main_gallery.jpg" alt="Native Blender main gallery"></div>
    <div><div class="caption">VIEW 02 — VIP LOUNGE &amp; RECEPTION (NATIVE BLENDER 5.1.1 CYCLES)</div><img src="assets/blender_view2_vip_lounge.jpg" alt="Native Blender VIP lounge"></div>
    </div>
    <div class="proofs">
    <div><div class="caption">VIEW 01 / EXACT SAME-CAMERA BLENDER 5.1.1 MESH + FREESTYLE</div><img src="assets/blender_view1_wireframe_samecam.jpg" alt="View 01 same-camera proof"></div>
    <div><div class="caption">VIEW 02 / EXACT SAME-CAMERA BLENDER 5.1.1 MESH + FREESTYLE</div><img src="assets/blender_view2_wireframe_samecam.jpg" alt="View 02 same-camera proof"></div>
    </div><div class="reference-strip">
    <div><div class="caption">CAD / 99.27 sqm*</div><img src="assets/cad_floorplan_99sqm.png" alt="CAD plan; source label 99.27 sqm"></div>{references}
    <div><div class="caption">VIEW 03 / NATIVE CYCLES DETAIL</div><img src="assets/blender_view3_vitrine_closeup.jpg" alt="Native glass display detail"></div>
    <div><div class="caption">VIEW 04 / NATIVE SECTION + MESH</div><img src="assets/blender_view4_wireframe_cutaway.jpg" alt="Native cutaway proof"></div></div>
    <div class="callout">100% NATIVE BLENDER 5.1.1 (.BLEND) + AUTOCAD (.DWG) — ZERO AI GENERATION — 100% MATTE PAINT WALLS (ZERO STONE / ZERO WOOD VENEER)</div>
    </div>"""

# ---------------------------------------------------------------- BT-03
SWATCH = [
    ("BM OC-17", "White Dove / matte interior paint", "#F3EFE6", "Project digital colour target", "Roughness 0.85", "Walls, COL-01..04, ceiling", "flat"),
    ("BM OC-85", "Pale Oak / matte interior paint", "#E6DEC8", "Project digital colour target", "Roughness 0.85", "Niches and painted fixture bases", "flat"),
    ("FAB-01", "Warm cream bouclé", "#EEE6D8", "Procedural Blender fibre relief", "Soft matte upholstery", "Curved VIP sofa and armchairs", "flat"),
    ("MET-01", "Satin champagne metal", "#C5B08B", "Small-section metalwork", "Satin", "Vitrine frames and hardware", "metal"),
    ("GLZ-01", "Clear display glass", "#DCE6E2", "Native transmission shader", "Lockable display / modelled hardware", "Vitrines and office glazing", "glass"),
    ("FLR-01", "Warm ivory floor", "#EAE4DA", "Existing finish subject to survey", "No stone wall cladding", "Continuous light neutral floor", "flat"),
]

def swatch_html():
    out = []
    for code, name, hexv, a, b, z, kind in SWATCH:
        if kind == "metal":
            bg = f"linear-gradient(100deg,#B9A57F 0%,#D3C19E 38%,#BBA781 62%,#CDBA94 100%)"
        elif kind == "glass":
            bg = f"linear-gradient(90deg,{hexv} 0 14%,#EAF0ED 14% 17%,{hexv} 17% 31%,#EAF0ED 31% 34%,{hexv} 34% 48%,#EAF0ED 48% 51%,{hexv} 51% 65%,#EAF0ED 65% 68%,{hexv} 68% 82%,#EAF0ED 82% 85%,{hexv} 85%)"
        elif kind == "tile":
            bg = f"linear-gradient({INK}22 1px,transparent 1px) 0 0/50% 50%,linear-gradient(90deg,{INK}22 1px,transparent 1px) 0 0/50% 50%,{hexv}"
        else:
            bg = hexv
        out.append(f"""<div style="padding:0 10px 0 10px"><div style="height:200px;background:{bg};border:1px solid {INK}"></div>
<div class="mono" style="font-size:10.5px;margin-top:6px;display:flex;justify-content:space-between"><b style="font-weight:400">{code}</b><span>{hexv if kind in ('flat','tile','metal') else 'CLEAR GLASS'}</span></div>
<div class="disp" style="font-size:12.5px;line-height:1.2;margin-top:3px">{name}</div>
<div style="font-size:10.5px;margin-top:4px;border-top:1px solid {RULE};padding-top:3px">{a}<br>{b}</div>
<div class="note" style="margin-top:3px"><b style="font-weight:600;color:{INK}">Applied:</b> {z}</div></div>""")
    return "".join(out)

def bt03(im):
    css = """.cols{bottom:auto;height:650px;grid-template-columns:1032fr 536fr}.pb{position:absolute;left:0;right:0;top:650px;bottom:0;border-top:1px solid var(--ink);padding:10px 8px 8px}"""
    sch = "".join(f'<tr><td class="tag">{t}</td><td class="n">{d}</td></tr>' for t, d in [
        ("V-01..04", dims(fx("vitrine")[0])), ("V-05..06", dims(fx("vitrine")[4])), ("P-01..03", dims(fx("pedestal")[0])),
        ("O-01..04", dims(fx("open_shelf")[0])), ("I-01", dims(fx("discovery")[0])), ("R-01", dims(fx("reception")[0]))])
    body = f"""<div class="cols">
<div class="col" style="padding-right:8px"><div class="lbl"><span class="tag">E-01..E-03 · D-01</span><span class="t">Dimensioned interior elevations and vitrine section</span><span class="r">CAD reference: ceiling +2,800 · display +2,400</span></div>
<div style="width:978px"><img class="mul" src="{im['elev_clean.png']}" style="width:978px;display:block"></div></div>
<div class="col"><div class="lbl"><span class="tag">Key</span><span class="t">Elevation index</span></div>
<table><tr><th style="width:56px">Ref</th><th>Sheet label</th><th>View</th></tr>
<tr><td class="tag">E-01</td><td>A</td><td>East vitrine wall, V-01..V-06</td></tr>
<tr><td class="tag">E-02</td><td>B</td><td>West open shelving, O-01..O-04, service core</td></tr>
<tr><td class="tag">E-03</td><td>C</td><td>South: VIP, office acoustic glass, hidden-store jib door</td></tr>
<tr><td class="tag">D-01</td><td>Section</td><td>Vitrine: LED, low-iron glass, lockable door, base anchorage</td></tr></table>
<div class="lbl" style="margin-top:14px"><span class="tag">Display schedule</span><span class="r">W × D × H mm, from layout_geometry.json</span></div>
<table><tr><th>Tag</th><th class="n">Size</th></tr>{sch}</table>
<p class="note" style="margin-top:10px">Wall relief comes only from drywall geometry and shadow-gap reveals; finish is paint. Elevation widths, heights and door positions follow the coordinate model; site survey needed for door clearances.</p></div></div>
<div class="pb"><div class="lbl" style="margin:0 10px 8px"><span class="tag">Matte paint &amp; material specification</span><span class="t" style="font-weight:400;text-transform:none;letter-spacing:0">Paint only: no stone wall cladding, no wood veneer wall panels, per client budget brief</span><span class="r">Hex = screen approximation; confirm against physical swatch fan before ordering</span></div>
<div style="display:grid;grid-template-columns:repeat(6,1fr)">{swatch_html()}</div></div>"""
    return css, body

# ---------------------------------------------------------------- BT-04
def mb(p):
    return f"{p.stat().st_size / 1e6:.1f} MB"

MANIFEST = [
    ("Crystal_Perfume_Boutique_99sqm.blend", ".blend", "Perspective Cycles scene; views 01–03"),
    ("Crystal_Perfume_Boutique_99sqm_Axonometric.blend", ".blend", f"Orthographic axonometric scene, {BLV['objects']} objects, live Boolean openings"),
    ("Crystal_Perfume_Boutique_99sqm.dxf", ".dxf", f"AutoCAD R2010, {len(CADV['layers'])} layers, {CADV['native_dimensions']} native dimensions"),
    ("Crystal_Perfume_Boutique_99sqm.dwg", ".dwg", "AutoCAD 2000 format, vector round-trip checked; not opened in Autodesk AutoCAD"),
    ("Crystal_Perfume_Boutique_99sqm_Submission_A3.pdf", ".pdf", "Print-ready 4-sheet PDF, 300 DPI"),
]

def bt04(im):
    manifest=json.loads((X/'render_manifest.json').read_text())
    native=manifest['renders'][0]['geometry']
    css=""".proof-board{padding:14px 18px;height:100%;display:grid;grid-template-rows:500px 1fr;gap:18px}
    .proof-top{display:grid;grid-template-columns:1fr 1fr;gap:18px}.proof-top img{width:100%;height:465px;object-fit:contain;display:block}
    .proof-bottom{display:grid;grid-template-columns:1.1fr 1fr 1fr;gap:24px;border-top:1px solid var(--ink);padding-top:16px}
    .proof-bottom h3{font-size:16px;margin:0 0 10px}.proof-bottom p{font-size:13px;line-height:1.55;margin-bottom:12px}
    .proof-bottom td{font-size:11px;padding:8px 4px}.proof-bottom .note{font-size:11px}
    """
    return css,f"""<div class="proof-board"><div class="proof-top">
    <div><div class="lbl"><span class="t">VIEW 03 / CRYSTAL VITRINE DETAIL</span><span class="r">Blender 5.1.1 / Cycles</span></div><img src="assets/blender_view3_vitrine_closeup.jpg" alt="Crystal flacons in native glass display"></div>
    <div><div class="lbl"><span class="t">VIEW 04 / NATIVE SECTION + MESH</span><span class="r">Clay / Freestyle</span></div><img src="assets/blender_view4_wireframe_cutaway.jpg" alt="Native geometry cutaway"></div>
    </div><div class="proof-bottom"><div><h3>Native model / reproducible views</h3>
    <p>{native['mesh_objects']:,} mesh objects · {native['evaluated_vertices']:,} evaluated vertices. Parametric objects, live Boolean openings, actual glass and procedural fabrics.</p>
    <p>VIEW 01 and VIEW 02 are paired with clay + Freestyle views using identical camera matrices, lenses, shifts, pixel dimensions and evaluated mesh hashes. Glass stays transparent in the proof.</p>
    <p class="note">Camera-pair verification: 2 / 2. Evidence: exports/render_manifest.json. The cutaway is an architectural section of the perspective model.</p>
    </div><div><h3>Paint, light and display</h3>
    <p>Walls, four structural columns and ceiling: BM OC-17 White Dove #F3EFE6. Painted niches and fixture bases: BM OC-85 Pale Oak #E6DEC8. Both matte, roughness 0.85.</p>
    <p>Broad neutral area lights, softened daylight and ceiling bounce keep the interior open and luminous. Modelled locks, low-iron glass and faceted crystal distinguish secure display from open product shelves.</p>
    <p class="note">Wood appears only in gift boxes and furniture. No stone, travertine, wood veneer or heavy panel wall finishes.</p>
    </div><div><h3>Editable handover / REV.03</h3>
    <table><tr><td>.BLEND</td><td>Perspective scene + CAD axonometric model</td></tr><tr><td>.DWG / .DXF</td><td>Native binary DWG; editable R2010 DXF dimensions</td></tr><tr><td>.JPG / .PDF</td><td>Six renders + four 3200 × 2400 boards + A3 PDF</td></tr><tr><td>.PY / .JSON</td><td>Build scripts, camera records, material audit, hashes</td></tr></table>
    <p class="note" style="margin-top:12px">99.27 sqm is the client's source label; CAD coordinate area excluding the service core is 98.43 sqm. CAD and detailed perspective layouts retain separate fit-out assumptions; same-camera proof applies to render pairs.</p>
    <p class="note">Client-supplied product references are separate from the design renders. Zero AI image generation in the submitted interior views. See docs/REV03.md for scope and rebuild commands.</p>
    </div></div></div>"""

# ---------------------------------------------------------------- build
def build_html(im):
    pages = {}
    for (bt, stem, title), fn in zip(BOARDS, (bt02, bt01, bt03, bt04)):
        css, body = fn(im)
        extra = css if isinstance(css, str) else ""
        pages[stem] = shell(bt, title, body, extra)
    return pages

AUDIT = """() => {
 const sheet=document.querySelector('.sheet');
 const leaves=[...sheet.querySelectorAll('*')].filter(e=>!e.closest('svg')&&!e.children.length&&(e.tagName==='IMG'||e.textContent.trim()));
 const r=e=>e.getBoundingClientRect(); let ov=[];
 for(let i=0;i<leaves.length;i++)for(let j=i+1;j<leaves.length;j++){
  const a=r(leaves[i]),b=r(leaves[j]);
  const w=Math.min(a.right,b.right)-Math.max(a.left,b.left),h=Math.min(a.bottom,b.bottom)-Math.max(a.top,b.top);
  if(w>1&&h>1&&leaves[i].tagName!=='TH'&&leaves[j].tagName!=='TH')ov.push((leaves[i].textContent||leaves[i].tagName).slice(0,24)+' | '+(leaves[j].textContent||leaves[j].tagName).slice(0,24));}
 const sr=sheet.getBoundingClientRect();
 const outside=[...sheet.querySelectorAll('*')].filter(e=>!e.closest('svg')&&(r(e).right>sr.right+1||r(e).bottom>sr.bottom+1)).length;
 const tb=document.querySelector('.tb').getBoundingClientRect();
 const intoTB=[...sheet.querySelectorAll('.main *')].filter(e=>!e.closest('svg')&&r(e).bottom>tb.top+1).length;
 const clip=[...sheet.querySelectorAll('*')].filter(e=>e.scrollHeight>e.clientHeight+1&&getComputedStyle(e).overflow!=='visible'&&!e.classList.contains('sheet')).length;
 return {sw:document.documentElement.scrollWidth*2,sh:document.documentElement.scrollHeight*2,overlaps:ov,outside,intoTB,clip};}"""


def render(pages):
    res = {}
    with sync_playwright() as p:
        b = p.chromium.launch()
        pg = b.new_page(viewport={"width": 1600, "height": 1200}, device_scale_factor=2)
        for stem, html in pages.items():
            f = ROOT / f"{stem}.html"
            f.write_text(html)
            pg.goto(f.as_uri()); pg.wait_for_load_state("networkidle"); pg.evaluate("document.fonts.ready")
            a = pg.evaluate(AUDIT)
            image = Image.open(io.BytesIO(pg.screenshot())).convert("RGB")
            image.save(ROOT / f"{stem}.jpg", "JPEG", quality=95)
            (ROOT / "deliverables").mkdir(exist_ok=True)
            shutil.copy2(ROOT / f"{stem}.jpg", ROOT / "deliverables" / f"{stem}.jpg")
            preview = image.resize((1200,900),Image.Resampling.LANCZOS)
            (ROOT / "review/previews").mkdir(parents=True,exist_ok=True)
            preview.save(ROOT / "review/previews" / f"{stem}_preview_1200x900.jpg",quality=93)
            a["visual_area_ratio"] = pg.evaluate("() => [...document.querySelectorAll('.main img')].reduce((s,e)=>{const r=e.getBoundingClientRect();const fit=getComputedStyle(e).objectFit;if(fit==='contain'){const k=Math.min(r.width/e.naturalWidth,r.height/e.naturalHeight);return s+e.naturalWidth*e.naturalHeight*k*k}return s+r.width*r.height},0)/(1600*1200)")
            a["missing_images"] = pg.evaluate("() => [...document.images].filter(e=>!e.complete||!e.naturalWidth).map(e=>e.src)")
            res[stem] = a
            print(stem, a)
        b.close()
    return res

def package():
    jpgs = [ROOT / f"{s}.jpg" for _, s, _ in BOARDS]
    ims = [Image.open(j).convert("RGB") for j in jpgs]
    pdf = X / "Crystal_Perfume_Boutique_99sqm_Submission_A3.pdf"
    # true A3 landscape at 300 DPI (4961x3508): board scaled to full height, paper-colour side margins
    a3 = []
    for im in ims:
        s = 3508 / im.height
        r = im.resize((round(im.width * s), 3508), Image.Resampling.LANCZOS)
        c = Image.new("RGB", (4961, 3508), PAPER)
        c.paste(r, ((4961 - r.width) // 2, 0))
        a3.append(c)
    a3[0].save(pdf, "PDF", resolution=300, save_all=True, append_images=a3[1:])
    zp = X / "Crystal_Perfume_Boutique_99sqm_Master_Pack.zip"
    return pdf, zp


def current_assets():
    return ([A / name for name in [
        "blender_view1_main_gallery.jpg", "blender_view2_vip_lounge.jpg",
        "blender_view1_wireframe_samecam.jpg", "blender_view2_wireframe_samecam.jpg",
        "blender_view3_vitrine_closeup.jpg", "blender_view4_wireframe_cutaway.jpg",
        "cad_floorplan_99sqm.png", "cad_3d_axonometric.png", "cad_elevations_vitrines.png"]]
        + list((A / "board_crops").glob("*")) + list((A / "fonts").glob("*.ttf")))


def publish_local(pdf, zp, pages):
    # Curated current files only; review backups and superseded renders never enter the pack.
    exports = [X / n for n in [
        "Crystal_Perfume_Boutique_99sqm.blend", "Crystal_Perfume_Boutique_99sqm_Axonometric.blend",
        "Crystal_Perfume_Boutique_99sqm.dwg", "Crystal_Perfume_Boutique_99sqm.dxf",
        pdf.name, "render_manifest.json", "blender_validation.json", "cad_validation.json",
        "dwg_validation.json", "verification.json"]]
    files = exports + current_assets() + list((ROOT/"scripts").glob("*.py"))
    files += [ROOT/"layout_geometry.json", ROOT/"README.md", ROOT/"docs/REV03.md", ROOT/"index.html"]
    # Keep the compositor's original inputs so the downloaded pack can rebuild.
    # These are client attachments, labelled separately from our native renders.
    files += [B / n for n in [
        "IMG_4951.PNG", "895d2c32-dca2-4d5e-adaa-f6e12dcbcde4.JPG",
        "Gemini_Generated_Image_h21hyah21hyah21h.png",
        "Gemini_Generated_Image_ck9sdbck9sdbck9s.jpg", "Gemini_Generated_Image_SQUARE.png"]]
    files += [ROOT/"review/previews"/f"{stem}_preview_1200x900.jpg" for _,stem,_ in BOARDS]
    files += [ROOT/"deliverables"/f"{stem}.jpg" for _,stem,_ in BOARDS]
    files += [ROOT/f"{stem}.html" for _,stem,_ in BOARDS]
    files += [ROOT/f"{stem}.jpg" for _,stem,_ in BOARDS]
    files += [ROOT/"review/board_audit_rev03.json"]
    with zipfile.ZipFile(zp,"w",zipfile.ZIP_DEFLATED) as z:
        for f in files:z.write(f,f.relative_to(ROOT).as_posix())
    # Legacy download URL now resolves to the current pack, never old imagery.
    shutil.copy2(zp, X/"Crystal_Perfume_Boutique_Coordinate_Review_Pack.zip")
    aliases={"board1_floorplan_axon":"board2_floorplan_axon", "board2_cycles_gallery_views":"board1_cycles_gallery_views"}
    for old,new in aliases.items():
        for ext in ["html","jpg"]:shutil.copy2(ROOT/f"{new}.{ext}",ROOT/f"{old}.{ext}")
    # docs/ is a complete local static-site mirror, ready for the existing Pages route.
    site_files = current_assets()+exports+[zp,X/"Crystal_Perfume_Boutique_Coordinate_Review_Pack.zip",ROOT/"index.html"]
    site_files += [ROOT/f"{stem}.{ext}" for _,stem,_ in BOARDS for ext in ["html","jpg"]]
    site_files += [ROOT/"deliverables"/f"{stem}.jpg" for _,stem,_ in BOARDS]
    site_files += [ROOT/f"{stem}.{ext}" for stem in aliases for ext in ["html","jpg"]]
    for f in site_files:
        target=ROOT/"docs"/f.relative_to(ROOT);target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(f,target)
    (ROOT/"docs/.nojekyll").touch()
    return files

def index_html(pdf, zp):
    zr, ar = zone_rows()
    btn = lambda href, t: f'<a class="btn" href="{href}" download>{t}</a>'
    paint = "".join(f'<tr><td class="tag">{c}</td><td>{n}</td><td class="tag">{h if k != "glass" else "—"}</td><td>{a}</td><td>{b}</td><td>{z}</td></tr>' for c, n, h, a, b, z, k in SWATCH)
    tabs = "".join(f'<button data-i="{i}" class="tab{" on" if i == 0 else ""}">{bt}</button>' for i, (bt, _, _) in enumerate(BOARDS))
    imgs = json.dumps([f"deliverables/{s}.jpg?v=rev03-"+hashlib.sha256((ROOT/"deliverables"/f"{s}.jpg").read_bytes()).hexdigest()[:12] for _,s,_ in BOARDS])
    return f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Crystal &amp; Perfume Boutique REV.03 — Contest #2801401</title><style>{CSS.split(':root')[0]}
:root{{--ink:{INK};--ink2:{INK2};--rule:{RULE};--tint:{TINT};--paper:{PAPER}}}
html,body{{width:auto;height:auto}}body{{padding:28px 40px 60px;max-width:1400px;margin:auto;font-size:14px;font-family:"IBM Plex Sans",sans-serif;line-height:1.4;color:var(--ink)}}
h1{{font-family:"Space Grotesk";font-size:30px;letter-spacing:-.03em}}h2{{font-family:"Space Grotesk";font-size:14px;letter-spacing:.05em;text-transform:uppercase;margin:32px 0 8px;padding-bottom:6px;border-bottom:1.5px solid var(--ink)}}
.btn{{display:inline-block;border:1px solid var(--ink);padding:8px 16px;margin:0 8px 8px 0;font-family:"JetBrains Mono";font-size:12px;color:var(--ink);text-decoration:none}}.btn:hover{{background:var(--ink);color:var(--paper)}}
.tab{{font-family:"JetBrains Mono";font-size:12px;padding:6px 14px;border:1px solid var(--ink);background:none;cursor:pointer;margin-right:-1px}}.tab.on{{background:var(--ink);color:var(--paper)}}
#vp{{height:78vh;border:1.5px solid var(--ink);overflow:hidden;position:relative;cursor:grab;margin-top:10px;background:#fff}}:focus-visible{{outline:2px solid #685333;outline-offset:3px}}
@media(max-width:700px){{body{{padding:18px 12px}}h1{{font-size:23px}}table{{display:block;overflow:auto}}#vp{{height:auto;aspect-ratio:4/3}}}}
#vp img{{position:absolute;left:0;top:0;transform-origin:0 0;user-select:none;-webkit-user-drag:none}}
td,th{{font-size:12.5px}}</style></head><body>
<h1>Luxury Crystal &amp; Perfume Boutique — REV.03</h1>
<p class="note" style="font-size:13px;margin-top:6px">Contest #2801401 · 99.27 sqm client brief · Bright matte-paint interiors · Native Blender 5.1.1 Cycles + same-camera Freestyle proof</p>
<p style="margin-top:12px">Six images rendered directly in Blender 5.1.1. No AI-generated interior images. OC-17 / OC-85 matte paint on walls, columns and ceiling.</p>
<p class="note" style="margin-top:6px">99.27 sqm is the source-plan label; the CAD coordinate area excluding the existing service core is 98.43 sqm. Perspective fit-out and CAD reference assumptions are documented separately.</p>
<h2>Downloads / REV.03</h2>
{btn("exports/Crystal_Perfume_Boutique_99sqm.dwg", ".DWG")}{btn("exports/Crystal_Perfume_Boutique_99sqm.dxf", ".DXF")}{btn("exports/Crystal_Perfume_Boutique_99sqm.blend", ".BLEND")}{btn("exports/Crystal_Perfume_Boutique_99sqm_Axonometric.blend", ".BLEND (AXONOMETRIC)")}{btn("exports/" + pdf.name, ".PDF")}{btn("exports/" + zp.name, ".ZIP")}
<p><a href="exports/render_manifest.json">Camera, mesh and render provenance</a> · <a href="REV03.md" id="revision-notes">Revision / rebuild notes</a></p>
<h2>Sheets BT-01 – BT-04 (wheel = zoom, drag = pan, double-click = fit)</h2>
<div>{tabs}<button class="tab" id="zi">+</button><button class="tab" id="zo">−</button><button class="tab" id="fit">FIT</button></div><div id="vp"><img id="im"></div>
<h2>Area reconciliation</h2><table style="max-width:760px"><tr><th>Zone</th><th>Description</th><th class="n">m²</th></tr>{zr}
<tr><td class="tag">LBL</td><td>SOURCE RASTER LABEL (NOT NORMALISED)</td><td class="n">{ar['source_label_m2']:.2f}</td></tr></table>
<h2>Fixture schedule</h2><table style="max-width:1000px"><tr><th>Tag</th><th>Item</th><th class="n">Qty</th><th class="n">W × D × H mm</th><th>Finish</th></tr>{fixture_rows()}</table>
<h2>Paint &amp; material schedule</h2><table><tr><th>Code</th><th>Name</th><th>Hex</th><th>Value</th><th>Sheen / note</th><th>Applied</th></tr>{paint}</table>
<p class="note" style="margin-top:10px">Wall finishes are paint only: no stone cladding, no wood veneer wall panels. Hex values are screen approximations.</p>
<script>const L={imgs};const vp=document.getElementById('vp'),im=document.getElementById('im');let s=1,x=0,y=0,d=null;
function ap(){{im.style.transform=`translate(${{x}}px,${{y}}px) scale(${{s}})`}}
function fit(){{s=Math.min(vp.clientWidth/im.naturalWidth,vp.clientHeight/im.naturalHeight);x=(vp.clientWidth-im.naturalWidth*s)/2;y=(vp.clientHeight-im.naturalHeight*s)/2;ap()}}
function zoom(k,cx,cy){{const n=Math.max(.05,Math.min(4,s*k));x=cx-(cx-x)*n/s;y=cy-(cy-y)*n/s;s=n;ap()}}
function show(i){{im.onload=fit;im.src=L[i];document.querySelectorAll('.tab[data-i]').forEach(b=>b.classList.toggle('on',+b.dataset.i===i))}}
document.querySelectorAll('.tab[data-i]').forEach(b=>b.onclick=()=>show(+b.dataset.i));
document.getElementById('zi').onclick=()=>zoom(1.3,vp.clientWidth/2,vp.clientHeight/2);document.getElementById('zo').onclick=()=>zoom(1/1.3,vp.clientWidth/2,vp.clientHeight/2);document.getElementById('fit').onclick=fit;vp.ondblclick=fit;
vp.onwheel=e=>{{e.preventDefault();const r=vp.getBoundingClientRect();zoom(e.deltaY<0?1.15:1/1.15,e.clientX-r.left,e.clientY-r.top)}};
vp.onmousedown=e=>{{d=[e.clientX-x,e.clientY-y];vp.style.cursor='grabbing'}};window.onmouseup=()=>{{d=null;vp.style.cursor='grab'}};window.onmousemove=e=>{{if(d){{x=e.clientX-d[0];y=e.clientY-d[1];ap()}}}};
document.getElementById('revision-notes').href=location.pathname.includes('/docs/')?'REV03.md':'docs/REV03.md';
window.onresize=fit;show(0);</script></body></html>"""


def main():
    manifest=json.loads((X/"render_manifest.json").read_text())
    assert manifest["blender_version"]=="5.1.1" and len(manifest["renders"])==6
    for path,expected in manifest["scripts"].items():
        assert hashlib.sha256((ROOT/path).read_bytes()).hexdigest()==expected, "Render script changed since Blender: "+path
    assert len(manifest["camera_pairs"])==2 and all(p["camera_equal"] and p["evaluated_mesh_equal"] and p["visibility_equal"] for p in manifest["camera_pairs"])
    for item in manifest["renders"]:
        assert hashlib.sha256((ROOT/item["file"]).read_bytes()).hexdigest()==item["sha256"], "Render changed since Blender: "+item["file"]
    assert hashlib.sha256((ROOT/manifest["native_blend"]).read_bytes()).hexdigest()==manifest["native_blend_sha256"]
    im=prep_images();pages=build_html(im);res=render(pages)
    bad={k:v for k,v in res.items() if v["overlaps"] or v["outside"] or v["intoTB"] or v["clip"] or v["missing_images"] or v["sw"]>3200 or v["sh"]>2400}
    (ROOT/"review/board_audit_rev03.json").write_text(json.dumps(res,indent=2)+"\n")
    assert not bad, bad
    assert res["board1_cycles_gallery_views"]["visual_area_ratio"]>=.85
    pdf,zp=package()
    (ROOT/"index.html").write_text(index_html(pdf,zp))
    publish_local(pdf,zp,pages)
    print("REV.03 BOARD / PACKAGE AUDIT PASS",pdf,zp)

if __name__ == "__main__":main()
