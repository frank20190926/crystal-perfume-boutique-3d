"""REV.03 native Cycles + exact-camera clay/Freestyle render pipeline.
Run Blender -b --factory-startup --python scripts/render_blender.py.
BOUTIQUE_PREVIEW=1 writes only to review/preview_renders; BOUTIQUE_VIEWS=1,2,3,4.
CAD orthographic pipeline: render_cad_axonometric.py.
"""
import hashlib, json, os, runpy, struct
from pathlib import Path
from datetime import datetime, timezone
import bpy
ROOT=Path(__file__).resolve().parents[1]
assert bpy.app.version[:3]==(5,1,1), bpy.app.version_string
requested=[int(v) for v in os.environ.get('BOUTIQUE_VIEWS','1,2,3,4').split(',') if v.strip()]
assert requested and all(v in (1,2,3,4) for v in requested), 'Views must be 1, 2, 3 or 4'
assert os.environ.get('BOUTIQUE_PREVIEW')=='1' or requested==[1,2,3,4], \
 'Final delivery requires all four views and both proofs. Use BOUTIQUE_PREVIEW=1 for selected views.'
os.environ['BOUTIQUE_NORENDER']='1'
ns=runpy.run_path(str(ROOT/'scripts/build_blender_boutique.py'))
scene,mats,cols=ns['scene'],ns['MAT'],ns['COLS']
preview=ns['PREVIEW']
out=ROOT/('review/preview_renders' if preview else 'assets')
out.mkdir(parents=True,exist_ok=True)
scene.render.resolution_x=1920;scene.render.resolution_y=1200
scene.render.resolution_percentage=50 if preview else 100
scene.cycles.samples=32 if preview else 256
scene.cycles.adaptive_threshold=.035 if preview else .012
scene.render.image_settings.quality=97
bpy.context.preferences.filepaths.save_version=0
scene['revision']='REV.03'
scene['image_provenance']='Native Blender Cycles + Freestyle; zero AI image generation'
scene['wall_finish']='OC-17 #F3EFE6 / OC-85 #E6DEC8; matte paint; roughness 0.85'

def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def camera_state():
 c=scene.camera
 return dict(name=c.name,matrix_world=[list(r) for r in c.matrix_world],lens_mm=c.data.lens,
  sensor_width_mm=c.data.sensor_width,shift_x=c.data.shift_x,shift_y=c.data.shift_y,
  clip_start=c.data.clip_start,clip_end=c.data.clip_end,
  resolution=[scene.render.resolution_x,scene.render.resolution_y,scene.render.resolution_percentage],
  pixel_aspect=[scene.render.pixel_aspect_x,scene.render.pixel_aspect_y])
def geometry_state():
 """Hash actual evaluated vertices, faces and world transforms, not names alone."""
 bpy.context.view_layer.update();dg=bpy.context.evaluated_depsgraph_get();h=hashlib.sha256()
 objects=vertices=faces=0
 for ob in sorted(scene.objects,key=lambda o:o.name):
  if ob.type!='MESH':continue
  ev=ob.evaluated_get(dg);me=ev.to_mesh();h.update(ob.name.encode())
  for r in ob.matrix_world:h.update(struct.pack('<4d',*r))
  for v in me.vertices:h.update(struct.pack('<3d',*v.co))
  for p in me.polygons:
   h.update(struct.pack('<I',len(p.vertices)));h.update(struct.pack('<'+'I'*len(p.vertices),*p.vertices))
  vertices+=len(me.vertices);faces+=len(me.polygons);objects+=1;ev.to_mesh_clear()
 return dict(sha256=h.hexdigest(),mesh_objects=objects,evaluated_vertices=vertices,evaluated_faces=faces)
def visibility_state():
 return dict(objects={o.name:o.hide_render for o in scene.objects},collections={c.name:c.hide_render for c in bpy.data.collections})
def audit_paint():
 objects=[];allowed={mats['wall'].name,mats['beige'].name}
 for ob in scene.objects:
  if ob.type!='MESH':continue
  if ob.name.startswith(('WAL_','COL-')) or cols['02_ARCH_Ceiling'] in ob.users_collection:
   names=[m.name for m in ob.data.materials]
   assert names and set(names)<=allowed,(ob.name,names)
   for m in ob.data.materials:assert abs(m.node_tree.nodes['Principled BSDF'].inputs['Roughness'].default_value-.85)<1e-6
   objects.append(dict(name=ob.name,materials=names))
 assert all(bpy.data.objects.get(f'COL-{i:02d}') for i in range(1,5))
 image_nodes=[(m.name,n.name) for m in bpy.data.materials if m.use_nodes for n in m.node_tree.nodes if n.type=='TEX_IMAGE']
 assert not image_nodes,image_nodes
 return dict(painted_architecture=objects,roughness=.85,image_texture_nodes=0,
  wood_scope='Product gift boxes and office furniture only; no wood wall finish')
def render_image(filename,view,proof=False):
 scene.render.filepath=str(out/filename);scene.render.use_freestyle=proof
 bpy.ops.render.render(write_still=True)
 return dict(file=str((out/filename).relative_to(ROOT)),sha256=digest(out/filename),view=view,
  pass_type='CLAY_FREESTYLE' if proof else 'CYCLES',camera=camera_state(),geometry=geometry_state(),
  samples=scene.cycles.samples,exposure=scene.view_settings.exposure)
def same_camera_clay():
 """Identical geometry/camera/visibility; glass remains transparent to expose products."""
 saved={};keep={mats[k].name for k in ['vglass','wglass','linen']}
 for me in bpy.data.meshes:
  saved[me.name]=list(me.materials)
  for i,m in enumerate(me.materials):
   if m.name not in keep:me.materials[i]=mats['clay_floor'] if 'FLR_' in me.name else mats['clay']
 bpy.ops.object.select_all(action='DESELECT')
 marked=[]
 for ob in scene.objects:
  if ob.type=='MESH' and ob.name.startswith(('V-','P-','ISL_','VIP_','REC_','COL-','O-')):
   ob.select_set(True);marked.append(ob)
 bpy.context.view_layer.objects.active=marked[0]
 bpy.ops.object.mode_set(mode='EDIT')
 bpy.ops.mesh.select_all(action='SELECT')
 bpy.ops.mesh.mark_freestyle_edge(clear=False)
 bpy.ops.object.mode_set(mode='OBJECT')
 ls=scene.view_layers[0].freestyle_settings.linesets[0]
 ls.select_edge_mark=True;ls.linestyle.color=(.025,.035,.04);ls.linestyle.thickness=1.0
 return saved
def restore_materials(saved):
 for name,materials in saved.items():
  for i,m in enumerate(materials):bpy.data.meshes[name].materials[i]=m
 scene.render.use_freestyle=False
manifest=dict(revision='REV.03',blender_version=bpy.app.version_string,blender_build_hash=bpy.app.build_hash.decode(),
 created_utc=datetime.now(timezone.utc).isoformat(),native_blend=str(Path(ns['BLEND_PATH']).relative_to(ROOT)),
 scripts={p:digest(ROOT/p) for p in ['scripts/build_blender_boutique.py','scripts/render_blender.py']},
 paint_audit=audit_paint(),renders=[],camera_pairs=[])
for i in ns['VIEWS']:
 ns['apply_view'](i)
 if i==4:
  # True wall section for the cutaway only; source meshes remain saved uncut.
  import bmesh
  for ob in cols['01_ARCH_Shell'].objects:
   if not ob.name.startswith('WAL_'):continue
   ob.data=ob.data.copy();bm=bmesh.new();bm.from_mesh(ob.data)
   bmesh.ops.bisect_plane(bm,geom=list(bm.verts)+list(bm.edges)+list(bm.faces),plane_co=(0,0,.85),
    plane_no=(0,0,1),clear_outer=True,dist=.0001)
   bm.to_mesh(ob.data);bm.free()
  scene.view_layers[0].freestyle_settings.linesets[0].select_edge_mark=True
 color=render_image(ns['CAM_FILES'][i],i,proof=i==4);manifest['renders'].append(color)
 if i in [1,2] and not (preview and os.environ.get("BOUTIQUE_PROOFS")=="0"):
  before_visibility=visibility_state();saved=same_camera_clay()
  proof=render_image(f'blender_view{i}_wireframe_samecam.jpg',i,proof=True);restore_materials(saved)
  assert proof['camera']==color['camera'],'Camera mismatch'
  assert proof['geometry']==color['geometry'],'Evaluated mesh mismatch'
  assert before_visibility==visibility_state(),'Visibility mismatch'
  manifest['renders'].append(proof)
  manifest['camera_pairs'].append(dict(view=i,camera_equal=True,evaluated_mesh_equal=True,
   visibility_equal=True,geometry_sha256=color['geometry']['sha256']))
# Reload uncut source; never save clay overrides as the handover file.
bpy.ops.wm.open_mainfile(filepath=ns['BLEND_PATH']);scene=bpy.context.scene
scene['revision']='REV.03';scene['image_provenance']='Native Blender Cycles + Freestyle; zero AI image generation'
scene.render.resolution_percentage=100;scene.cycles.samples=256;scene.render.use_freestyle=False
bpy.context.preferences.filepaths.save_version=0
bpy.ops.wm.save_as_mainfile(filepath=ns['BLEND_PATH'],compress=True)
manifest['native_blend_sha256']=digest(ns['BLEND_PATH'])
target=ROOT/('review/preview_renders/render_manifest.json' if preview else 'exports/render_manifest.json')
target.write_text(json.dumps(manifest,indent=2)+'\n')
print('REV03 COMPLETE',target,flush=True)
