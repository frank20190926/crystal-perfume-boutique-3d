"""Millimetre source model. Preserve the supplied coordinates and their provenance."""
import json
from pathlib import Path
from shapely.geometry import Polygon, box
from shapely.ops import unary_union
ROOT=Path(__file__).resolve().parents[1]

def rect(b):
 x,y,X,Y=b;return [[x,y],[X,y],[X,Y],[x,Y]]

def make_geometry():
 g=dict(schema_version='1.0',contest_id=2801401,units='mm',origin='South-west; X east, Y north, Z up',
  source_plan='brief/IMG_4951.PNG',coordinate_authority='User-supplied coordinates, 2026-11-10; raster dimensions independently inspected',
  boundary_mm=[[0,0],[6450,0],[6450,4999],[8800,4999],[8800,14200],[0,14200]],
  height_assumptions_mm=dict(enclosure=2800,display=2400,new_partitions=2400,north_window_sill=650,west_window_sill=450,window_head=2700),
  finishes=[dict(code='BM-OC-17',name='Benjamin Moore OC-17 White Dove',hex='#F3EFE6',finish='Matte painted walls and shelving'),dict(code='BM-OC-85',name='Benjamin Moore OC-85 Pale Oak',hex='#E6DEC8',finish='Matte painted console and selected joinery'),dict(code='MET-01',name='Satin Champagne Bronze',hex='#C5B08B',finish='Satin metal vitrine frames and hardware')],
  walls=[],columns=[],glazing=[],doors=[],fixtures=[],lighting=[],zones=[],coordination=[])
 def wall(id,b,status='existing',h=2800):g['walls'].append(dict(id=id,bounds_mm=b,z_mm=[0,h],status=status))
 # Outside face of finish is offset outward; coordinate boundary is the inner face.
 for id,b in [('S',[0,-150,6600,0]),('SE',[6450,0,6600,4999]),('E',[8800,4849,8950,14350]),('N1',[-150,14200,1850,14350]),('N2',[7350,14200,8800,14350]),('W1',[-150,0,0,900]),('W2',[-150,5500,0,14200]),('ENTRY1',[6450,4849,6850,4999]),('ENTRY2',[7950,4849,8800,4999])]:wall('EXT-'+id,b)
 # Glazing openings with solid sill and head defined in the model.
 for id,b,sill in [('WN',[1850,14200,7350,14350],650),('WW',[-150,900,0,5500],450)]:
  g['glazing'].append(dict(id=id,bounds_mm=b,z_mm=[sill,2700],mullion_spacing_max_mm=1100))
  wall(id+'-SILL',b,h=sill);g['walls'].append(dict(id=id+'-HEAD',bounds_mm=b,z_mm=[2700,2800],status='existing'))
 core=[('PANTRY-N',12100,14200),('WC-N',10100,12100),('SHAFT',9350,10100),('WC-S',7450,9350),('PANTRY-S',5500,7450)]
 g['service_core']=dict(bounds_mm=[0,5500,1699,14200],rooms=[dict(id=i,bounds_mm=[0,a,1699,b]) for i,a,b in core])
 for a,b in [(5500,13000),(13800,14200)]:wall(f'CORE-E-{a}',[1599,a,1699,b])
 for y in [5500,7450,12100]:
  for x,X in [(0,450),(1250,1599)]:wall(f'CORE-H-{y}-{x}',[x,y,X,y+100])
 for y in [9350,10100]:wall(f'CORE-H-{y}',[0,y,1599,y+100])
 for id,b in [('COL-1',[1699,4050,2150,4750]),('COL-2',[8350,4999,8800,5700]),('COL-3',[8350,10950,8800,11650]),('COL-4',[1400,10600,1750,11400])]:g['columns'].append(dict(id=id,bounds_mm=b,z_mm=[0,2800]))
 for id,b in [('STORE-N1',[0,2100,2750,2200]),('STORE-N2',[3650,2100,3800,2200]),('OFFICE-W',[3700,0,3800,2500])]:wall(id,b,'new',2400)
 for id,b in [('OFFICE-G1',[3800,2450,4000,2500]),('OFFICE-G2',[4900,2450,6450,2500])]:g['glazing'].append(dict(id=id,bounds_mm=b,z_mm=[0,2400],mullion_spacing_max_mm=900,material='acoustic reeded glass'))
 def door(id,h,r,a,b,leaf,wall_id,type='flush hinged'):
  g['doors'].append(dict(id=id,hinge_mm=h,width_mm=r,arc_deg=[a,b],leaf_open_deg=leaf,wall_id=wall_id,type=type,height_mm=2400))
 door('D-01',[7950,4999],1100,90,180,90,'ENTRANCE','inward northwest quadrant glass entrance')
 door('D-02',[4000,2500],900,270,360,270,'OFFICE','acoustic glass')
 door('D-03',[3650,2100],900,180,270,270,'STORE','hidden frameless jib')
 door('D-04',[1250,5500],800,90,180,90,'PANTRY-S')
 door('D-05',[450,7450],800,0,90,90,'WC-S')
 door('D-06',[1250,12100],800,180,270,270,'WC-N')
 door('D-07',[1699,13800],800,180,270,180,'PANTRY-N')
 def obj(id,kind,b,h,zone,finish='BM-OC-17',**kw):
  g['fixtures'].append(dict(id=id,kind=kind,bounds_mm=b,z_mm=[0,h],zone=zone,finish=finish,**kw))
 obj('R-01','reception',[5400,6100,7600,6850],1050,'01','BM-OC-85')
 obj('I-01','discovery',[3800,8200,6200,9300],950,'01','BM-OC-85',description='Perfume oil and crystal flacon tester island')
 for j,(x,y) in enumerate([(4200,7800),(5700,7800),(4200,9700),(5700,9700)],1):obj(f'T-{j:02}','stool',[x-225,y-225,x+225,y+225],480,'01',upholstery='ivory boucle')
 # The first four nominal 1150 mm modules fit in the prescribed 4950 mm run.
 for j,y in enumerate([5850,7116,8383,9650,11750,12850],1):
  w=1150 if j<=4 else 1100
  obj(f'V-{j:02}','vitrine',[8300,y,8800,y+w],2400,'02','MET-01',nominal_width_mm=1150,depth_mm=500,security=dict(low_iron_glass=True,lockable=True,anchorage='Concealed base/wall restraint; engineer to detail'),lighting=dict(cct_K=3000,CRI_min=95,concealed_LED=True,dimmable=True),position_status='exact length fits supplied run' if j<=4 else '1100 mm fit option; nominal 1150 conflicts with 2200 mm run')
 for j,x in enumerate([3400,5000,6600],1):obj(f'P-{j:02}','pedestal',[x-325,11875,x+325,12525],1400,'02','MET-01',anchor_interpretation='User X/Y interpreted as centre',glass_top_height_mm=500)
 for j,y in enumerate([5900,7600,9150,11550],1):obj(f'O-{j:02}','open_shelf',[1760,y,2180,y+1300],2400,'02',description='Open tactile shelves; matte paint; gift boxes and standard perfumes')
 obj('VIP-RUG','rug',[300,2200,3650,5050],12,'03',material='woven silk wool')
 obj('VIP-SOFA','sofa',[850,2250,3250,3050],850,'03',upholstery='ivory boucle',seats=4)
 for j,(x,y) in enumerate([(1200,4450),(2700,4450)],1):obj(f'VIP-A{j}','armchair',[x-350,y-350,x+350,y+350],780,'03',upholstery='sand velvet')
 obj('VIP-T','coffee_table',[1350,3200,2750,3900],390,'03','BM-OC-85')
 obj('VIP-C','credenza',[250,2300,700,4000],800,'03','BM-OC-85')
 obj('OF-D','desk',[4450,1150,6050,1800],750,'04','BM-OC-85')
 obj('OF-C','credenza',[4200,100,6250,500],800,'04')
 obj('OF-E','task_chair',[4950,1850,5550,2350],1000,'04')
 for j,x in enumerate([4825,5675],1):obj(f'OF-V{j}','chair',[x-225,620,x+225,1020],780,'04')
 obj('S-01','rack',[100,100,3600,550],2200,'05')
 obj('S-02','rack',[100,550,550,1600],2200,'05',description='450 mm deep west stock rack; corner ends abut S-01 / S-03')
 obj('S-03','rack',[100,1600,2700,2050],2200,'05',description='North stock rack stops before hidden door')
 obj('PKG-01','packing_table',[1150,900,2250,1300],900,'05','BM-OC-85')
 # Source-informed service fixture symbols; elevations/pipework are assumptions.
 for id,y in [('PN',13450),('PS',6300)]:obj(id+'-SINK','sink',[100,y,650,y+600],900,'service')
 for id,y in [('WN',10500),('WS',8500)]:obj(id+'-WC','toilet',[350,y,1050,y+650],450,'service')
 for id,p,q in [('LT-E',[7550,5800],[7550,13600]),('LT-W',[2850,6100],[2850,13600]),('LT-VIP',[1000,3750],[3300,3750])]:g['lighting'].append(dict(id=id,start_mm=p,end_mm=q,z_mm=2650,cct_K=3000,beam_deg=24,aim='display faces',track='ceiling mounted; omitted from cutaway for visibility'))
 boundary=Polygon(g['boundary_mm']);core_poly=box(*g['service_core']['bounds_mm']);public=boundary.difference(core_poly)
 zpolys={'02':box(1699,8600,8800,14200),'03':box(250,2100,3800,5400),'04':box(3800,0,6450,2500),'05':box(0,0,3800,2100)}
 zpolys['01']=public.difference(unary_union(list(zpolys.values())))
 names={'01':'Reception, olfactory discovery and circulation','02':'Main crystal and perfume gallery','03':'VIP lounge and hospitality salon','04':'Private management office','05':'Hidden stock and packaging store'}
 for id in sorted(zpolys):
  p=zpolys[id];parts=list(p.geoms) if hasattr(p,'geoms') else [p]
  g['zones'].append(dict(id=id,name=names[id],polygons_mm=[list(map(list,q.exterior.coords)) for q in parts],area_m2=round(p.area/1e6,6),area_basis='coordinate footprint, includes furniture and partitions; excludes service core; no net-use claim'))
 g['area_reconciliation']=dict(source_label_m2=99.27,coordinate_envelope_m2=boundary.area/1e6,service_core_m2=core_poly.area/1e6,five_zone_coordinate_total_m2=public.area/1e6,difference_from_source_label_m2=round(public.area/1e6-99.27,6),source_label_status='Original raster label; cannot be reproduced from supplied boundary/core coordinates',normalization_applied=False)
 g['coordination']=[
 dict(id='C01',topic='area',detail='Boundary 113.21235 m2; less stated core 14.78130 m2 = 98.43105 m2, not 99.27. No coordinate scaling or fabricated balancing area.'),
 dict(id='C02',topic='VIP',detail='Requested sofa intersects COL-1; two armchairs overlap the table/credenza. Requested VIP bounding area is 11.715 m2, not 16.8.'),
 dict(id='C03',topic='vitrines',detail='Two 1150 mm modules exceed the 2200 mm northeast run by 100 mm. 1100 mm modules are shown as a dimensional fit candidate.'),
 dict(id='C04',topic='core shelving',detail='O-03 conflicts with COL-4; O-04 overlaps the north pantry door. Door locations reconstructed from the raster need site survey.'),
 dict(id='C05',topic='office',detail='Visitor chairs overlap the rear credenza footprint; requested desk leaves limited visitor clearance.'),
 dict(id='C06',topic='store',detail='Packing table leaves only 250/100 mm to south/north shelf faces; layout is not a verified usable storage aisle.'),
 dict(id='C07',topic='assumptions',detail='Wall thicknesses, heights, window sills, service door clearances and furniture heights are design assumptions; source is a raster plan, not a measured survey.')]
 g['fixture_schedule']=[dict(id=o['id'],kind=o['kind'],length_x_mm=o['bounds_mm'][2]-o['bounds_mm'][0],length_y_mm=o['bounds_mm'][3]-o['bounds_mm'][1],height_mm=o['z_mm'][1]-o['z_mm'][0],zone=o['zone'],finish=o['finish']) for o in g['fixtures']]
 g['design_status']='Source-coordinate reconstruction; spatial conflicts remain unresolved. No construction-readiness claim.'
 return g

if __name__=='__main__':
 g=make_geometry();(ROOT/'layout_geometry.json').write_text(json.dumps(g,indent=2)+'\n');print(g['area_reconciliation'])
