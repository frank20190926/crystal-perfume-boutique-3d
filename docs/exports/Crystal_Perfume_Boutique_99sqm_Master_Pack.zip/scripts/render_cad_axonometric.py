"""Blender native scene, built exclusively from layout_geometry.json (mm -> m)."""
import bpy, json, math, sys
from pathlib import Path
from mathutils import Vector
ROOT=Path(__file__).resolve().parents[1]
g=json.loads((ROOT/'layout_geometry.json').read_text())
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
for material in list(bpy.data.materials):bpy.data.materials.remove(material)
scene=bpy.context.scene
scene.unit_settings.system='METRIC';scene.unit_settings.length_unit='MILLIMETERS';scene.unit_settings.scale_length=1

def mat(name,color,rough=.55,metal=0,trans=0):
 color=tuple(v/12.92 if v<=.04045 else ((v+.055)/1.055)**2.4 for v in color)
 m=bpy.data.materials.new(name);m.diffuse_color=(*color,1);m.use_nodes=True;p=next(n for n in m.node_tree.nodes if n.type=='BSDF_PRINCIPLED');p.inputs['Base Color'].default_value=(*color,1);p.inputs['Roughness'].default_value=rough;p.inputs['Metallic'].default_value=metal;p.inputs['Transmission Weight'].default_value=trans
 if trans:p.inputs['IOR'].default_value=1.46
 return m

def rgb(h):return tuple(int(h[i:i+2],16)/255 for i in (1,3,5))
mats={f['code']:mat(f['name'],rgb(f['hex']),.85) for f in g['finishes']}
mats.update(dict(floor=mat('Warm neutral mineral floor',(.92,.90,.85),.7),glass=mat('Low iron display glass',(.91,.97,.94),.09,0,.94),crystal=mat('Cut crystal flacons',(.91,.95,.92),.035,0,1),bronze=mat('Satin champagne frame',(.64,.51,.30),.28,.72),fabric=mat('Ivory boucle',(.93,.90,.85),.92),velvet=mat('Sand velvet',(.87,.83,.76),.95),rug=mat('Woven silk wool',(.90,.86,.80),1),wood=mat('Carved gift box',(.38,.23,.10),.6),pearl=mat('Mother of pearl inlay',(.83,.80,.67),.28,.2),oil=mat('Amber perfume oil',(.43,.20,.055),.15,0,.35),ink=mat('Graphite',(.11,.10,.08),.5),white=mat('Porcelain',(.91,.90,.85),.25),shell=mat('Cut plaster',(.80,.78,.71),.8)))
# Subtle real procedural fibres, no external bitmaps or AI generated materials.
for key,scale,strength in [('fabric',160,.12),('velvet',220,.065),('rug',280,.18)]:
 m=mats[key];nodes=m.node_tree.nodes;noise=nodes.new('ShaderNodeTexNoise');noise.inputs['Scale'].default_value=scale;b=nodes.new('ShaderNodeBump');b.inputs['Strength'].default_value=strength;b.inputs['Distance'].default_value=.008;m.node_tree.links.new(noise.outputs['Fac'],b.inputs['Height']);m.node_tree.links.new(b.outputs['Normal'],next(n for n in nodes if n.type=='BSDF_PRINCIPLED').inputs['Normal'])
collections={}
for name in ['01_Shell','02_Service_Core','03_Fixtures','04_Products','05_Lighting','06_Cutaway','07_Full_Height_Walls','08_Labels']:
 c=bpy.data.collections.new(name);scene.collection.children.link(c);collections[name]=c
active='03_Fixtures'
def move(o,collection=None):
 for c in list(o.users_collection):c.objects.unlink(o)
 collections[collection or active].objects.link(o)

def cube(name,b,z0,z1,m,bevel=0,collection=None):
 x,y,X,Y=[v/1000 for v in b];a=z0/1000;Z=z1/1000
 bpy.ops.mesh.primitive_cube_add(size=1,location=((x+X)/2,(y+Y)/2,(a+Z)/2));o=bpy.context.object;o.name=name;o.dimensions=(X-x,Y-y,Z-a);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(m);move(o,collection)
 if bevel:
  mod=o.modifiers.new('Manufactured edge radius','BEVEL');mod.width=bevel/1000;mod.segments=3;o.modifiers.new('Weighted normals','WEIGHTED_NORMAL')
 return o

def cylinder(name,x,y,z,r,h,m,vertices=48):
 bpy.ops.mesh.primitive_cylinder_add(vertices=vertices,radius=r/1000,depth=h/1000,location=(x/1000,y/1000,(z+h/2)/1000));o=bpy.context.object;o.name=name;o.data.materials.append(m);move(o);be=o.modifiers.new('Edge radius','BEVEL');be.width=.007;be.segments=2;o.modifiers.new('Weighted normals','WEIGHTED_NORMAL');return o

def line3(name,a,b,r,material):
 a,b=Vector(a)/1000,Vector(b)/1000;v=b-a;bpy.ops.mesh.primitive_cylinder_add(vertices=12,radius=r/1000,depth=v.length,location=(a+b)/2);o=bpy.context.object;o.rotation_euler=v.to_track_quat('Z','Y').to_euler();o.name=name;o.data.materials.append(material);move(o);return o

def poly_floor(name,p,z,material):
 # Ear-clipped triangulation of the same concave polygon, no bounding-box slab.
 from mathutils.geometry import tessellate_polygon
 verts=[Vector((x/1000,y/1000,z/1000)) for x,y in p];tri=tessellate_polygon([verts]);indices=[]
 for t in tri:indices.append([v if isinstance(v,int) else min(range(len(verts)),key=lambda i:(verts[i]-v).length) for v in t])
 mesh=bpy.data.meshes.new(name);mesh.from_pydata(verts,[],indices);mesh.update();o=bpy.data.objects.new(name,mesh);collections['01_Shell'].objects.link(o);o.data.materials.append(material)
 return o
poly_floor('Exact L shaped floor',g['boundary_mm'],0,mats['floor'])
# A slim base slab preserves the concave outline.
o=poly_floor('Floor edge slab',g['boundary_mm'],-12,mats['shell']);mod=o.modifiers.new('Slab 150 mm','SOLIDIFY');mod.thickness=.15
for z in g['zones']:
 for j,p in enumerate(z['polygons_mm']):poly_floor('Zone '+z['id']+f' {j}',p,2,mats['floor'])
# Selective architectural cuts expose rooms while retaining full-height source walls.
for w in g['walls']:
 b=w['bounds_mm'];z0,z1=w['z_mm'];name=w['id'];m=mats['BM-OC-17'] if w['status']=='new' else mats['BM-OC-17']
 cut=name.startswith(('EXT-W','EXT-S','CORE-','STORE-','OFFICE-W','WW-'))
 orig=cube(name+' / full height',b,z0,z1,m,collection='07_Full_Height_Walls' if cut else '01_Shell')
 orig['source_bounds_mm']=b;orig['source_height_mm']=z1-z0
 if cut:
  orig.hide_render=True;orig.hide_set(True)
  if z0<600:cube(name+' / cut at 600 mm',b,z0,min(z1,600),m,collection='06_Cutaway')
for c in g['columns']:
 o=cube(c['id'],c['bounds_mm'],0,c['z_mm'][1],mats['BM-OC-17'],8,'01_Shell');o['source_bounds_mm']=c['bounds_mm']
for win in g['glazing']:
 b=win['bounds_mm'];x,y,X,Y=b;z0,z1=win['z_mm'];vertical=Y-y>X-x;office=win['id'].startswith('OFFICE')
 # West glass is omitted in the cutaway; true frame sill remains.
 win_collection='07_Full_Height_Walls' if win['id']=='WW' else '01_Shell'
 mid=(x+X)/2 if vertical else (y+Y)/2
 bb=[mid-5,y,mid+5,Y] if vertical else [x,mid-5,X,mid+5]
 pane=cube(win['id']+' glass',bb,z0,z1,mats['glass'],collection=win_collection)
 n=math.ceil((Y-y if vertical else X-x)/win['mullion_spacing_max_mm'])
 for i in range(n+1):
  t=i/n;bx=[x,y+(Y-y)*t-12,X,y+(Y-y)*t+12] if vertical else [x+(X-x)*t-12,y,x+(X-x)*t+12,Y];cube(win['id']+' mullion',bx,z0,z1,mats['bronze'],collection=win_collection)
 for z in [z0,z1-25]:cube(win['id']+' rail',b,z,z+25,mats['bronze'],collection=win_collection)
 if office:
  for xx in range(x+30,X,65):cube(win['id']+' reed',[xx,mid-7,xx+4,mid+7],z0,z1,mats['glass'],collection='01_Shell')
# Door leaves are open at exactly the plan angle; dimensions shared with CAD.
for d in g['doors']:
 hx,hy=d['hinge_mm'];r=d['width_mm'];angle=math.radians(d['leaf_open_deg']);end=(hx+r*math.cos(angle),hy+r*math.sin(angle));height=d['height_mm']
 cut_door=d['id'] in ['D-03','D-04','D-05','D-06','D-07']
 if abs(end[0]-hx)>abs(end[1]-hy):b=[min(hx,end[0]),hy-18,max(hx,end[0]),hy+18]
 else:b=[hx-18,min(hy,end[1]),hx+18,max(hy,end[1])]
 cube(d['id']+' full',b,0,height,mats['glass'] if d['id'] in ['D-01','D-02'] else mats['BM-OC-17'],collection='07_Full_Height_Walls' if cut_door else '01_Shell')
 if cut_door:cube(d['id']+' cut',b,0,600,mats['BM-OC-17'],collection='06_Cutaway')

def flacon(name,x,y,z,size=100):
 global active
 old=active;active='04_Products'
 cylinder(name+' crystal body',x,y,z,size*.43,size*1.35,mats['crystal'],8);cylinder(name+' oil',x,y,z+size*.15,size*.31,size*.80,mats['oil'],8);cylinder(name+' stopper',x,y,z+size*1.35,size*.28,size*.4,mats['bronze'],8);active=old

def gift(name,x,y,z,w=200,d=150,h=140):
 global active
 old=active;active='04_Products';cube(name,[x,y,x+w,y+d],z,z+h,mats['wood'],6);cube(name+' lid',[x-3,y-3,x+w+3,y+d+3],z+h-15,z+h+4,mats['pearl'],3);active=old

for o in g['fixtures']:
 id=o['id'];x,y,X,Y=o['bounds_mm'];H=o['z_mm'][1];cx=(x+X)/2;cy=(y+Y)/2;k=o['kind'];m=mats.get(o['finish'],mats['BM-OC-17'])
 if k=='rug':cube(id,[x,y,X,Y],4,H+4,mats['rug'],5)
 elif k in ['vitrine','pedestal']:
  base=260 if k=='vitrine' else H-500;top=H
  cube(id+' plinth',[x,y,X,Y],0,base,mats['BM-OC-85'],8)
  for xx in [x+18,X-18]:
   for yy in [y+18,Y-18]:cube(id+' frame',[xx-11,yy-11,xx+11,yy+11],base,top,mats['bronze'],3)
  for zz in [base,H-25]:
   for xx in [x+12,X-12]:cube(id+' rail',[xx-12,y,xx+12,Y],zz,zz+25,mats['bronze'],2)
   for yy in [y+12,Y-12]:cube(id+' rail',[x,yy-12,X,yy+12],zz,zz+25,mats['bronze'],2)
  # Glass is physically modelled as 6 mm panels.
  for xx in [x+22,X-22]:cube(id+' glass',[xx-3,y+25,xx+3,Y-25],base+25,H-25,mats['glass'])
  for yy in [y+22,Y-22]:cube(id+' glass',[x+25,yy-3,X-25,yy+3],base+25,H-25,mats['glass'])
  cube(id+' glass cap',[x+25,y+25,X-25,Y-25],H-7,H,mats['glass'])
  levels=[650,1150,1650] if k=='vitrine' else [base+20]
  for zz in levels:
   if k=='vitrine':cube(id+' shelf',[x+35,y+35,X-35,Y-35],zz-6,zz,mats['glass'])
   for j,yy in enumerate([y+(Y-y)*.28,y+(Y-y)*.70] if k=='vitrine' else [cy]):flacon(id+f' flacon {zz}-{j}',cx,yy,zz+10,130 if k=='vitrine' else 220)
  if k=='vitrine':
   # Warm concealed optical strips are real emitters.
   led=mat(id+' 3000K LED',(1,.70,.36),.4);p=next(n for n in led.node_tree.nodes if n.type=='BSDF_PRINCIPLED');p.inputs['Emission Color'].default_value=(1,.70,.36,1);p.inputs['Emission Strength'].default_value=2.5
   for yy in [y+45,Y-45]:cube(id+' LED',[x+40,yy-8,x+55,yy+8],300,H-100,led)
 elif k in ['open_shelf','rack']:
  cube(id+' base',[x,y,X,Y],0,100,m,5)
  # Open shelving has no opaque back; products remain visible across the cutaway.
  if Y-y>X-x:
   for yy in [y,Y-28]:cube(id+' side',[x,yy,X,yy+28],100,H,m,4)
  else:
   for xx in [x,X-28]:cube(id+' side',[xx,y,xx+28,Y],100,H,m,4)
  for zz in ([420,950,1480,2010,2370] if k=='open_shelf' else [450,950,1450,1950,2170]):
   cube(id+' shelf',[x,y,X,Y],zz-30,zz,m,3)
   if zz<H-170:
    if Y-y>X-x:
     for j,yy in enumerate([y+100,y+(Y-y)/2+50]):gift(id+f' box {zz}-{j}',x+75,yy,zz,220,240,170)
    else:
     for j,xx in enumerate(range(int(x+80),int(X-280),600)):gift(id+f' box {zz}-{j}',xx,y+90,zz,320,280,180)
 elif k=='sofa':
  cube(id+' base',[x,y,X,Y],100,430,mats['fabric'],90);cube(id+' back',[x,Y-220,X,Y],400,H,mats['fabric'],90)
  for xx in [x,X-180]:cube(id+' arm',[xx,y,xx+180,Y],350,720,mats['fabric'],70)
  for j in range(4):
   a=x+210+j*(X-x-420)/4;cube(id+f' seat {j}',[a,y+35,a+(X-x-420)/4-20,Y-235],410,540,mats['fabric'],65)
 elif k in ['stool','chair','task_chair','armchair']:
  r=(X-x)*.42;cylinder(id+' base',cx,cy,0,r*.68,360,mats['bronze']);cylinder(id+' seat',cx,cy,360,r,130,mats['fabric'] if k=='stool' else mats['velvet'])
  if k!='stool':cube(id+' back',[x+45,Y-140,X-45,Y-30],460,H,mats['velvet'],70)
 elif k in ['reception','discovery']:
  cube(id+' pedestal',[x+120,y+100,X-120,Y-100],0,H-70,m,45);cube(id+' counter',[x,y,X,Y],H-70,H,m,45)
  if k=='discovery':
   for j,xx in enumerate([x+200,x+850,x+1500]):
    cube(id+' tester tray',[xx,y+200,xx+480,Y-200],H,H+18,mats['bronze'],6)
    for yy in [y+360,Y-350]:flacon(id+f' tester {j}-{yy}',xx+230,yy,H+25,95)
  else:cube(id+' POS',[X-560,Y-330,X-220,Y-150],H,H+80,mats['ink'],10)
 elif k in ['coffee_table','desk','packing_table']:
  cube(id+' top',[x,y,X,Y],H-55,H,m,25)
  for xx in [x+80,X-100]:
   for yy in [y+80,Y-100]:cube(id+' leg',[xx,yy,xx+35,yy+35],0,H-50,mats['bronze'],5)
  if k=='desk':cube(id+' laptop',[cx-230,cy-100,cx+230,cy+180],H,H+20,mats['ink'],6)
 elif k=='credenza':
  cube(id,[x,y,X,Y],0,H,m,12)
  n=max(2,round((X-x)/500))
  for j in range(1,n):line3(id+' reveal',(x+j*(X-x)/n,y-1,100),(x+j*(X-x)/n,y-1,H-80),1.5,mats['bronze'])
 elif k=='sink':
  cube(id+' vanity',[x,y,X,Y],0,H,mats['BM-OC-85'],6);cube(id+' basin',[x+60,y+80,X-60,Y-80],H,H+30,mats['white'],70)
 elif k=='toilet':
  cylinder(id,cx,cy,0,250,420,mats['white']);cube(id+' cistern',[x,Y-180,X,Y],0,650,mats['white'],40)
 else:cube(id,[x,y,X,Y],0,H,m,8)
# Orthographic camera sees east vitrines, core and south rooms in one continuous space.
collections['07_Full_Height_Walls'].hide_render=True
collections['07_Full_Height_Walls'].hide_viewport=True
for ob in collections['07_Full_Height_Walls'].objects:ob.hide_set(False)
active='05_Lighting'
world=bpy.data.worlds.new('Warm white studio');scene.world=world;world.use_nodes=True;next(n for n in world.node_tree.nodes if n.type=='BACKGROUND').inputs[0].default_value=(1,.98,.94,1);next(n for n in world.node_tree.nodes if n.type=='BACKGROUND').inputs[1].default_value=.7
bpy.ops.object.light_add(type='SUN',location=(-10,-10,20));sun=bpy.context.object;sun.name='Southwest sunlight / altitude 35 degrees';alt=math.radians(35);towards=Vector((math.cos(alt)/math.sqrt(2),math.cos(alt)/math.sqrt(2),-math.sin(alt)));sun.rotation_euler=towards.to_track_quat('-Z','Y').to_euler();sun.data.energy=2;sun.data.angle=math.radians(9);move(sun)
bpy.ops.object.light_add(type='AREA',location=(3,5,15));fill=bpy.context.object;fill.name='Soft overhead studio';fill.data.energy=1600;fill.data.shape='DISK';fill.data.size=10;move(fill)
bpy.ops.object.camera_add(location=(-11,-17,27));cam=bpy.context.object;target=Vector((4.3,7.0,.9));cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=22.0;cam.data.lens=50;scene.camera=cam;move(cam,'05_Lighting')
# Add small, planar object tags to the native model, not floating UI bubbles.
active='08_Labels';font=bpy.data.fonts.load(str(ROOT/'assets/fonts/IBMPlexSans-600.ttf'))
for o in g['fixtures']:
 if o['kind'] not in ['vitrine','pedestal','open_shelf','reception','discovery']:continue
 x,y,X,Y=o['bounds_mm'];k=o['kind'];px=x-140 if k=='vitrine' else X+140 if k=='open_shelf' else (x+X)/2;py=(y+Y)/2 if k in ['vitrine','open_shelf'] else y-170
 bpy.ops.object.text_add(location=(px/1000,py/1000,.022));t=bpy.context.object;t.name='Tag '+o['id'];t.data.body=o['id'];t.data.align_x='CENTER';t.data.size=.15;t.data.font=font;t.data.materials.append(mats['ink']);move(t)
# Pure white ground receives physical southwest shadows.
active='01_Shell';ground=cube('White studio ground',[-100000,-100000,100000,100000],-180,-170,mat('White paper',(1,1,1),1));ground.is_shadow_catcher=True
scene.render.engine='CYCLES';scene.cycles.samples=48;scene.cycles.use_denoising=True;scene.cycles.max_bounces=8;scene.cycles.transmission_bounces=6
scene.render.resolution_x=2200;scene.render.resolution_y=1600;scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG';scene.render.image_settings.color_mode='RGB';scene.render.film_transparent=True
# Blender 5 compositor: shadow catcher over a pure white drawing canvas.
nt=bpy.data.node_groups.new('Architectural white canvas','CompositorNodeTree');nt.interface.new_socket(name='Image',in_out='OUTPUT',socket_type='NodeSocketColor');rl=nt.nodes.new('CompositorNodeRLayers');over=nt.nodes.new('CompositorNodeAlphaOver');over.inputs['Factor'].default_value=1;over.inputs['Background'].default_value=(16,16,16,1);out=nt.nodes.new('NodeGroupOutput');nt.links.new(rl.outputs['Image'],over.inputs['Foreground']);nt.links.new(over.outputs[0],out.inputs['Image']);scene.compositing_node_group=nt;scene.render.use_compositing=True
scene.view_settings.view_transform='AgX';scene.render.filepath='//../assets/cad_3d_axonometric.png'
scene['geometry_source']='layout_geometry.json';scene['scale']='1 Blender unit = 1 m; all source coordinates / 1000';scene['cutaway']='West, south and core walls cut to 600 mm; original full-height walls retained in collection 07 (hidden).';scene['sun_altitude_deg']=35
import hashlib
scene['geometry_sha256']=hashlib.sha256((ROOT/'layout_geometry.json').read_bytes()).hexdigest()
(ROOT/'exports/blender_validation.json').write_text(json.dumps(dict(native_scene='exports/Crystal_Perfume_Boutique_99sqm_Axonometric.blend',blender_version=bpy.app.version_string,geometry_sha256=scene['geometry_sha256'],objects=len(bpy.data.objects),fixture_ids=[o['id'] for o in g['fixtures']],source_units='mm',blender_units='m',scale=0.001,camera='ORTHO',sun_altitude_deg=35,full_height_walls_retained=True,cut_wall_height_mm=600),indent=2)+'\n')
bpy.context.preferences.filepaths.save_version=0
bpy.ops.file.pack_all()
for loaded_font in bpy.data.fonts:
 if loaded_font.filepath and loaded_font.filepath!='<builtin>':loaded_font.filepath='//../assets/fonts/'+Path(loaded_font.filepath).name
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'exports/Crystal_Perfume_Boutique_99sqm_Axonometric.blend'))
if '--preview' in sys.argv:scene.render.resolution_percentage=55;scene.cycles.samples=16;scene.render.filepath=str(ROOT/'review/axon_preview.png')
if '--no-render' not in sys.argv:bpy.ops.render.render(write_still=True)
print('NATIVE_SCENE',len(bpy.data.objects),'objects',scene.render.filepath)
