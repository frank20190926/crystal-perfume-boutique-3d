"""Crystal & Perfume Boutique (99.27 m2) - parametric Blender scene builder.

Run:
  /Applications/Blender.app/Contents/MacOS/Blender -b -P scripts/build_blender_boutique.py

Env options:
  BOUTIQUE_PREVIEW=1      quick low-res / low-sample test renders (written to review/)
  BOUTIQUE_VIEWS=1,3      render only the listed views
  BOUTIQUE_NORENDER=1     build + save .blend only

Coordinate system: metres, origin (0,0,0) = south-west interior corner,
X = east, Y = north, Z = up. Finished floor Z = 0.00, ceiling soffit Z = 3.20.
All geometry is generated from the dimensions of the employer floor plan
(brief/IMG_4951.PNG): 8 800 x 14 200, main hall 7 101 x 9 201, south wing 6 450 x 4 999.
"""

import bpy
import bmesh
import math
import os
import random
import json
from mathutils import Vector

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
EXPORTS = os.path.join(ROOT, "exports")
ASSETS = os.path.join(ROOT, "assets")
REVIEW = os.path.join(ROOT, "review")
FONT_DIR = os.path.join(ASSETS, "fonts")
BLEND_PATH = os.path.join(EXPORTS, "Crystal_Perfume_Boutique_99sqm.blend")

PREVIEW = os.environ.get("BOUTIQUE_PREVIEW") == "1"
if PREVIEW:
    BLEND_PATH = os.path.join(REVIEW, "preview_renders", "Crystal_Perfume_Boutique_Preview.blend")
NORENDER = os.environ.get("BOUTIQUE_NORENDER") == "1"
VIEWS = [int(v) for v in os.environ.get("BOUTIQUE_VIEWS", "1,2,3,4").split(",") if v.strip()]

H = 3.20          # ceiling height
WT = 0.25         # exterior wall thickness
random.seed(2801401)
GEOMETRY = json.load(open(os.path.join(ROOT, "layout_geometry.json")))

# ---------------------------------------------------------------------------
# scene reset
# ---------------------------------------------------------------------------
bpy.ops.wm.read_factory_settings(use_empty=True)
scene = bpy.context.scene
scene.name = "Boutique_99sqm"
scene.unit_settings.system = "METRIC"
scene.unit_settings.length_unit = "METERS"

COLS = {}


def coll(name, parent=None):
    if name in COLS:
        return COLS[name]
    c = bpy.data.collections.new(name)
    (parent or scene.collection).children.link(c)
    COLS[name] = c
    return c


for n in ["01_ARCH_Shell", "02_ARCH_Ceiling", "03_ARCH_Windows_Glass", "04_Curtains",
          "05_Joinery_Vitrines", "06_Vitrine_Glass", "07_Crystal_Products", "08_Furniture",
          "09_Lighting_Fixtures", "10_Lights", "11_Annotation_Plan", "12_Clay_Light", "99_Boolean_Cutters"]:
    coll(n)
COLS["99_Boolean_Cutters"].hide_render = True
COLS["99_Boolean_Cutters"].hide_viewport = True


# ---------------------------------------------------------------------------
# colour helpers
# ---------------------------------------------------------------------------
def srgb_to_lin(c):
    return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4


def hexcol(h, a=1.0):
    h = h.lstrip("#")
    return (srgb_to_lin(int(h[0:2], 16) / 255), srgb_to_lin(int(h[2:4], 16) / 255),
            srgb_to_lin(int(h[4:6], 16) / 255), a)


# ---------------------------------------------------------------------------
# materials
# ---------------------------------------------------------------------------
def set_in(node, name, val):
    if name in node.inputs:
        node.inputs[name].default_value = val


def principled(name, color, rough=0.5, metal=0.0, **kw):
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    nt = m.node_tree
    p = nt.nodes["Principled BSDF"]
    set_in(p, "Base Color", hexcol(color) if isinstance(color, str) else color)
    set_in(p, "Roughness", rough)
    set_in(p, "Metallic", metal)
    for k, v in kw.items():
        set_in(p, k.replace("_", " "), v)
    m.diffuse_color = hexcol(color) if isinstance(color, str) else color
    return m


def add_bump(m, scale, strength, distance=0.002, detail=6.0):
    nt = m.node_tree
    p = nt.nodes["Principled BSDF"]
    tc = nt.nodes.new("ShaderNodeTexCoord")
    nz = nt.nodes.new("ShaderNodeTexNoise")
    nz.inputs["Scale"].default_value = scale
    nz.inputs["Detail"].default_value = detail
    bp = nt.nodes.new("ShaderNodeBump")
    bp.inputs["Strength"].default_value = strength
    bp.inputs["Distance"].default_value = distance
    nt.links.new(tc.outputs["Object"], nz.inputs["Vector"])
    nt.links.new(nz.outputs["Fac"], bp.inputs["Height"])
    nt.links.new(bp.outputs["Normal"], p.inputs["Normal"])
    return nz


def shadow_transparent(m):
    """Keep full glass shading for camera rays, let direct-light shadow rays pass
    (standard archviz setup so internal LED light reaches lower glass shelves)."""
    nt = m.node_tree
    out = nt.nodes["Material Output"]
    p = nt.nodes["Principled BSDF"]
    lp = nt.nodes.new("ShaderNodeLightPath")
    tr = nt.nodes.new("ShaderNodeBsdfTransparent")
    mix = nt.nodes.new("ShaderNodeMixShader")
    nt.links.new(lp.outputs["Is Shadow Ray"], mix.inputs[0])
    nt.links.new(p.outputs["BSDF"], mix.inputs[1])
    nt.links.new(tr.outputs["BSDF"], mix.inputs[2])
    nt.links.new(mix.outputs[0], out.inputs["Surface"])


def emission_mat(name, kelvin, strength):
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    nt = m.node_tree
    for n in list(nt.nodes):
        nt.nodes.remove(n)
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    em = nt.nodes.new("ShaderNodeEmission")
    bb = nt.nodes.new("ShaderNodeBlackbody")
    bb.inputs["Temperature"].default_value = kelvin
    em.inputs["Strength"].default_value = strength
    nt.links.new(bb.outputs[0], em.inputs["Color"])
    nt.links.new(em.outputs[0], out.inputs["Surface"])
    m.diffuse_color = (1, 0.9, 0.7, 1)
    return m


MAT = {}
# walls & ceiling - Benjamin Moore OC-17 White Dove, matte with plaster micro-bump
MAT["wall"] = principled("PAINT_BM_OC17_White_Dove_F3EFE6", "#F3EFE6", 0.85)
add_bump(MAT["wall"], 140.0, 0.035, 0.002)
# niches, arch headers, plinths - Benjamin Moore OC-85 Pale Oak
MAT["beige"] = principled("PAINT_BM_OC85_Pale_Oak_E6DEC8", "#E6DEC8", 0.85)
add_bump(MAT["beige"], 140.0, 0.03, 0.002)
# floor - warm ivory micro-cement, low-amplitude cloud variation
MAT["floor"] = principled("Mat_Floor_Microcement", "#EAE4DA", 0.38)
_nt = MAT["floor"].node_tree
_p = _nt.nodes["Principled BSDF"]
_tc = _nt.nodes.new("ShaderNodeTexCoord")
_nz = _nt.nodes.new("ShaderNodeTexNoise")
_nz.inputs["Scale"].default_value = 0.9
_nz.inputs["Detail"].default_value = 8.0
_cr = _nt.nodes.new("ShaderNodeValToRGB")
_cr.color_ramp.elements[0].color = hexcol("#E3DCD0")
_cr.color_ramp.elements[1].color = hexcol("#EEE9E0")
_nt.links.new(_tc.outputs["Object"], _nz.inputs["Vector"])
_nt.links.new(_nz.outputs["Fac"], _cr.inputs["Fac"])
_nt.links.new(_cr.outputs["Color"], _p.inputs["Base Color"])
_rr = _nt.nodes.new("ShaderNodeMapRange")
_rr.inputs["To Min"].default_value = 0.33
_rr.inputs["To Max"].default_value = 0.45
_nt.links.new(_nz.outputs["Fac"], _rr.inputs["Value"])
_nt.links.new(_rr.outputs["Result"], _p.inputs["Roughness"])

MAT["bronze"] = principled("Mat_Champagne_Bronze", "#C5B08B", 0.26, 0.88, Anisotropic=0.35)
MAT["bronze_dark"] = principled("Mat_Bronze_Track_Satin", "#3B342B", 0.35, 0.8)
MAT["vglass"] = principled("Mat_Vitrine_Glass", "#FFFFFF", 0.02, 0.0, IOR=1.50, Transmission_Weight=0.98)
shadow_transparent(MAT["vglass"])
MAT["crystal"] = principled("Mat_Bohemia_Crystal", "#FFFFFF", 0.01, 0.0, IOR=1.545, Transmission_Weight=1.0)
MAT["oil"] = principled("Mat_Amber_Oud_Oil", "#B86B14", 0.02, 0.0, IOR=1.48, Transmission_Weight=0.92)
MAT["walnut"] = principled("Mat_GiftBox_Wood", "#5A3A24", 0.42, 0.0, Coat_Weight=0.35, Coat_Roughness=0.15)
_nt = MAT["walnut"].node_tree
_p = _nt.nodes["Principled BSDF"]
_tc = _nt.nodes.new("ShaderNodeTexCoord")
_mp = _nt.nodes.new("ShaderNodeMapping")
_mp.inputs["Scale"].default_value = (1.0, 18.0, 1.0)
_wv = _nt.nodes.new("ShaderNodeTexWave")
_wv.inputs["Scale"].default_value = 6.0
_wv.inputs["Distortion"].default_value = 9.0
_wv.inputs["Detail"].default_value = 4.0
_cr = _nt.nodes.new("ShaderNodeValToRGB")
_cr.color_ramp.elements[0].color = hexcol("#4A2E1C")
_cr.color_ramp.elements[1].color = hexcol("#6B4830")
_nt.links.new(_tc.outputs["Object"], _mp.inputs["Vector"])
_nt.links.new(_mp.outputs["Vector"], _wv.inputs["Vector"])
_nt.links.new(_wv.outputs["Fac"], _cr.inputs["Fac"])
_nt.links.new(_cr.outputs["Color"], _p.inputs["Base Color"])
MAT["pearl"] = principled("Mat_MotherOfPearl_Inlay", "#F4EFE2", 0.22, 0.0, Coat_Weight=0.6,
                          Thin_Film_Thickness=420.0, Thin_Film_IOR=1.45)
MAT["brass"] = principled("Mat_Brass_Clasp", "#C8A45C", 0.22, 1.0)
MAT["boucle"] = principled("Mat_Boucle_WarmIvory", "#EEE6D8", 0.95, 0.0, Sheen_Weight=0.6, Sheen_Roughness=0.5)
_nz = add_bump(MAT["boucle"], 420.0, 0.45, 0.004, 3.0)
MAT["rug"] = principled("Mat_Rug_Woven_Cream", "#E9E0CF", 0.98, 0.0, Sheen_Weight=0.4)
_nt = MAT["rug"].node_tree
_p = _nt.nodes["Principled BSDF"]
_tc = _nt.nodes.new("ShaderNodeTexCoord")
_wv = _nt.nodes.new("ShaderNodeTexWave")
_wv.inputs["Scale"].default_value = 90.0
_bp = _nt.nodes.new("ShaderNodeBump")
_bp.inputs["Strength"].default_value = 0.35
_nt.links.new(_tc.outputs["Object"], _wv.inputs["Vector"])
_nt.links.new(_wv.outputs["Fac"], _bp.inputs["Height"])
_nt.links.new(_bp.outputs["Normal"], _p.inputs["Normal"])
MAT["plaster_table"] = principled("Mat_Plaster_Table_Ivory", "#EFE9DE", 0.7)
add_bump(MAT["plaster_table"], 60.0, 0.06, 0.003)
MAT["linen"] = bpy.data.materials.new("Mat_Sheer_Linen")
MAT["linen"].use_nodes = True
_nt = MAT["linen"].node_tree
for _n in list(_nt.nodes):
    _nt.nodes.remove(_n)
_o = _nt.nodes.new("ShaderNodeOutputMaterial")
_tl = _nt.nodes.new("ShaderNodeBsdfTranslucent")
_tl.inputs["Color"].default_value = hexcol("#F6F0E4")
_df = _nt.nodes.new("ShaderNodeBsdfDiffuse")
_df.inputs["Color"].default_value = hexcol("#F2ECE0")
_tp = _nt.nodes.new("ShaderNodeBsdfTransparent")
_m1 = _nt.nodes.new("ShaderNodeMixShader")
_m1.inputs[0].default_value = 0.45
_m2 = _nt.nodes.new("ShaderNodeMixShader")
_m2.inputs[0].default_value = 0.42
_nt.links.new(_df.outputs[0], _m1.inputs[1])
_nt.links.new(_tl.outputs[0], _m1.inputs[2])
_nt.links.new(_m1.outputs[0], _m2.inputs[1])
_nt.links.new(_tp.outputs[0], _m2.inputs[2])
_nt.links.new(_m2.outputs[0], _o.inputs["Surface"])
MAT["linen"].diffuse_color = hexcol("#F6F0E4")
# window glass: fresnel reflection + transparent so daylight enters
MAT["wglass"] = bpy.data.materials.new("Mat_Window_Glass_LowE")
MAT["wglass"].use_nodes = True
_nt = MAT["wglass"].node_tree
for _n in list(_nt.nodes):
    _nt.nodes.remove(_n)
_o = _nt.nodes.new("ShaderNodeOutputMaterial")
_fr = _nt.nodes.new("ShaderNodeFresnel")
_fr.inputs["IOR"].default_value = 1.5
_tp = _nt.nodes.new("ShaderNodeBsdfTransparent")
_tp.inputs["Color"].default_value = (0.92, 0.95, 0.95, 1)
_gl = _nt.nodes.new("ShaderNodeBsdfGlossy")
_gl.inputs["Roughness"].default_value = 0.0
_mx = _nt.nodes.new("ShaderNodeMixShader")
_nt.links.new(_fr.outputs[0], _mx.inputs[0])
_nt.links.new(_tp.outputs[0], _mx.inputs[1])
_nt.links.new(_gl.outputs[0], _mx.inputs[2])
_nt.links.new(_mx.outputs[0], _o.inputs["Surface"])
MAT["wglass"].diffuse_color = (0.8, 0.9, 0.95, 0.3)
MAT["black_gap"] = principled("Mat_ShadowGap_Charcoal", "#2B2824", 0.6)
MAT["steel_rack"] = principled("Mat_Powdercoat_Rack_Warmgrey", "#BDB7AD", 0.45, 0.2)
MAT["carton"] = principled("Mat_Stock_Carton_Kraft", "#C9B08A", 0.85)
MAT["ceramic"] = principled("Mat_Sanitary_Ceramic", "#F7F7F4", 0.12)
MAT["chair_leather"] = principled("Mat_Office_Chair_Leather_Taupe", "#B9A58E", 0.45, Coat_Weight=0.2)
MAT["clay"] = principled("Mat_Clay_Proof", "#DCD6CC", 0.8)
MAT["clay_floor"] = principled("Mat_Clay_Proof_Floor", "#EFEBE4", 0.85)
MAT["clay_text"] = principled("Mat_Plan_Label", "#2F2B26", 0.9)
MAT["led_3000"] = emission_mat("Mat_LED_3000K", 3000, 6.0)
MAT["led_2700"] = emission_mat("Mat_LED_2700K_Cove", 2700, 9.0)
MAT["led_shelf"] = emission_mat("Mat_LED_2700K_Shelf", 2700, 5.0)
MAT["halo"] = emission_mat("Mat_Crest_Halo_3000K", 3000, 4.0)
MAT["spot_lens"] = emission_mat("Mat_Spot_Lens_3000K", 3000, 30.0)


# ---------------------------------------------------------------------------
# geometry helpers
# ---------------------------------------------------------------------------
def link(obj, cname):
    COLS[cname].objects.link(obj)
    return obj


def mesh_obj(name, verts, faces, mat, cname, smooth=False, recalc=True):
    me = bpy.data.meshes.new(name)
    me.from_pydata(verts, [], faces)
    me.update()
    if recalc:
        bm = bmesh.new()
        bm.from_mesh(me)
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
        bm.to_mesh(me)
        bm.free()
    if smooth:
        for p in me.polygons:
            p.use_smooth = True
    ob = bpy.data.objects.new(name, me)
    if mat is not None:
        if isinstance(mat, (list, tuple)):
            for m in mat:
                me.materials.append(m)
        else:
            me.materials.append(mat)
    return link(ob, cname)


def box(name, x0, x1, y0, y1, z0, z1, mat, cname="01_ARCH_Shell", bevel=0.0):
    v = [(x0, y0, z0), (x1, y0, z0), (x1, y1, z0), (x0, y1, z0),
         (x0, y0, z1), (x1, y0, z1), (x1, y1, z1), (x0, y1, z1)]
    f = [(0, 3, 2, 1), (4, 5, 6, 7), (0, 1, 5, 4), (1, 2, 6, 5), (2, 3, 7, 6), (3, 0, 4, 7)]
    ob = mesh_obj(name, v, f, mat, cname)
    if bevel > 0:
        add_bevel(ob, bevel)
    return ob


def add_bevel(ob, width, segs=2):
    md = ob.modifiers.new("Bevel", "BEVEL")
    md.width = width
    md.segments = segs
    md.limit_method = "ANGLE"
    md.harden_normals = False
    return md


def prism(name, pts, z0, z1, mat, cname, bevel=0.0, smooth=False):
    n = len(pts)
    v = [(x, y, z0) for x, y in pts] + [(x, y, z1) for x, y in pts]
    f = [tuple(reversed(range(n))), tuple(range(n, 2 * n))]
    for i in range(n):
        j = (i + 1) % n
        f.append((i, j, n + j, n + i))
    ob = mesh_obj(name, v, f, mat, cname, smooth=smooth)
    if bevel > 0:
        add_bevel(ob, bevel, 3)
    return ob


def cyl(name, cx, cy, r, z0, z1, mat, cname, seg=48, bevel=0.0, smooth=True):
    pts = [(cx + r * math.cos(2 * math.pi * i / seg), cy + r * math.sin(2 * math.pi * i / seg)) for i in range(seg)]
    ob = prism(name, pts, z0, z1, mat, cname, bevel=bevel)
    if smooth:
        auto_smooth(ob)
    return ob


def auto_smooth(ob, angle=35):
    me = ob.data
    for p in me.polygons:
        p.use_smooth = True
    try:
        me.set_sharp_from_angle(angle=math.radians(angle))
    except Exception:
        pass


def ellipse_pts(cx, cy, rx, ry, seg=72):
    return [(cx + rx * math.cos(2 * math.pi * i / seg), cy + ry * math.sin(2 * math.pi * i / seg)) for i in range(seg)]


def stadium_pts(x0, x1, y0, y1, seg=24):
    r = (y1 - y0) / 2
    cy = (y0 + y1) / 2
    pts = []
    for i in range(seg + 1):  # east cap
        a = -math.pi / 2 + math.pi * i / seg
        pts.append((x1 - r + r * math.cos(a), cy + r * math.sin(a)))
    for i in range(seg + 1):  # west cap
        a = math.pi / 2 + math.pi * i / seg
        pts.append((x0 + r + r * math.cos(a), cy + r * math.sin(a)))
    return pts


def arc_band_pts(cx, cy, r_in, r_out, a0, a1, seg=48):
    outer = [(cx + r_out * math.cos(a0 + (a1 - a0) * i / seg), cy + r_out * math.sin(a0 + (a1 - a0) * i / seg)) for i in range(seg + 1)]
    inner = [(cx + r_in * math.cos(a0 + (a1 - a0) * i / seg), cy + r_in * math.sin(a0 + (a1 - a0) * i / seg)) for i in range(seg + 1)]
    return outer + list(reversed(inner))


def lathe(name, profile, seg, mat, cname, loc=(0, 0, 0), smooth=False, rot0=0.0):
    """Solid of revolution. profile = [(r, z) or (r, z, alt)], alt=1 rotates the ring by
    half a facet -> cut-crystal diamond facets. r==0 points become poles."""
    verts, rings = [], []
    for pt in profile:
        r, z = pt[0], pt[1]
        alt = pt[2] if len(pt) > 2 else 0
        if r < 1e-6:
            rings.append([len(verts)])
            verts.append((0.0, 0.0, z))
        else:
            idx = []
            for j in range(seg):
                a = rot0 + 2 * math.pi * (j + 0.5 * alt) / seg
                idx.append(len(verts))
                verts.append((r * math.cos(a), r * math.sin(a), z))
            rings.append(idx)
    faces = []
    for a, b in zip(rings[:-1], rings[1:]):
        if len(a) == 1 and len(b) == 1:
            continue
        if len(a) == 1:
            for j in range(seg):
                faces.append((a[0], b[j], b[(j + 1) % seg]))
        elif len(b) == 1:
            for j in range(seg):
                faces.append((a[j], a[(j + 1) % seg], b[0]))
        else:
            for j in range(seg):
                k = (j + 1) % seg
                faces.append((a[j], a[k], b[j]))
                faces.append((a[k], b[k], b[j]))
    ob = mesh_obj(name, verts, faces, mat, cname, smooth=smooth)
    ob.location = loc
    return ob


def cutter(name, x0, x1, y0, y1, z0, z1, mat=None):
    ob = box(name, x0, x1, y0, y1, z0, z1, mat, "99_Boolean_Cutters")
    ob.display_type = "WIRE"
    ob.hide_render = True
    return ob


def boolean(target, cutters, name="Openings"):
    """Live (non-destructive) boolean so the handover file stays editable."""
    cc = bpy.data.collections.new(f"CUT_{target.name}")
    COLS["99_Boolean_Cutters"].children.link(cc)
    for c in cutters:
        for uc in list(c.users_collection):
            uc.objects.unlink(c)
        cc.objects.link(c)
    md = target.modifiers.new(name, "BOOLEAN")
    md.operation = "DIFFERENCE"
    md.operand_type = "COLLECTION"
    md.collection = cc
    md.solver = "EXACT"
    if hasattr(md, "material_mode"):
        md.material_mode = "TRANSFER"
    return md


def kelvin_rgb(k):
    t = k / 100.0
    r = 255 if t <= 66 else 329.698727446 * ((t - 60) ** -0.1332047592)
    g = 99.4708025861 * math.log(t) - 161.1195681661 if t <= 66 else 288.1221695283 * ((t - 60) ** -0.0755148492)
    b = 255 if t >= 66 else (0 if t <= 19 else 138.5177312231 * math.log(t - 10) - 305.0447927307)
    return tuple(srgb_to_lin(max(0, min(255, c)) / 255) for c in (r, g, b))


def light(name, ltype, loc, kelvin, energy, cname="10_Lights", aim=None, rot=None, **kw):
    ld = bpy.data.lights.new(name, ltype)
    ld.energy = energy
    if hasattr(ld, "use_temperature"):
        ld.use_temperature = True
        ld.temperature = kelvin
    else:
        ld.color = kelvin_rgb(kelvin)
    for k, v in kw.items():
        setattr(ld, k, v)
    ob = bpy.data.objects.new(name, ld)
    ob.location = loc
    if aim is not None:
        d = Vector(aim) - Vector(loc)
        ob.rotation_euler = d.to_track_quat("-Z", "Y").to_euler()
    elif rot is not None:
        ob.rotation_euler = rot
    return link(ob, cname)


# ---------------------------------------------------------------------------
# 1. ARCHITECTURAL SHELL (from employer plan IMG_4951)
# ---------------------------------------------------------------------------
# floor and ceiling slabs - L-shaped boundary + west core
OUTLINE = [(0, 0), (6.45, 0), (6.45, 5.00), (8.80, 5.00), (8.80, 14.20), (0, 14.20)]
prism("FLR_Slab_Microcement", OUTLINE, -0.20, 0.0, MAT["floor"], "01_ARCH_Shell")
ceil = prism("CLG_Slab_WhiteDove", OUTLINE, H, H + 0.20, MAT["wall"], "02_ARCH_Ceiling")

# exterior walls
w_s = box("WAL_South_SWWing", -WT, 6.45 + 0.35, -WT, 0.0, 0, H + 0.2, MAT["wall"])
w_ew = box("WAL_East_SWWing_X6450", 6.45, 6.45 + 0.35, 0.0, 5.00 - 0.25, 0, H + 0.2, MAT["wall"])
w_se = box("WAL_South_MainHall_Y5000", 6.45, 8.80 + WT, 5.00 - 0.25, 5.00, 0, H + 0.2, MAT["wall"])
w_e = box("WAL_East_MainHall_X8800", 8.80, 8.80 + WT, 5.00 - 0.25, 14.20 + WT, 0, H + 0.2, MAT["wall"])
w_n = box("WAL_North_Y14200", -WT, 8.80 + WT, 14.20, 14.20 + WT, 0, H + 0.2, MAT["wall"])
w_w = box("WAL_West_X0000", -WT, 0.0, -WT, 14.20 + WT, 0, H + 0.2, MAT["wall"])

# window and door openings (live booleans)
boolean(w_n, [cutter("CUT_N_Window", 1.85, 7.35, 14.1, 14.6, 0.15, 2.95)])
boolean(w_w, [cutter("CUT_W_Window", -0.4, 0.1, 0.90, 5.50, 0.15, 2.95)])
boolean(w_se, [cutter("CUT_Entrance", 6.85, 7.95, 4.6, 5.1, -0.1, 2.50)])
# VIP presentation niche in X=6.45 wall (facing the lounge)
boolean(w_ew, [cutter("CUT_VIP_Niche", 6.40, 6.65, 3.15, 4.35, 0.85, 2.25, MAT["beige"])])

# structural pilasters (hatched columns on plan)
for col in GEOMETRY["columns"]:
    x0, y0, x1, y1 = [v / 1000 for v in col["bounds_mm"]]
    ob = box(f"COL-{int(col['id'].split('-')[1]):02d}", x0, x1, y0, y1, 0, H, MAT["wall"])
    ob["source_bounds_mm"] = col["bounds_mm"]

# ---- west service core (existing pantries / WCs kept as-is) ----
box("WAL_Core_South_Y5500", 0.0, 2.15, 5.50, 5.65, 0, H, MAT["wall"])
for i, (y0, y1) in enumerate([(7.25, 7.35), (9.40, 9.50), (10.25, 10.35), (12.35, 12.45)]):
    w = box(f"WAL_Core_Internal_{i+1}", 0.0, 1.55, y0, y1, 0, H, MAT["wall"])
    if i in (0, 3):  # pantry -> WC doors
        boolean(w, [cutter(f"CUT_CoreDoor_{i+1}", 0.75, 1.45, y0 - 0.1, y1 + 0.1, -0.1, 2.10)])
# corridor to service shaft gets a door in the west wall run (existing)
for nm, x, y in [("WC-1", 0.35, 8.95), ("WC-2", 0.35, 10.85)]:
    box(f"FIX_{nm}_Toilet", x - 0.20, x + 0.20, y - 0.28, y + 0.10, 0, 0.42, MAT["ceramic"], "08_Furniture", 0.04)
    box(f"FIX_{nm}_Vanity", 1.05, 1.50, y - 0.25 if nm == "WC-1" else y + 0.4, y + 0.25 if nm == "WC-1" else y + 0.9, 0.80, 0.86, MAT["ceramic"], "08_Furniture", 0.01)
for nm, y0, y1 in [("PANTRY-1", 5.75, 7.15), ("PANTRY-2", 12.55, 14.10)]:
    box(f"FIX_{nm}_Counter", 0.05, 0.65, y0, y1, 0, 0.90, MAT["beige"], "08_Furniture", 0.005)

# ---- west lining wall X 1.55..2.15 with 4 recessed alcoves + flush jib door ----
lining = box("WAL_West_Lining_Shelving_X2150", 1.55, 2.15, 5.65, 14.20, 0, H, MAT["wall"])
ALCOVES = [("O-01", 6.20, 7.60, "arch"), ("O-02", 7.825, 9.225, "rect"),
           ("O-03", 10.575, 11.975, "rect"), ("O-04", 12.20, 13.60, "arch")]
JIB = (9.45, 10.35)
cuts = []
for code, y0, y1, kind in ALCOVES:
    if kind == "rect":
        cuts.append(cutter(f"CUT_{code}", 1.73, 2.30, y0, y1, 0.10, 2.55, MAT["beige"]))
    else:
        cuts.append(cutter(f"CUT_{code}_Body", 1.73, 2.30, y0, y1, 0.10, 1.85, MAT["beige"]))
        r = (y1 - y0) / 2
        pts = [((y0 + y1) / 2 + r * math.cos(math.pi * i / 32), 1.85 + r * math.sin(math.pi * i / 32) * 0.86) for i in range(33)]
        # half-elliptical arch head (rise 0.60 m), extruded along X
        v = [(1.73, y, z) for y, z in pts] + [(2.30, y, z) for y, z in pts]
        n = len(pts)
        f = [tuple(range(n)), tuple(reversed(range(n, 2 * n)))]
        for i in range(n):
            j = (i + 1) % n
            f.append((i, j, n + j, n + i))
        c = mesh_obj(f"CUT_{code}_Arch", v, f, MAT["beige"], "99_Boolean_Cutters")
        c.hide_render = True
        cuts.append(c)
# jib door shadow-gap outline (3 mm reveals) - door reads flush with the wall
g = 0.004
cuts += [cutter("CUT_Jib_L", 2.13, 2.20, JIB[0], JIB[0] + g, 0.0, 2.40, MAT["black_gap"]),
         cutter("CUT_Jib_R", 2.13, 2.20, JIB[1] - g, JIB[1], 0.0, 2.40, MAT["black_gap"]),
         cutter("CUT_Jib_T", 2.13, 2.20, JIB[0], JIB[1], 2.40 - g, 2.40, MAT["black_gap"])]
boolean(lining, cuts)
box("JIB_PushPlate_Bronze", 2.150, 2.156, JIB[0] + 0.06, JIB[0] + 0.10, 1.00, 1.30, MAT["bronze"], "05_Joinery_Vitrines")

# alcove shelves, LED strips, contents
for code, y0, y1, kind in ALCOVES:
    for k, zs in enumerate([0.55, 1.05, 1.55] + ([2.05] if kind == "rect" else [])):
        box(f"{code}_Shelf_{k+1}", 1.735, 2.13, y0 + 0.003, y1 - 0.003, zs - 0.03, zs, MAT["beige"], "05_Joinery_Vitrines", 0.003)
        box(f"{code}_LED_{k+1}", 2.09, 2.11, y0 + 0.03, y1 - 0.03, zs - 0.036, zs - 0.03, MAT["led_shelf"], "09_Lighting_Fixtures")
    box(f"{code}_Plinth", 1.735, 2.13, y0 + 0.003, y1 - 0.003, 0.10, 0.12, MAT["beige"], "05_Joinery_Vitrines")
    top = 2.43 if kind == "arch" else 2.55
    light(f"LGT_{code}_Wash", "AREA", (1.95, (y0 + y1) / 2, top - 0.04), 2700, 18.0,
          rot=(0, 0, 0), size=0.30, size_y=1.2, shape="RECTANGLE")

# ---- south wing partitions: store room (solid) and 1-person office (acoustic glass) ----
part = box("WAL_Store_Partition_Y2100", 0.0, 3.80, 2.10, 2.50, 0, H, MAT["wall"])
boolean(part, [cutter("CUT_StoreDoor_L", 0.40, 0.404, 2.45, 2.55, 0, 2.40, MAT["black_gap"]),
               cutter("CUT_StoreDoor_R", 1.296, 1.30, 2.45, 2.55, 0, 2.40, MAT["black_gap"]),
               cutter("CUT_StoreDoor_T", 0.40, 1.30, 2.45, 2.55, 2.396, 2.40, MAT["black_gap"])])
box("STORE_Door_PushPlate", 1.18, 1.22, 2.50, 2.506, 1.00, 1.30, MAT["bronze"], "05_Joinery_Vitrines")
box("WAL_Store_Office_X3800", 3.80, 3.92, 0.0, 2.50, 0, H, MAT["wall"])
# office glass partition at Y=2.30 (X 3.92..6.45), bronze frame + glass door
box("OFF_Glass_Head", 3.92, 6.45, 2.27, 2.33, 2.40, H, MAT["wall"])
box("OFF_Frame_Base", 3.92, 6.45, 2.28, 2.32, 0.0, 0.05, MAT["bronze"], "05_Joinery_Vitrines")
box("OFF_Frame_Top", 3.92, 6.45, 2.28, 2.32, 2.36, 2.40, MAT["bronze"], "05_Joinery_Vitrines")
for i, x in enumerate([3.92, 4.80, 5.45, 6.41]):
    box(f"OFF_Mullion_{i+1}", x, x + 0.04, 2.28, 2.32, 0.0, 2.40, MAT["bronze"], "05_Joinery_Vitrines")
box("OFF_Acoustic_Glass_A", 3.96, 4.80, 2.295, 2.305, 0.05, 2.36, MAT["vglass"], "06_Vitrine_Glass")
box("OFF_Acoustic_Glass_B", 4.84, 5.45, 2.295, 2.305, 0.05, 2.36, MAT["vglass"], "06_Vitrine_Glass")
box("OFF_Glass_Door", 5.49, 6.40, 2.295, 2.305, 0.05, 2.34, MAT["vglass"], "06_Vitrine_Glass")
box("OFF_Door_Pull", 5.55, 5.57, 2.31, 2.33, 0.80, 1.60, MAT["bronze"], "05_Joinery_Vitrines")

# ---------------------------------------------------------------------------
# 2. WINDOWS, ENTRANCE, CURTAINS
# ---------------------------------------------------------------------------
# north curtain wall
box("WIN_N_Glass", 1.85, 7.35, 14.27, 14.28, 0.15, 2.95, MAT["wglass"], "03_ARCH_Windows_Glass")
for i in range(6):
    x = 1.85 + i * 1.10
    box(f"WIN_N_Mullion_{i+1}", x - (0 if i == 0 else 0.025), x + (0.05 if i == 0 else 0.025) - (0.05 if i == 5 else 0), 14.20, 14.30, 0.15, 2.95, MAT["bronze"], "05_Joinery_Vitrines")
box("WIN_N_Sill", 1.85, 7.35, 14.20, 14.30, 0.15, 0.20, MAT["bronze"], "05_Joinery_Vitrines")
box("WIN_N_Head", 1.85, 7.35, 14.20, 14.30, 2.90, 2.95, MAT["bronze"], "05_Joinery_Vitrines")
box("WIN_N_Transom", 1.85, 7.35, 14.21, 14.29, 2.42, 2.45, MAT["bronze"], "05_Joinery_Vitrines")
# west curtain wall (south wing)
box("WIN_W_Glass", -0.08, -0.07, 0.90, 5.50, 0.15, 2.95, MAT["wglass"], "03_ARCH_Windows_Glass")
for i, y in enumerate([0.90, 2.05, 3.20, 4.35, 5.45]):
    box(f"WIN_W_Mullion_{i+1}", -0.10, 0.0, y, y + 0.05, 0.15, 2.95, MAT["bronze"], "05_Joinery_Vitrines")
box("WIN_W_Sill", -0.10, 0.0, 0.90, 5.50, 0.15, 0.20, MAT["bronze"], "05_Joinery_Vitrines")
box("WIN_W_Head", -0.10, 0.0, 0.90, 5.50, 2.90, 2.95, MAT["bronze"], "05_Joinery_Vitrines")
# entrance double glass door
for i, (x0, x1) in enumerate([(6.85, 7.40), (7.40, 7.95)]):
    box(f"ENT_Leaf_{i+1}_Glass", x0 + 0.03, x1 - 0.03, 4.87, 4.88, 0.03, 2.47, MAT["vglass"], "06_Vitrine_Glass")
    box(f"ENT_Leaf_{i+1}_Rail_B", x0, x1, 4.86, 4.89, 0.0, 0.10, MAT["bronze"], "05_Joinery_Vitrines")
    box(f"ENT_Leaf_{i+1}_Rail_T", x0, x1, 4.86, 4.89, 2.44, 2.50, MAT["bronze"], "05_Joinery_Vitrines")
    box(f"ENT_Leaf_{i+1}_Stile_O", x0 if i == 0 else x1 - 0.03, x0 + 0.03 if i == 0 else x1, 4.86, 4.89, 0, 2.5, MAT["bronze"], "05_Joinery_Vitrines")
    hx = x1 - 0.10 if i == 0 else x0 + 0.08
    box(f"ENT_Leaf_{i+1}_Pull", hx, hx + 0.02, 4.90, 4.93, 0.70, 1.80, MAT["bronze"], "05_Joinery_Vitrines")
    box(f"ENT_Leaf_{i+1}_PullOut", hx, hx + 0.02, 4.82, 4.85, 0.70, 1.80, MAT["bronze"], "05_Joinery_Vitrines")


def curtain(name, axis, plane, a0, a1, z0, z1, amp, wave, mat, cname="04_Curtains"):
    nu = max(8, int((a1 - a0) / wave * 8))
    nv = 2
    verts, faces = [], []
    for j in range(nv):
        z = z0 + (z1 - z0) * j / (nv - 1)
        for i in range(nu + 1):
            a = a0 + (a1 - a0) * i / nu
            off = amp * math.sin(2 * math.pi * (a - a0) / wave)
            verts.append((plane + off, a, z) if axis == "X" else (a, plane + off, z))
    for i in range(nu):
        faces.append((i, i + 1, nu + 2 + i, nu + 1 + i))
    return mesh_obj(name, verts, faces, mat, cname, smooth=True, recalc=False)


# north sheer daylight diffuser (full width) + west linen drapery panels (partly drawn)
curtain("CUR_N_Sheer_Diffuser", "Y", 14.08, 1.80, 7.40, 0.03, 3.12, 0.018, 0.22, MAT["linen"])
for i, (a0, a1) in enumerate([(0.95, 1.75), (2.95, 3.35), (4.85, 5.45)]):
    curtain(f"CUR_W_Linen_Panel_{i+1}", "X", 0.13, a0, a1, 0.02, 3.12, 0.045, 0.14, MAT["linen"])
box("CUR_W_Track", 0.08, 0.18, 0.85, 5.50, 3.12, 3.20, MAT["wall"], "04_Curtains")
box("CUR_N_Track", 1.80, 7.40, 14.03, 14.13, 3.12, 3.20, MAT["wall"], "04_Curtains")

# ---------------------------------------------------------------------------
# 3. CEILING ARCHITECTURE - perimeter cove + recessed track slots
# ---------------------------------------------------------------------------
CB = 0.55   # cove band width
cove_runs = [  # (x0,x1,y0,y1, led strip along inner edge)
    ("N", 2.15, 8.80, 14.20 - CB, 14.20, ("x", 2.15 + CB, 8.80 - CB, 14.20 - CB + 0.06)),
    ("E", 8.80 - CB, 8.80, 5.00, 14.20 - CB, ("y", 5.0 + CB, 14.20 - CB, 8.80 - CB + 0.06)),
    ("W", 2.15, 2.15 + CB, 5.65, 14.20 - CB, ("y", 5.65 + CB, 14.20 - CB, 2.15 + CB - 0.06)),
]
for nm, x0, x1, y0, y1, led in cove_runs:
    box(f"CLG_Cove_Plate_{nm}", x0, x1, y0, y1, 2.95, 3.02, MAT["wall"], "02_ARCH_Ceiling")
    if led[0] == "x":
        box(f"CLG_Cove_Lip_{nm}", led[1], led[2], y0, y0 + 0.03, 3.02, 3.09, MAT["wall"], "02_ARCH_Ceiling")
        box(f"CLG_Cove_LED_{nm}", led[1], led[2], led[3], led[3] + 0.015, 3.02, 3.03, MAT["led_2700"], "09_Lighting_Fixtures")
    else:
        lx = x0 if nm == "E" else x1 - 0.03
        box(f"CLG_Cove_Lip_{nm}", lx, lx + 0.03, led[1], led[2], 3.02, 3.09, MAT["wall"], "02_ARCH_Ceiling")
        lx2 = led[3] if nm == "E" else led[3] - 0.015
        box(f"CLG_Cove_LED_{nm}", lx2, lx2 + 0.015, led[1], led[2], 3.02, 3.03, MAT["led_2700"], "09_Lighting_Fixtures")
# south bulkhead over the entrance line (Y 5.00..5.55) closes the cove ring
box("CLG_Cove_Plate_S", 2.15, 8.25, 5.00, 5.55, 2.95, 3.02, MAT["wall"], "02_ARCH_Ceiling")
box("CLG_Cove_Lip_S", 2.70, 8.25, 5.52, 5.55, 3.02, 3.09, MAT["wall"], "02_ARCH_Ceiling")
box("CLG_Cove_LED_S", 2.70, 8.25, 5.43, 5.445, 3.02, 3.03, MAT["led_2700"], "09_Lighting_Fixtures")

SPOT_TARGETS = []  # (fixture xyz, target xyz)
TRACKS = [("TRK-1_East_Vitrines", "y", 7.45, 5.9, 13.6),
          ("TRK-2_West_Shelving", "y", 3.25, 6.0, 13.6),
          ("TRK-3_Island", "x", 8.70, 3.9, 6.1),
          ("TRK-4_Pedestals", "x", 11.55, 3.0, 7.0)]
for nm, ax, c, a0, a1 in TRACKS:
    if ax == "y":
        box(f"CLG_{nm}_Slot", c - 0.025, c + 0.025, a0, a1, H - 0.025, H, MAT["bronze_dark"], "09_Lighting_Fixtures")
    else:
        box(f"CLG_{nm}_Slot", a0, a1, c - 0.025, c + 0.025, H - 0.025, H, MAT["bronze_dark"], "09_Lighting_Fixtures")

VITRINES = [("V-01", 5.90, 7.00), ("V-02", 7.15, 8.25), ("V-03", 8.40, 9.50), ("V-04", 9.65, 10.75),
            ("V-05", 11.70, 12.80), ("V-06", 12.85, 13.95)]
for code, y0, y1 in VITRINES:
    SPOT_TARGETS.append(((7.45, (y0 + y1) / 2, H - 0.03), (8.55, (y0 + y1) / 2, 1.35), code))
for code, y0, y1, kind in ALCOVES:
    SPOT_TARGETS.append(((3.25, (y0 + y1) / 2, H - 0.03), (1.95, (y0 + y1) / 2, 1.10), code))
for x in (4.35, 5.65):
    SPOT_TARGETS.append(((x, 8.70, H - 0.03), (x, 8.70, 0.92), "ISLAND"))
PEDESTALS = [("P-01", 3.40), ("P-02", 5.00), ("P-03", 6.60)]
for code, x in PEDESTALS:
    SPOT_TARGETS.append(((x, 11.55, H - 0.03), (x, 12.30, 1.30), code))

for i, (fx, tg, code) in enumerate(SPOT_TARGETS):
    d = (Vector(tg) - Vector(fx)).normalized()
    q = d.to_track_quat("-Z", "Y")
    # spotlight body: 60 mm cylinder, 140 mm long, hanging 40 mm below slot
    body = cyl(f"SPT_{i+1:02d}_{code}_Body", 0, 0, 0.032, -0.14, 0.0, MAT["bronze_dark"], "09_Lighting_Fixtures", seg=24)
    lens = cyl(f"SPT_{i+1:02d}_{code}_Lens", 0, 0, 0.024, -0.142, -0.138, MAT["spot_lens"], "09_Lighting_Fixtures", seg=24)
    piv = Vector(fx) + Vector((0, 0, -0.06))
    for o in (body, lens):
        o.location = piv
        o.rotation_euler = q.to_euler()
    box(f"SPT_{i+1:02d}_{code}_Stem", fx[0] - 0.008, fx[0] + 0.008, fx[1] - 0.008, fx[1] + 0.008, piv.z, H - 0.02, MAT["bronze_dark"], "09_Lighting_Fixtures")
    light(f"LGT_Spot_{i+1:02d}_{code}", "SPOT", tuple(piv + d * 0.15), 3000, 55.0 if code.startswith("V") else 40.0,
          aim=tg, spot_size=math.radians(26), spot_blend=0.6, shadow_soft_size=0.03)

# ---------------------------------------------------------------------------
# 4. CRYSTAL PRODUCT GENERATORS
# ---------------------------------------------------------------------------
PROFILES = {
    # tall octagonal obelisk flacon with bevelled shoulder
    "obelisk": dict(seg=8, prof=[(0, 0), (0.026, 0), (0.030, 0.004), (0.030, 0.105), (0.026, 0.118, 1), (0.011, 0.130), (0.009, 0.142), (0.012, 0.145), (0.012, 0.152), (0, 0.152)],
                    stopper=[(0, 0), (0.008, 0), (0.020, 0.018, 1), (0.026, 0.040), (0.020, 0.062, 1), (0, 0.080)], s_seg=8),
    # round brilliant-cut flacon (alternating rings -> diamond facets)
    "brilliant": dict(seg=12, prof=[(0, 0), (0.030, 0), (0.044, 0.016, 1), (0.050, 0.040), (0.046, 0.064, 1), (0.030, 0.082), (0.011, 0.094, 1), (0.010, 0.106), (0.014, 0.109), (0, 0.112)],
                      stopper=[(0, 0), (0.007, 0), (0.024, 0.014, 1), (0.028, 0.030), (0.0, 0.058)], s_seg=12),
    # squat hexagonal flacon
    "hexa": dict(seg=6, prof=[(0, 0), (0.040, 0), (0.044, 0.006), (0.044, 0.062), (0.036, 0.072, 1), (0.010, 0.080), (0.010, 0.090), (0, 0.090)],
                 stopper=[(0, 0), (0.006, 0), (0.030, 0.010), (0.030, 0.020, 1), (0.0, 0.040)], s_seg=6),
}


def flacon(name, x, y, z, style="obelisk", scale=1.0, rot=0.0, cname="07_Crystal_Products"):
    P = PROFILES[style]
    prof = [(p[0] * scale, p[1] * scale) + tuple(p[2:]) for p in P["prof"]]
    b = lathe(f"{name}_Flacon", prof, P["seg"], MAT["crystal"], cname, loc=(x, y, z), rot0=rot)
    top = prof[-1][1]
    sp = [(p[0] * scale, p[1] * scale) + tuple(p[2:]) for p in P["stopper"]]
    s = lathe(f"{name}_Stopper", sp, P["s_seg"], MAT["crystal"], cname, loc=(x, y, z + top - 0.004 * scale), rot0=rot)
    return b, s


DEC_OUT = [(0, 0), (0.060, 0), (0.074, 0.010), (0.082, 0.040, 1), (0.086, 0.090), (0.080, 0.130, 1), (0.062, 0.165),
           (0.032, 0.200, 1), (0.020, 0.235), (0.020, 0.262), (0.026, 0.268)]
DEC_IN = [(0.016, 0.268), (0.012, 0.236), (0.024, 0.200), (0.052, 0.163), (0.070, 0.128), (0.076, 0.090), (0.072, 0.045), (0.058, 0.022), (0, 0.022)]


def decanter(name, x, y, z, scale=1.0, fill=0.11, rot=0.0, cname="07_Crystal_Products"):
    prof = [(p[0] * scale, p[1] * scale) + tuple(p[2:]) for p in DEC_OUT + DEC_IN]
    lathe(f"{name}_Decanter", prof, 16, MAT["crystal"], cname, loc=(x, y, z), rot0=rot)
    inner = sorted([(p[0], p[1]) for p in DEC_IN], key=lambda p: p[1])
    liq = [(0, inner[0][1])]
    for r, zz in inner:
        if zz <= fill:
            liq.append((r * 1.006, zz))
    # interpolate radius at fill level
    for (r0, z0), (r1, z1) in zip(inner[:-1], inner[1:]):
        if z0 <= fill <= z1:
            t = (fill - z0) / (z1 - z0)
            liq.append(((r0 + (r1 - r0) * t) * 1.006, fill))
            break
    liq.append((0, fill))
    liq = [(r * scale, zz * scale) for r, zz in liq]
    lathe(f"{name}_AmberOudOil", liq, 32, MAT["oil"], cname, loc=(x, y, z), smooth=True)
    st = [(0, 0), (0.012, 0), (0.015, 0.012), (0.036, 0.030, 1), (0.040, 0.050), (0.030, 0.072, 1), (0, 0.090)]
    st = [(p[0] * scale, p[1] * scale) + tuple(p[2:]) for p in st]
    lathe(f"{name}_Stopper", st, 12, MAT["crystal"], cname, loc=(x, y, z + 0.255 * scale), rot0=rot)


def giftbox(name, cx, cy, z, w=0.22, d=0.15, h=0.09, rot=0.0, cname="07_Crystal_Products"):
    ob = box(f"{name}_Walnut", -w / 2, w / 2, -d / 2, d / 2, 0, h, MAT["walnut"], cname, 0.003)
    parts = [ob]
    parts.append(box(f"{name}_Pearl_Inlay_1", -w / 2 + 0.02, w / 2 - 0.02, -0.012, -0.004, h, h + 0.0015, MAT["pearl"], cname))
    parts.append(box(f"{name}_Pearl_Inlay_2", -w / 2 + 0.02, w / 2 - 0.02, 0.004, 0.012, h, h + 0.0015, MAT["pearl"], cname))
    parts.append(box(f"{name}_Brass_Clasp", -0.012, 0.012, -d / 2 - 0.004, -d / 2, h - 0.03, h - 0.005, MAT["brass"], cname))
    parts.append(box(f"{name}_Lid_Line", -w / 2 - 0.0005, w / 2 + 0.0005, -d / 2 - 0.0005, d / 2 + 0.0005, h - 0.022, h - 0.020, MAT["black_gap"], cname))
    for p in parts:
        p.location = (cx, cy, z)
        p.rotation_euler = (0, 0, rot)
    return ob


# ---------------------------------------------------------------------------
# 5. EAST WALL HIGH-SECURITY VITRINES V-01..V-06
# ---------------------------------------------------------------------------
VX0, VX1 = 8.28, 8.78
styles = ["obelisk", "brilliant", "hexa"]
for vi, (code, y0, y1) in enumerate(VITRINES):
    cy = (y0 + y1) / 2
    C = "05_Joinery_Vitrines"
    box(f"{code}_Pedestal_PaleOak", VX0, VX1, y0, y1, 0.06, 0.85, MAT["beige"], C, 0.004)
    box(f"{code}_Plinth_Recess", VX0 + 0.04, VX1, y0 + 0.02, y1 - 0.02, 0.0, 0.06, MAT["black_gap"], C)
    box(f"{code}_Lock_Bronze", VX0 - 0.003, VX0, cy - 0.015, cy + 0.015, 0.74, 0.78, MAT["bronze"], C)
    box(f"{code}_Deck", VX0 + 0.01, VX1 - 0.01, y0 + 0.01, y1 - 0.01, 0.85, 0.87, MAT["beige"], C)
    box(f"{code}_Back_Panel", VX1 - 0.02, VX1, y0, y1, 0.85, 2.35, MAT["beige"], C)
    box(f"{code}_Canopy", VX0, VX1, y0, y1, 2.35, 2.45, MAT["bronze"], C, 0.002)
    box(f"{code}_LED_Top", VX0 + 0.06, VX1 - 0.06, y0 + 0.06, y1 - 0.06, 2.344, 2.35, MAT["led_3000"], "09_Lighting_Fixtures")
    box(f"{code}_LED_Base", VX0 + 0.03, VX0 + 0.045, y0 + 0.05, y1 - 0.05, 0.87, 0.876, MAT["led_3000"], "09_Lighting_Fixtures")
    # slim champagne-bronze frame (12 mm)
    t = 0.012
    for (px, py) in [(VX0, y0), (VX0, y1 - t), (VX1 - t, y0), (VX1 - t, y1 - t)]:
        box(f"{code}_Post_{px:.2f}_{py:.2f}", px, px + t, py, py + t, 0.85, 2.35, MAT["bronze"], C)
    box(f"{code}_Rail_Front_B", VX0, VX0 + t, y0, y1, 0.85, 0.87, MAT["bronze"], C)
    # glass enclosure (front + 2 sides) and 2 glass shelves
    G = "06_Vitrine_Glass"
    box(f"{code}_Glass_Front", VX0 + 0.002, VX0 + 0.010, y0 + t, y1 - t, 0.87, 2.35, MAT["vglass"], G)
    box(f"{code}_Glass_Side_S", VX0 + t, VX1 - 0.02, y0 + 0.002, y0 + 0.010, 0.87, 2.35, MAT["vglass"], G)
    box(f"{code}_Glass_Side_N", VX0 + t, VX1 - 0.02, y1 - 0.010, y1 - 0.002, 0.87, 2.35, MAT["vglass"], G)
    shelves = [1.32, 1.80]
    for k, zs in enumerate(shelves):
        box(f"{code}_Glass_Shelf_{k+1}", VX0 + 0.02, VX1 - 0.03, y0 + 0.02, y1 - 0.02, zs - 0.010, zs, MAT["vglass"], G)
        box(f"{code}_Shelf_Bracket_{k+1}", VX1 - 0.03, VX1 - 0.02, y0 + 0.02, y1 - 0.02, zs - 0.02, zs, MAT["bronze"], C)
    light(f"LGT_{code}_Internal_3000K", "AREA", (8.53, cy, 2.33), 3000, 22.0, rot=(0, 0, 0),
          shape="RECTANGLE", size=0.36, size_y=0.98)
    # products on 3 levels
    for lvl, zb in enumerate([0.87, shelves[0], shelves[1]]):
        n = 4 if lvl < 2 else 3
        for k in range(n):
            yy = y0 + 0.16 + (y1 - y0 - 0.32) * k / (n - 1)
            xx = 8.50 + (0.05 if k % 2 else -0.04)
            nm = f"{code}_L{lvl+1}_{k+1}"
            if lvl == 0 and k in (1, 2):
                decanter(nm, xx, yy, zb, scale=0.95 if k == 1 else 0.8, fill=0.12 if k == 1 else 0.09, rot=0.1 * k)
            else:
                flacon(nm, xx, yy, zb, styles[(vi + lvl + k) % 3], scale=1.0 + 0.15 * ((k + lvl) % 2), rot=0.2 * k)

# ---------------------------------------------------------------------------
# 6. NORTH WINDOW PEDESTAL VITRINES P-01..P-03
# ---------------------------------------------------------------------------
for code, x in PEDESTALS:
    y = 12.30
    C = "05_Joinery_Vitrines"
    box(f"{code}_Plinth_PaleOak", x - 0.325, x + 0.325, y - 0.325, y + 0.325, 0.05, 1.00, MAT["beige"], C, 0.004)
    box(f"{code}_Plinth_Recess", x - 0.30, x + 0.30, y - 0.30, y + 0.30, 0.0, 0.05, MAT["black_gap"], C)
    box(f"{code}_Base_Rim_Bronze", x - 0.33, x + 0.33, y - 0.33, y + 0.33, 1.00, 1.02, MAT["bronze"], C, 0.002)
    box(f"{code}_Hood_Glass", x - 0.30, x + 0.30, y - 0.30, y + 0.30, 1.02, 1.45, MAT["vglass"], "06_Vitrine_Glass")
    box(f"{code}_Hood_Cap_Bronze", x - 0.303, x + 0.303, y - 0.303, y + 0.303, 1.448, 1.452, MAT["bronze"], C)
    decanter(f"{code}_Masterpiece", x, y, 1.02, scale=1.3, fill=0.12, rot=0.3)
    flacon(f"{code}_Companion", x + 0.17, y - 0.12, 1.02, "brilliant", 0.9)

# ---------------------------------------------------------------------------
# 7. CENTRAL OLFACTORY DISCOVERY ISLAND
# ---------------------------------------------------------------------------
ISL = (3.80, 6.20, 8.15, 9.25)
prism("ISL_Body_Plaster_PaleOak", stadium_pts(ISL[0] + 0.05, ISL[1] - 0.05, ISL[2] + 0.05, ISL[3] - 0.05), 0.08, 0.86, MAT["beige"], "05_Joinery_Vitrines", bevel=0.006)
prism("ISL_Plinth_Shadow", stadium_pts(ISL[0] + 0.10, ISL[1] - 0.10, ISL[2] + 0.10, ISL[3] - 0.10), 0.0, 0.08, MAT["black_gap"], "05_Joinery_Vitrines")
prism("ISL_Top_WhiteDove", stadium_pts(*ISL), 0.86, 0.90, MAT["plaster_table"], "05_Joinery_Vitrines", bevel=0.008)
box("ISL_Brass_Testing_Tray", 4.45, 5.55, 8.55, 8.85, 0.895, 0.905, MAT["bronze"], "05_Joinery_Vitrines", 0.002)
for i in range(7):
    flacon(f"ISL_Tester_{i+1}", 4.55 + i * 0.15, 8.70 + (0.04 if i % 2 else -0.04), 0.905, styles[i % 3], 0.75 + 0.1 * (i % 2), rot=0.15 * i)
decanter("ISL_Decanter_W", 4.15, 8.45, 0.90, 0.9, 0.10)
decanter("ISL_Decanter_E", 5.88, 8.95, 0.90, 0.75, 0.13)
giftbox("ISL_GiftBox_1", 4.20, 9.00, 0.90, rot=0.12)
giftbox("ISL_GiftBox_2", 4.22, 9.02, 0.99, 0.18, 0.12, 0.07, rot=-0.10)
giftbox("ISL_GiftBox_3", 5.80, 8.42, 0.90, 0.26, 0.17, 0.10, rot=-0.06)
for i, (sx, sy) in enumerate([(4.35, 7.72), (5.65, 7.72), (4.35, 9.68), (5.65, 9.68)]):
    s = cyl(f"ISL_Stool_Boucle_{i+1}", sx, sy, 0.21, 0.02, 0.47, MAT["boucle"], "08_Furniture", seg=48, bevel=0.03)
    cyl(f"ISL_Stool_Base_{i+1}", sx, sy, 0.19, 0.0, 0.02, MAT["bronze"], "08_Furniture", seg=48)

# ---------------------------------------------------------------------------
# 8. WEST SHELVING CONTENT (gift coffers + non-fragile bottles)
# ---------------------------------------------------------------------------
for code, y0, y1, kind in ALCOVES:
    lv = [0.12, 0.55, 1.05, 1.55] + ([2.05] if kind == "rect" else [])
    for k, zb in enumerate(lv):
        if k == 0:
            giftbox(f"{code}_Coffer_Base_A", 1.94, y0 + 0.40, zb, 0.34, 0.24, 0.16, rot=math.pi / 2)
            giftbox(f"{code}_Coffer_Base_B", 1.94, y0 + 0.40, zb + 0.16, 0.30, 0.22, 0.12, rot=math.pi / 2 + 0.05)
            giftbox(f"{code}_Coffer_Base_C", 1.94, y1 - 0.40, zb, 0.34, 0.24, 0.20, rot=math.pi / 2)
            continue
        if (k + len(code)) % 2:
            giftbox(f"{code}_Coffer_{k}_A", 1.93, y0 + 0.35, zb, 0.24, 0.16, 0.09, rot=math.pi / 2 + 0.04)
            giftbox(f"{code}_Coffer_{k}_B", 1.93, y0 + 0.35, zb + 0.09, 0.20, 0.14, 0.08, rot=math.pi / 2 - 0.06)
            giftbox(f"{code}_Coffer_{k}_C", 1.93, y1 - 0.35, zb, 0.24, 0.16, 0.12, rot=math.pi / 2)
            flacon(f"{code}_Bottle_{k}", 1.95, (y0 + y1) / 2, zb, styles[k % 3], 1.0)
        else:
            for m in range(3):
                flacon(f"{code}_Bottle_{k}_{m}", 1.95, y0 + 0.30 + m * 0.40, zb, styles[(k + m) % 3], 0.95 + 0.1 * (m % 2))
            giftbox(f"{code}_Coffer_{k}_D", 1.93, y1 - 0.22, zb, 0.20, 0.14, 0.08, rot=math.pi / 2)

# ---------------------------------------------------------------------------
# 9. RECEPTION & CASHIER CONSOLE (curved, matte painted)
# ---------------------------------------------------------------------------
RC = (6.50, 3.60)
R_OUT = 3.20
a_half = math.asin(1.10 / R_OUT)
A0, A1 = math.pi / 2 - a_half, math.pi / 2 + a_half
prism("REC_Counter_Body_WhiteDove", arc_band_pts(RC[0], RC[1], R_OUT - 0.60, R_OUT - 0.04, A0, A1), 0.10, 0.92, MAT["wall"], "05_Joinery_Vitrines", bevel=0.006)
prism("REC_Counter_Plinth_Recess", arc_band_pts(RC[0], RC[1], R_OUT - 0.56, R_OUT - 0.10, A0 + 0.01, A1 - 0.01), 0.0, 0.10, MAT["black_gap"], "05_Joinery_Vitrines")
prism("REC_Counter_Top_PaleOak", arc_band_pts(RC[0], RC[1], R_OUT - 0.62, R_OUT, A0 - 0.003, A1 + 0.003), 0.92, 0.95, MAT["beige"], "05_Joinery_Vitrines", bevel=0.006)
prism("REC_Cove_LED_Toe", arc_band_pts(RC[0], RC[1], R_OUT - 0.11, R_OUT - 0.095, A0 + 0.02, A1 - 0.02), 0.005, 0.012, MAT["led_2700"], "09_Lighting_Fixtures")
prism("REC_Bronze_Reveal", arc_band_pts(RC[0], RC[1], R_OUT - 0.045, R_OUT - 0.035, A0, A1), 0.80, 0.82, MAT["bronze"], "05_Joinery_Vitrines")
decanter("REC_Decanter", 6.95, 6.62, 0.95, 0.7, 0.12)
giftbox("REC_GiftBox", 6.10, 6.55, 0.95, 0.26, 0.18, 0.10, rot=0.08)
# backlit brand crest above the entrance (north face of the header, behind the counter)
ring = cyl("REC_Crest_Bronze_Ring", 0, 0, 0.26, 0.0, 0.02, MAT["bronze"], "05_Joinery_Vitrines", seg=96)
ring.rotation_euler = (math.radians(90), 0, 0)
ring.location = (7.40, 5.02, 2.76)
boolean(ring, [cutter("CUT_Crest_Inner", -0.235, 0.235, -0.235, 0.235, -0.1, 0.1)])
halo = cyl("REC_Crest_Halo_Backlight", 0, 0, 0.24, 0.0, 0.004, MAT["halo"], "09_Lighting_Fixtures", seg=96)
halo.rotation_euler = (math.radians(90), 0, 0)
halo.location = (7.40, 5.004, 2.76)
for k in range(3):
    b = box(f"REC_Crest_Bar_{k+1}", -0.012, 0.012, 0.0, 0.03, -0.12 + k * 0.0, 0.12, MAT["bronze"], "05_Joinery_Vitrines")
    b.location = (7.40 - 0.07 + 0.07 * k, 5.0, 2.76)

# ---------------------------------------------------------------------------
# 10. VIP LOUNGE (south-west wing)
# ---------------------------------------------------------------------------
L = "08_Furniture"
prism("VIP_Rug_Woven_Cream", [(0.95, 2.70), (4.55, 2.70), (4.55, 5.00), (0.95, 5.00)], 0.0, 0.012, MAT["rug"], L, bevel=0.004)
# curved 4-seat sofa (concave to the north, 2 800 mm chord)
SC = (2.75, 2.55 + 4.0)
R = 4.0
ah = math.asin(1.40 / R)
s0, s1 = -math.pi / 2 - ah, -math.pi / 2 + ah
prism("VIP_Sofa_Base_Recess", arc_band_pts(SC[0], SC[1], R - 0.74, R - 0.06, s0 + 0.01, s1 - 0.01), 0.0, 0.10, MAT["black_gap"], L)
prism("VIP_Sofa_Seat_Boucle", arc_band_pts(SC[0], SC[1], R - 0.80, R - 0.18, s0 + 0.012, s1 - 0.012, 64), 0.10, 0.44, MAT["boucle"], L, bevel=0.05)
prism("VIP_Sofa_Back_Boucle", arc_band_pts(SC[0], SC[1], R - 0.20, R, s0, s1, 64), 0.10, 0.78, MAT["boucle"], L, bevel=0.06)
for side, (a, b) in enumerate([(s0, s0 + 0.045), (s1 - 0.045, s1)]):
    prism(f"VIP_Sofa_Arm_{side+1}", arc_band_pts(SC[0], SC[1], R - 0.84, R, a, b, 6), 0.10, 0.62, MAT["boucle"], L, bevel=0.05)
for k in range(4):  # 4 seat cushions
    a = s0 + 0.045 + (s1 - s0 - 0.09) * k / 4
    b = s0 + 0.045 + (s1 - s0 - 0.09) * (k + 1) / 4
    prism(f"VIP_Sofa_Cushion_{k+1}", arc_band_pts(SC[0], SC[1], R - 0.80, R - 0.20, a + 0.003, b - 0.003, 16), 0.44, 0.54, MAT["boucle"], L, bevel=0.045)
for o in [o for o in COLS[L].objects if o.name.startswith("VIP_Sofa")]:
    auto_smooth(o, 50)
# oval matte-plaster coffee table 1 500 x 900
prism("VIP_Table_Top_Plaster", ellipse_pts(2.95, 4.15, 0.75, 0.45), 0.34, 0.40, MAT["plaster_table"], L, bevel=0.012)
prism("VIP_Table_Pedestal_Plaster", ellipse_pts(2.95, 4.15, 0.48, 0.24), 0.0, 0.34, MAT["plaster_table"], L, bevel=0.01)
for o in ("VIP_Table_Top_Plaster", "VIP_Table_Pedestal_Plaster"):
    auto_smooth(bpy.data.objects[o], 40)
box("VIP_Tea_Tray_Bronze", 2.70, 3.10, 4.00, 4.28, 0.40, 0.415, MAT["bronze"], L, 0.003)
decanter("VIP_Decanter", 3.35, 4.12, 0.40, 1.0, 0.12)
for k in range(2):
    lathe(f"VIP_Tumbler_{k+1}", [(0, 0), (0.032, 0), (0.034, 0.006, 1), (0.036, 0.085), (0.032, 0.085), (0.030, 0.012), (0, 0.012)],
          12, MAT["crystal"], "07_Crystal_Products", loc=(2.80 + 0.17 * k, 4.12, 0.415))
giftbox("VIP_GiftBox", 2.40, 4.20, 0.40, 0.24, 0.16, 0.09, rot=0.3)


def armchair(name, cx, cy, yaw):
    parts = []
    parts.append(cyl(f"{name}_Seat", 0, 0, 0.36, 0.10, 0.42, MAT["boucle"], L, seg=64, bevel=0.05))
    back = prism(f"{name}_Back", arc_band_pts(0, 0, 0.22, 0.38, math.radians(110), math.radians(250), 32), 0.10, 0.74, MAT["boucle"], L, bevel=0.05)
    auto_smooth(back, 50)
    parts.append(back)
    parts.append(cyl(f"{name}_Plinth", 0, 0, 0.30, 0.0, 0.10, MAT["bronze"], L, seg=64))
    for p in parts:
        p.location = (cx, cy, 0)
        p.rotation_euler = (0, 0, yaw)


armchair("VIP_Armchair_W", 1.15, 4.10, math.radians(-10))   # back to window, faces east
armchair("VIP_Armchair_E", 4.40, 4.30, math.radians(190))   # faces west
# VIP presentation niche (in X=6.45 wall) - glass front, LED, flagship decanter
box("VIP_Niche_Glass", 6.452, 6.458, 3.15, 4.35, 0.85, 2.25, MAT["vglass"], "06_Vitrine_Glass")
box("VIP_Niche_Shelf", 6.46, 6.64, 3.16, 4.34, 1.20, 1.23, MAT["beige"], "05_Joinery_Vitrines")
box("VIP_Niche_LED", 6.50, 6.60, 3.20, 4.30, 2.244, 2.25, MAT["led_3000"], "09_Lighting_Fixtures")
light("LGT_VIP_Niche_3000K", "AREA", (6.55, 3.75, 2.23), 3000, 8.0, rot=(0, 0, 0), shape="RECTANGLE", size=0.15, size_y=1.1)
decanter("VIP_Niche_Decanter", 6.55, 3.60, 1.23, 1.1, 0.11)
giftbox("VIP_Niche_Coffer", 6.55, 4.00, 1.23, 0.24, 0.16, 0.10, rot=math.pi / 2)
flacon("VIP_Niche_Flacon", 6.55, 3.45, 0.85, "brilliant", 1.2)

# ---------------------------------------------------------------------------
# 11. OFFICE + STORE ROOM CONTENTS
# ---------------------------------------------------------------------------
box("OFF_Desk_Top_Walnut", 4.40, 5.90, 0.90, 1.65, 0.72, 0.76, MAT["walnut"], L, 0.004)
box("OFF_Desk_Pedestal_PaleOak", 5.40, 5.85, 0.95, 1.60, 0.0, 0.72, MAT["beige"], L, 0.004)
box("OFF_Desk_Leg_Bronze", 4.45, 4.48, 0.95, 1.60, 0.0, 0.72, MAT["bronze"], L)
box("OFF_Monitor", 4.90, 5.40, 1.50, 1.52, 0.80, 1.10, MAT["black_gap"], L, 0.003)
cyl("OFF_Chair_Seat", 5.10, 0.45, 0.26, 0.42, 0.50, MAT["chair_leather"], L, seg=48, bevel=0.02)
box("OFF_Chair_Back", 4.86, 5.34, 0.18, 0.24, 0.50, 1.05, MAT["chair_leather"], L, 0.03)
cyl("OFF_Chair_Column", 5.10, 0.45, 0.025, 0.06, 0.42, MAT["bronze"], L, seg=24)
cyl("OFF_Chair_Base", 5.10, 0.45, 0.30, 0.0, 0.06, MAT["bronze_dark"], L, seg=48)
box("OFF_Credenza_PaleOak", 3.95, 6.40, 0.05, 0.45, 0.0, 0.75, MAT["beige"], L, 0.004)
light("LGT_Office_Downlight", "AREA", (5.10, 1.20, 3.18), 3000, 60.0, rot=(0, 0, 0), shape="DISK", size=0.6)
for i, (x0, x1, y0, y1) in enumerate([(0.10, 1.80, 0.08, 0.53), (1.95, 3.65, 0.08, 0.53), (3.20, 3.75, 0.70, 1.95)]):
    for zz in (0.05, 0.60, 1.15, 1.70, 2.20):
        box(f"STO_Rack_{i+1}_Shelf_{zz:.2f}", x0, x1, y0, y1, zz, zz + 0.025, MAT["steel_rack"], L)
    for (px, py) in [(x0, y0), (x1 - 0.03, y0), (x0, y1 - 0.03), (x1 - 0.03, y1 - 0.03)]:
        box(f"STO_Rack_{i+1}_Post_{px:.2f}_{py:.2f}", px, px + 0.03, py, py + 0.03, 0.0, 2.25, MAT["steel_rack"], L)
    for zz in (0.075, 0.625, 1.175, 1.725):
        nb = int((max(x1 - x0, y1 - y0)) / 0.36)
        for b in range(nb):
            if random.random() < 0.15:
                continue
            if (x1 - x0) > (y1 - y0):
                bx = x0 + 0.04 + b * 0.36
                box(f"STO_Carton_{i+1}_{zz:.2f}_{b}", bx, bx + 0.32, y0 + 0.04, y1 - 0.04, zz, zz + 0.22 + 0.08 * random.random(),
                    MAT["carton"] if random.random() < 0.6 else MAT["walnut"], L, 0.003)
            else:
                by = y0 + 0.04 + b * 0.36
                box(f"STO_Carton_{i+1}_{zz:.2f}_{b}", x0 + 0.04, x1 - 0.04, by, by + 0.32, zz, zz + 0.22 + 0.08 * random.random(),
                    MAT["carton"], L, 0.003)
light("LGT_Store_Downlight", "AREA", (1.90, 1.05, 3.18), 4000, 45.0, rot=(0, 0, 0), shape="DISK", size=0.5)

# ---------------------------------------------------------------------------
# 12. LIGHTING - daylight portals, coves, downlights
# ---------------------------------------------------------------------------
# north daylight (5500K): large exterior area light + sky
light("LGT_North_Daylight_5500K", "AREA", (4.60, 15.6, 1.6), 5500, 2600.0,
      rot=(math.radians(90), 0, 0), shape="RECTANGLE", size=6.2, size_y=3.4)
# west afternoon sun (4800K) through the south-wing curtain wall + area portal
sun = light("LGT_West_Sun_4800K", "SUN", (-4.0, 3.2, 4.0), 4800, 1.0, aim=(1.5, 3.4, 0.0), angle=math.radians(18))
light("LGT_West_Daylight_Portal_4800K", "AREA", (-1.4, 3.2, 1.55), 4800, 900.0,
      aim=(3.0, 3.2, 1.0), shape="RECTANGLE", size=4.8, size_y=3.0)
# soft fill downlights in lounge / reception (recessed 2700K)
for i, (x, y) in enumerate([(1.4, 3.6), (2.95, 4.15), (4.4, 3.6), (6.5, 6.4), (3.0, 6.3), (5.0, 6.3)]):
    cyl(f"DLT_{i+1:02d}_Trim", x, y, 0.06, H - 0.004, H, MAT["bronze_dark"], "09_Lighting_Fixtures", seg=32)
    cyl(f"DLT_{i+1:02d}_Lens", x, y, 0.045, H - 0.006, H - 0.004, MAT["spot_lens"], "09_Lighting_Fixtures", seg=32)
    light(f"LGT_Downlight_{i+1:02d}_2700K", "SPOT", (x, y, H - 0.02), 2700, 45.0, rot=(0, 0, 0),
          spot_size=math.radians(70), spot_blend=0.8, shadow_soft_size=0.04)
# cove light boosters (mesh LEDs are tiny; long area lights give the actual 2700K bounce)
light("LGT_Cove_N_2700K", "AREA", (5.48, 13.70, 3.05), 2700, 120.0, rot=(0, 0, 0), shape="RECTANGLE", size=5.4, size_y=0.08)
light("LGT_Cove_E_2700K", "AREA", (8.29, 9.33, 3.05), 2700, 140.0, rot=(0, 0, 0), shape="RECTANGLE", size=0.08, size_y=7.9)
light("LGT_Cove_W_2700K", "AREA", (2.66, 9.65, 3.05), 2700, 140.0, rot=(0, 0, 0), shape="RECTANGLE", size=0.08, size_y=7.4)
light("LGT_Cove_S_2700K", "AREA", (5.48, 5.47, 3.05), 2700, 90.0, rot=(0, 0, 0), shape="RECTANGLE", size=5.5, size_y=0.08)
for o in [o for o in COLS["10_Lights"].objects if o.name.startswith("LGT_Cove")]:
    o.rotation_euler = (math.pi, 0, 0)  # cove LEDs face up -> wash ceiling

# Broad neutral fill: actual Cycles lights, not image brightening or relighting.
for i, (x, y, power, size) in enumerate([
    (4.9, 7.1, 500, 3.0), (5.1, 10.0, 550, 3.5),
    (5.0, 12.5, 450, 3.0), (2.9, 4.0, 500, 3.5), (5.6, 3.4, 300, 2.0)]):
    light(f"LGT_REV03_Softbox_{i+1}", "AREA", (x, y, 2.85), 4800, power,
          rot=(0, 0, 0), shape="DISK", size=size)
light("LGT_REV03_Gallery_Ceiling_Bounce", "AREA", (5.2, 8.0, 2.60), 4800, 220,
      rot=(math.pi, 0, 0), shape="DISK", size=3.0)
light("LGT_REV03_VIP_Ceiling_Bounce", "AREA", (3.1, 4.2, 2.55), 4800, 160,
      rot=(math.pi, 0, 0), shape="DISK", size=2.4)

# world sky (bright overcast daylight)
world = bpy.data.worlds.new("World_Daylight")
scene.world = world
world.use_nodes = True
bg = world.node_tree.nodes["Background"]
bg.inputs["Color"].default_value = (0.92, 0.96, 1.0, 1)
bg.inputs["Strength"].default_value = 2.0
# A white camera background for the technical cutaway; illumination is unchanged.
camera_bg = world.node_tree.nodes.new("ShaderNodeBackground")
camera_bg.name = "Cutaway_White_Background"
camera_bg.inputs["Color"].default_value = (1, 1, 1, 1)
camera_bg.inputs["Strength"].default_value = 6.0
camera_ray = world.node_tree.nodes.new("ShaderNodeLightPath")
camera_mix = world.node_tree.nodes.new("ShaderNodeMixShader")
world.node_tree.links.new(camera_ray.outputs["Is Camera Ray"], camera_mix.inputs[0])
world.node_tree.links.new(bg.outputs["Background"], camera_mix.inputs[1])
world.node_tree.links.new(camera_bg.outputs["Background"], camera_mix.inputs[2])

# ---------------------------------------------------------------------------
# 13. PLAN ANNOTATION (only visible in the clay/wire cutaway)
# ---------------------------------------------------------------------------
font_path = os.path.join(FONT_DIR, "SpaceGrotesk-600.ttf")
FNT = bpy.data.fonts.load(font_path) if os.path.exists(font_path) else None
mono_path = os.path.join(FONT_DIR, "JetBrainsMono-400.ttf")
FNT_M = bpy.data.fonts.load(mono_path) if os.path.exists(mono_path) else FNT


def label(name, text, x, y, size, font=None, rot=0.0):
    cu = bpy.data.curves.new(name, "FONT")
    cu.body = text
    cu.size = size
    cu.align_x = "CENTER"
    cu.align_y = "CENTER"
    cu.extrude = 0.004
    if font or FNT:
        cu.font = font or FNT
    ob = bpy.data.objects.new(name, cu)
    ob.location = (x, y, 0.03)
    ob.rotation_euler = (0, 0, rot)
    ob.data.materials.append(MAT["clay_text"])
    return link(ob, "11_Annotation_Plan")


label("TXT_MainGallery", "MAIN GALLERY", 5.25, 10.75, 0.46)
label("TXT_MainGallery_Dim", "7 101 x 9 201", 5.25, 10.15, 0.24, FNT_M)
label("TXT_VIP", "VIP LOUNGE", 3.40, 5.45, 0.30)
label("TXT_Office", "OFFICE", 5.15, 1.95, 0.26)
label("TXT_Store", "HIDDEN STORE", 1.55, 1.20, 0.26)
label("TXT_Core", "EXISTING PANTRY / WC", 0.80, 9.90, 0.20, rot=math.pi / 2)
label("TXT_Reception", "RECEPTION", 6.50, 7.25, 0.22)
label("TXT_Island", "DISCOVERY ISLAND", 5.00, 7.35, 0.18)
label("TXT_Area", "99.27 m2  /  8 800 x 14 200", 3.20, -0.80, 0.36)
COLS["11_Annotation_Plan"].hide_render = True

clay_sun = light("LGT_Clay_Sun", "SUN", (12, -6, 14), 5600, 3.5, cname="12_Clay_Light", aim=(4.4, 7.1, 0), angle=math.radians(4))
COLS["12_Clay_Light"].hide_render = True

# ---------------------------------------------------------------------------
# 14. CAMERAS
# ---------------------------------------------------------------------------


def camera(name, loc, target, lens, shift_y=0.0, shift_x=0.0, level=True, ortho=None):
    cd = bpy.data.cameras.new(name)
    cd.lens = lens
    cd.sensor_width = 36
    cd.shift_x, cd.shift_y = shift_x, shift_y
    cd.clip_start = 0.05
    cd.clip_end = 200
    ob = bpy.data.objects.new(name, cd)
    ob.location = loc
    d = Vector(target) - Vector(loc)
    if level:  # two-point perspective: keep verticals vertical
        d.z = 0
    ob.rotation_euler = d.to_track_quat("-Z", "Y").to_euler()
    scene.collection.objects.link(ob)
    return ob


CAMS = {
    1: camera("CAM_1_Main_Gallery_North", (3.55, 5.35, 1.50), (5.80, 12.6, 1.50), 16.0, shift_y=0.035),
    2: camera("CAM_2_VIP_Lounge_SouthWest", (6.10, 7.65, 1.50), (2.90, 3.20, 1.50), 17.0, shift_y=-0.04),
    3: camera("CAM_3_Vitrine_Closeup", (6.55, 8.15, 1.50), (8.52, 9.40, 1.50), 35.0, shift_y=0.0),
    4: camera("CAM_4_Cutaway_TopSE", (10.4, -2.6, 24.0), (4.4, 6.6, 0.0), 36.0, level=False),
}
CAM_FILES = {
    1: "blender_view1_main_gallery.jpg",
    2: "blender_view2_vip_lounge.jpg",
    3: "blender_view3_vitrine_closeup.jpg",
    4: "blender_view4_wireframe_cutaway.jpg",
}
scene.camera = CAMS[1]

# ---------------------------------------------------------------------------
# 15. RENDER SETTINGS - Cycles, Apple Metal GPU, OIDN, AgX Medium High Contrast
# ---------------------------------------------------------------------------
scene.render.engine = "CYCLES"
prefs = bpy.context.preferences.addons["cycles"].preferences
prefs.compute_device_type = "METAL"
prefs.get_devices()
for d in prefs.devices:
    d.use = (d.type == "METAL")
scene.cycles.device = "GPU"
scene.cycles.samples = 40 if PREVIEW else 256
scene.cycles.use_adaptive_sampling = True
scene.cycles.adaptive_threshold = 0.03 if PREVIEW else 0.008
scene.cycles.use_denoising = True
try:
    scene.cycles.denoiser = "OPENIMAGEDENOISE"
except Exception:
    pass
try:
    scene.cycles.denoising_use_gpu = True
except Exception:
    pass
scene.cycles.max_bounces = 24
scene.cycles.diffuse_bounces = 6
scene.cycles.glossy_bounces = 10
scene.cycles.transmission_bounces = 18
scene.cycles.transparent_max_bounces = 24
scene.cycles.caustics_reflective = True
scene.cycles.caustics_refractive = True
scene.cycles.blur_glossy = 0.6
scene.cycles.sample_clamp_indirect = 8.0
scene.cycles.light_sampling_threshold = 0.01
scene.render.resolution_x = 1920
scene.render.resolution_y = 1200
scene.render.resolution_percentage = 40 if PREVIEW else 100
scene.render.image_settings.file_format = "JPEG"
scene.render.image_settings.quality = 93
scene.render.film_transparent = False
try:
    scene.display_settings.display_device = "sRGB"
    scene.view_settings.view_transform = "AgX"
except Exception as e:
    print("view transform:", e)
for look in ("AgX - Medium High Contrast", "Medium High Contrast"):
    try:
        scene.view_settings.look = look
        break
    except Exception:
        continue
EXPOSURE = {1: -2.10, 2: -2.10, 3: -1.90, 4: -0.4}
# neutral white balance for mixed 2700-5500K sources (paint must read as off-white, not orange)
try:
    scene.view_settings.use_white_balance = True
    scene.view_settings.white_balance_temperature = 4800
except Exception as e:
    print("white balance:", e)
print("COLOR MGMT:", scene.view_settings.view_transform, "|", scene.view_settings.look)

# freestyle line settings for the cutaway proof
scene.render.line_thickness_mode = "ABSOLUTE"
scene.render.line_thickness = 1.3
vl = scene.view_layers[0]
vl.use_freestyle = True
fs = vl.freestyle_settings
if fs.linesets:
    ls = fs.linesets[0]
else:
    ls = fs.linesets.new("LineSet")
ls.select_by_visibility = True
ls.visibility = "VISIBLE"
ls.select_silhouette = True
ls.select_border = True
ls.select_crease = True
ls.select_edge_mark = False
fs.crease_angle = math.radians(140)
if ls.linestyle is None:
    ls.linestyle = bpy.data.linestyles.new("LS_Architectural_Edges")
try:
    lsty = ls.linestyle
    lsty.color = (0.16, 0.15, 0.14)
    lsty.thickness = 0.9
except Exception:
    pass
scene.render.use_freestyle = False


_SAVED_MATS = {}


def swap_clay(on):
    """Clay proof: temporarily give every modelled mesh the clay material
    (plan labels keep their dark material); restored afterwards."""
    for ob in bpy.data.objects:
        if ob.type != "MESH" or ob.name.startswith("TXT_"):
            continue
        me = ob.data
        if on:
            if me.name not in _SAVED_MATS:
                _SAVED_MATS[me.name] = list(me.materials)
            clay = MAT["clay_floor"] if ob.name.startswith("FLR_") or ob.name.startswith("VIP_Rug") else MAT["clay"]
            for k in range(len(me.materials)):
                me.materials[k] = clay
        elif me.name in _SAVED_MATS:
            for k, m in enumerate(_SAVED_MATS.pop(me.name)):
                me.materials[k] = m


def apply_view(i):
    is_clay = (i == 4)
    scene.camera = CAMS[i]
    scene.view_settings.exposure = EXPOSURE[i]
    swap_clay(is_clay)
    scene.view_settings.use_white_balance = not is_clay
    scene.render.use_freestyle = is_clay
    for cname in ("02_ARCH_Ceiling", "03_ARCH_Windows_Glass", "04_Curtains", "06_Vitrine_Glass"):
        COLS[cname].hide_render = is_clay
    COLS["11_Annotation_Plan"].hide_render = not is_clay
    COLS["12_Clay_Light"].hide_render = not is_clay
    COLS["10_Lights"].hide_render = is_clay
    world.node_tree.nodes["Background"].inputs["Strength"].default_value = 1.2 if is_clay else 2.0
    world.node_tree.links.new(camera_mix.outputs[0] if is_clay else bg.outputs["Background"],
                              world.node_tree.nodes["World Output"].inputs["Surface"])
    # cove/LED/spot emission meshes stay; with the override they become clay


# save editable source file (with camera 1 active)
os.makedirs(EXPORTS, exist_ok=True)
os.makedirs(ASSETS, exist_ok=True)
os.makedirs(os.path.dirname(BLEND_PATH), exist_ok=True)
apply_view(1)
try:
    bpy.ops.file.pack_all()
except Exception as e:
    print("pack:", e)
bpy.context.preferences.filepaths.save_version = 0
bpy.ops.wm.save_as_mainfile(filepath=BLEND_PATH, compress=True)
print("SAVED", BLEND_PATH)
n_obj = len([o for o in bpy.data.objects if o.type == "MESH" and not o.users_collection[0].name.startswith("CUT")
             and o.users_collection[0].name != "99_Boolean_Cutters"])
print("MESH OBJECTS:", n_obj, "| LIGHTS:", len([o for o in bpy.data.objects if o.type == "LIGHT"]))

if not NORENDER:
    out_dir = os.path.join(REVIEW, "preview_renders") if PREVIEW else ASSETS
    os.makedirs(out_dir, exist_ok=True)
    for i in VIEWS:
        apply_view(i)
        scene.render.filepath = os.path.join(out_dir, CAM_FILES[i])
        bpy.ops.render.render(write_still=True)
        print("RENDERED", scene.render.filepath)
    apply_view(1)
    bpy.ops.wm.save_as_mainfile(filepath=BLEND_PATH, compress=True)
    print("RESAVED", BLEND_PATH)
