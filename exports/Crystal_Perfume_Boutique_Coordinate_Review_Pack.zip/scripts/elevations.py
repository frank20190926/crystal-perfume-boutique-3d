"""Orthographic interior elevations derived from the millimetre fixture model."""
from drawing import Scene,ROOT,INK,MUTED,BRONZE

def bottle(s,x,z,w=100,h=210,layer='vitrine'):
 s.rect([x-w/2,z,x+w/2,z+h*.74],layer=layer,fill='#f4eee0',lw=.55);s.rect([x-w*.27,z+h*.74,x+w*.27,z+h],layer=layer,fill='#c6b189',lw=.5)

def cabinet(s,o,a,z=0):
 b=o['bounds_mm'];w=b[3]-b[1];H=o['z_mm'][1];kind=o['kind'];layer='vitrine' if kind=='vitrine' else 'shelf'
 s.rect([a,z,a+w,z+H],layer=layer,fill='#eee9dd',lw=.9)
 if kind=='vitrine':
  s.rect([a+35,z+300,a+w-35,z+H-100],layer=layer,fill='#f7f6ee',lw=.55,color=BRONZE)
  s.rect([a,z,a+w,z+260],layer=layer,fill='#bda785',lw=.6)
  s.line((a+w/2,z+300),(a+w/2,z+H-100),layer,.4,BRONZE)
  for side in [55,w-55]:s.line((a+side,z+320),(a+side,z+H-140),'light',1.2,'#c1a363')
  for zz in [650,1150,1650]:
   s.line((a+40,z+zz),(a+w-40,z+zz),layer,.45,'#958d7b')
   for j,xx in enumerate([a+w*.25,a+w*.7]):bottle(s,xx,z+zz+15,110 if j else 150,230 if j else 280)
  s.ellipse((a+w*.55,z+1080),36,36,layer,fill=BRONZE,lw=.4)
  # Downward optical light path drawn as thin amber rays.
  for xx in [a+w*.25,a+w*.75]:
   s.poly([(xx-95,z+H-140),(xx+95,z+H-140),(xx+240,z+H-820),(xx-240,z+H-820)],layer='light',fill='#f4eddc',lw=0)
   s.line((xx,z+H-120),(xx,z+H-550),'light',.4,'#a58b56')
   s.poly([(xx,z+H-580),(xx-25,z+H-520),(xx+25,z+H-520)],layer='light',fill='#a58b56',lw=.2)
 else:
  s.rect([a+45,z+140,a+w-45,z+H-100],layer=layer,fill='#f9f6ee',lw=.55)
  for k,zz in enumerate([420,950,1480,2010]):
   s.rect([a+45,z+zz-35,a+w-45,z+zz],layer=layer,fill='#d2c6b2',lw=.5)
   if k%2==0:
    for j,xx in enumerate([a+180,a+650,a+1050]):
     s.rect([xx,z+zz,xx+230,z+zz+210],layer=layer,fill='#b59d7b' if j!=1 else '#d4c5a9',lw=.4);s.line((xx,z+zz+160),(xx+230,z+zz+160),layer,.3)
   else:
    for xx in [a+250,a+600,a+950]:bottle(s,xx,z+zz+5,120,210,'shelf')
 s.text((a+w/2,z+H+(180 if kind=='vitrine' else 600)),o['id'],135,font='bold')
 s.dim((a,z),(a+w,z),z-200,h=105)

def elevation(g,side):
 s=Scene();H=g['height_assumptions_mm']['enclosure']
 if side=='East':
  L=9201;s.rect([0,0,L,H],fill='#fcfaf5',lw=.55)
  for c in g['columns']:
   if c['id'] not in ['COL-2','COL-3']:continue
   x=c['bounds_mm'][1]-4999;w=c['bounds_mm'][3]-c['bounds_mm'][1];s.rect([x,0,x+w,H],layer='column',fill='#c6c0b4',lw=.7,hatch='//')
  for o in g['fixtures']:
   if o['kind']=='vitrine':cabinet(s,o,o['bounds_mm'][1]-4999)
  s.dim((0,H),(L,H),H+480,h=130)
  s.dim((0,0),(0,2400),-300,axis='y',h=105)
  s.text((0,H+800),'A   EAST / HIGH-SECURITY VITRINES',185,font='title',align='left')
  s.text((L,-480),'SOUTH  →  NORTH',110,align='right',font='mono')
 elif side=='West':
  L=8700;s.rect([0,0,L,H],fill='#f7f4ee',lw=.55)
  # North appears at left when looking west.
  for o in g['fixtures']:
   if o['kind']=='open_shelf':cabinet(s,o,14200-o['bounds_mm'][3])
  for d in g['doors']:
   if d['id']=='D-07':
    a=14200-d['hinge_mm'][1];s.rect([a,0,a+d['width_mm'],2400],layer='door',lw=.6);s.line((a+100,1100),(a+100,1250),'door',1)
  c=next(c for c in g['columns'] if c['id']=='COL-4');s.rect([14200-c['bounds_mm'][3],0,14200-c['bounds_mm'][1],H],layer='column',fill='#bcb6aa',hatch='//',lw=.65)
  a=14200-10100;s.rect([a,0,a+750,2200],layer='door',fill='#e8e3d9',lw=.5);s.text((a+375,1100),'SERVICE',100,rotation=90)
  s.dim((0,H),(L,H),H+480,h=130);s.dim((L,0),(L,2400),L+280,axis='y',h=105)
  s.text((0,H+800),'B   WEST / OPEN DISPLAY + SERVICE CORE',185,font='title',align='left');s.text((L,-480),'NORTH  →  SOUTH',110,align='right',font='mono')
 else:
  L=6450;s.rect([0,0,L,H],fill='#fcfaf5',lw=.55)
  s.rect([0,0,3800,2400],layer='new',fill='#e4e0d8',lw=.8)
  s.rect([2750,0,3650,2400],layer='door',lw=.5)
  s.line((2790,1050),(2790,1250),'door',.8)
  for a,b in [(3800,4000),(4900,6450)]:
   s.rect([a,0,b,2400],layer='glass',fill='#f2f0e8',lw=.6)
   for xx in range(a+25,b,65):s.line((xx,0),(xx,2400),'glass',.18,'#c6bda9')
  s.rect([4000,0,4900,2400],layer='door',lw=.7);s.line((4780,1000),(4780,1300),'door',1)
  sofa=next(o for o in g['fixtures'] if o['id']=='VIP-SOFA');x,y,X,Y=sofa['bounds_mm'];z=sofa['z_mm'][1]
  s.rect([x,90,X,z],layer='vip',fill='#e8ddcb',lw=.8)
  for j in range(4):s.rect([x+200+j*(X-x-400)/4,120,x+200+(j+1)*(X-x-400)/4-30,540],layer='vip',fill='#f4eddf',lw=.5)
  for a in [x+50,X-200]:s.rect([a,120,a+150,710],layer='vip',fill='#dfd0b9',lw=.5)
  # Actual column silhouette remains in its surveyed location.
  col=next(c for c in g['columns'] if c['id']=='COL-1');s.rect([col['bounds_mm'][0],0,col['bounds_mm'][2],H],layer='column',fill='#bdb6a9',hatch='//',lw=.7)
  s.dim((0,H),(3800,H),H+400,h=120);s.dim((3800,H),(6450,H),H+400,h=120)
  s.dim((6450,0),(6450,2400),6750,axis='y',h=105)
  s.dim((2750,0),(3650,0),-240,h=100);s.dim((4000,0),(4900,0),-240,h=100)
  s.text((0,H+800),'C   SOUTH / VIP + OFFICE + HIDDEN STORE',185,font='title',align='left')
  s.text((950,2070),'MATTE PAINT',110);s.text((5450,2550),'ACOUSTIC GLASS',110);s.text((L,-480),'WEST  →  EAST',110,align='right',font='mono')
 return s

def shift(s,dx,dy):
 out=Scene()
 for obj in s.items:
  i=dict(obj);k=i['kind']
  if k=='poly':i['p']=[(p[0]+dx,p[1]+dy) for p in i['p']]
  else:
   for key in ['p','c','a','b']:
    if key in i and isinstance(i[key],(tuple,list)):i[key]=(i[key][0]+dx,i[key][1]+dy)
   if k=='dim':i['offset']+=dy if i['axis']=='x' else dx
  out.items.append(i)
 return out

def elevations_sheet(g):
 s=Scene()
 for side,dy in [('East',8500),('West',4250),('South',0)]:s.items+=shift(elevation(g,side),0,dy).items
 # Technical light section at right, a proper section drawing instead of UI cards.
 s.text((10900,12000),'VITRINE / SECTION',170,font='title',align='left')
 s.rect([11000,9000,11500,11400],layer='vitrine',fill='#f4f0e6',lw=.7)
 s.rect([11000,9000,11500,9260],layer='vitrine',fill='#bda785',lw=.55)
 s.line((11020,9300),(11020,11350),'glass',.6);s.line((11040,9300),(11040,11350),'glass',.3)
 for z in [9650,10150,10650]:s.line((11030,z),(11460,z),'vitrine',.5)
 s.ellipse((11230,11280),65,35,'light',fill=BRONZE,lw=.4)
 s.poly([(11230,11260),(10980,10400),(11480,10400)],layer='light',fill='#f2e7cb',lw=0)
 s.line((11230,11260),(11230,10550),'light',.5,BRONZE)
 s.dim((11000,9000),(11500,9000),8800,h=110)
 s.leader((11230,11280),(11700,11400),(12200,11400),'3000 K / CRI ≥95\nDIMMABLE LED',115)
 s.leader((11030,10200),(11700,10000),(12200,10000),'LOW-IRON GLASS\nLOCKABLE DOOR',115)
 s.leader((11250,9150),(11700,9300),(12200,9300),'CONCEALED\nBASE ANCHORAGE',115)
 s.text((10900,8050),'PAINT + HARDWARE',170,font='title',align='left')
 for j,f in enumerate(g['finishes']):
  y=7550-j*600;s.rect([10900,y-160,11200,y+140],fill=f['hex'],lw=.4)
  s.text((11400,y+50),f['name'].replace('Benjamin Moore ','').replace('Satin Champagne Bronze','Champagne Bronze'),135,align='left',font='bold');s.text((11400,y-160),f['hex']+' / '+('SATIN METAL' if j==3 else 'MATTE PAINT'),110,align='left',font='mono')
 s.text((10900,4250),'DISPLAY SCHEDULE / mm',170,font='title',align='left')
 for j,tx in enumerate(['V-01–04   1150 × 500 × 2400','V-05–06   1100 × 500 × 2400','P-01–03    650 × 650 × 1400','O-01–04   1400 × 420 × 2400','I-01      2400 × 1100 × 950','R-01      2200 × 750 × 1050']):s.text((10900,3800-j*330),tx,115,align='left',font='mono')
 s.text((10900,1050),'HEIGHT DATUM +0.000',130,align='left',font='bold');s.text((10900,730),'Ceiling +2.800 m / display +2.400 m',110,align='left');s.text((10900,420),'Painted joinery; no stone or wall veneers.',110,align='left')
 return s
