"""Independent geometric/file checks; spatial conflicts are reported, never passed."""
import json,math,hashlib
from pathlib import Path
from itertools import combinations
from collections import Counter
from shapely.geometry import Polygon,box
from shapely.ops import unary_union
from PIL import Image
import ezdxf
ROOT=Path(__file__).resolve().parents[1]
g=json.loads((ROOT/'layout_geometry.json').read_text());checks=[]
def check(name,value,detail=None):
 checks.append(dict(check=name,passed=bool(value),detail=detail));assert value,(name,detail)
p=Polygon(g['boundary_mm']);core=box(*g['service_core']['bounds_mm']);public=p.difference(core)
check('exact exterior coordinate polygon',g['boundary_mm']==[[0,0],[6450,0],[6450,4999],[8800,4999],[8800,14200],[0,14200]])
check('coordinate envelope area',abs(p.area/1e6-113.21235)<1e-8)
zps=[unary_union([Polygon(part) for part in z['polygons_mm']]) for z in g['zones']]
check('five zones partition public footprint without overlap',abs(sum(z.area for z in zps)-unary_union(zps).area)<1e-6 and public.symmetric_difference(unary_union(zps)).area<1e-6)
check('source 99.27 label preserved without normalization',g['area_reconciliation']['source_label_m2']==99.27 and not g['area_reconciliation']['normalization_applied'])
for o in g['fixtures']:check('fixture inside source boundary: '+o['id'],p.covers(box(*o['bounds_mm'])))
counts=Counter(o['kind'] for o in g['fixtures']);check('requested fixture quantities',counts['vitrine']==6 and counts['pedestal']==3 and counts['open_shelf']==4 and counts['stool']==4 and counts['rack']==3,dict(counts))
d=ezdxf.readfile(ROOT/'exports/Crystal_Perfume_Boutique_99sqm.dxf');a=d.audit();check('R2010 DXF / millimetres',d.dxfversion=='AC1024' and d.units==4);check('DXF reopened without audit errors or fixes',not a.errors and not a.fixes)
required=['A-WALL-EXIST','A-WALL-NEW','A-COLS','A-GLAZ','A-DOOR','A-FURN-VIP','A-VITRINE-SEC','A-SHELF-OPEN','A-STOR-RACK','A-LIGHT-TRACK','A-DIMS-MM','A-ANNO-TEXT'];check('all 12 required CAD layers',all(x in d.layers for x in required))
values=[round(e.get_measurement(),3) for e in d.modelspace().query('DIMENSION')];check('original source dimensions are native dimensions',all(v in values for v in [7101,9201,4999,6450]),values)
polys=[list(e.get_points('xy')) for e in d.modelspace().query('LWPOLYLINE')]
check('CAD source boundary remains at 0,0 without offset or scale',any(Polygon(q).equals(p) for q in polys if len(q)>=3))
for c in g['columns']:check('CAD column coordinate footprint: '+c['id'],any(Polygon(q).equals(box(*c['bounds_mm'])) for q in polys if len(q)>=3))
text=' '.join(e.dxf.text for e in d.modelspace().query('TEXT'))
check('no internal hold or promotional text in drawings',not any(w in text.upper() for w in ['QA HOLD','MAXIMIZED','UNLEASH','GAME-CHANGER','100% COMPLIANT','RELOCATED']))
conv=json.loads((ROOT/'exports/dwg_validation.json').read_text());check('DWG roundtrip retains geometry and mm units',not conv['modelspace_differences'] and not conv['block_differences'] and conv['roundtrip_units']==4 and conv['roundtrip_audit_errors']==0)
check('DWG is a native binary, not a renamed DXF',(ROOT/'exports/Crystal_Perfume_Boutique_99sqm.dwg').read_bytes()[:6]==b'AC1015')
for name,size in [('cad_floorplan_99sqm.png',(2200,2800)),('cad_3d_axonometric.png',(2200,1600)),('cad_elevations_vitrines.png',(2400,1500))]:
 with Image.open(ROOT/'assets'/name) as im:check('exact raster size: '+name,im.size==size,str(im.size));im.verify()
blend=json.loads((ROOT/'exports/blender_validation.json').read_text());check('Blender scene built from the current geometry hash',blend['geometry_sha256']==hashlib.sha256((ROOT/'layout_geometry.json').read_bytes()).hexdigest());check('Blender orthographic + 35 degree light',blend['camera']=='ORTHO' and blend['sun_altitude_deg']==35)
# Collision evidence is a separate result from file-integrity checks.
collisions=[]
fixed=[o for o in g['fixtures'] if o['kind'] not in ['rug','sink','toilet']]
for o in fixed:
 for c in g['columns']:
  area=box(*o['bounds_mm']).intersection(box(*c['bounds_mm'])).area
  if area>1:collisions.append(dict(a=o['id'],b=c['id'],kind='fixture/structure',overlap_m2=round(area/1e6,6)))
for a,b in combinations(fixed,2):
 area=box(*a['bounds_mm']).intersection(box(*b['bounds_mm'])).area
 if area>1:collisions.append(dict(a=a['id'],b=b['id'],kind='fixture/fixture bounding footprints',overlap_m2=round(area/1e6,6)))
report=dict(file_integrity_checks=checks,passed=len(checks),geometry_design_status='unresolved_source_layout_conflicts',measured_zone_total_m2=sum(z.area for z in zps)/1e6,source_label_m2=99.27,collisions=collisions,additional_coordination=g['coordination'],auto_adjustments=False)
(ROOT/'exports/verification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(file_integrity_checks_passed=len(checks),spatial_collisions=len(collisions),collisions=collisions),indent=2))
