"""Shared architectural vector primitives for PNG and R2010 DXF."""
import math
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon, Ellipse, Arc
from matplotlib.font_manager import FontProperties
ROOT=Path(__file__).resolve().parents[1]
INK='#353129';MUTED='#6b6255';BRONZE='#b49a6e';GLASS='#e7e5dc'
FONTS={k:FontProperties(fname=str(ROOT/'assets/fonts'/v)) for k,v in {'title':'SpaceGrotesk-600.ttf','body':'IBMPlexSans-400.ttf','bold':'IBMPlexSans-600.ttf','mono':'JetBrainsMono-400.ttf'}.items()}
LAYERS={'wall':'A-WALL-EXIST','new':'A-WALL-NEW','column':'A-COLS','glass':'A-GLAZ','door':'A-DOOR','vip':'A-FURN-VIP','vitrine':'A-VITRINE-SEC','shelf':'A-SHELF-OPEN','rack':'A-STOR-RACK','light':'A-LIGHT-TRACK','dim':'A-DIMS-MM','text':'A-ANNO-TEXT','furn':'A-FURN-GEN','floor':'A-FLOOR-ZONE','service':'A-FIXT-SERVICE','elev':'A-ELEVATION'}
class Scene:
 def __init__(self):self.items=[]
 def line(self,a,b,layer='elev',lw=.65,color=INK,dash=False):self.items.append(dict(kind='line',a=a,b=b,layer=layer,lw=lw,color=color,dash=dash))
 def poly(self,p,layer='elev',fill=None,lw=.7,hatch=None,color=INK,dash=False):self.items.append(dict(kind='poly',p=p,layer=layer,fill=fill,lw=lw,hatch=hatch,color=color,dash=dash))
 def rect(self,b,**kw):
  x,y,X,Y=b;self.poly([(x,y),(X,y),(X,Y),(x,Y)],**kw)
 def text(self,p,s,h=120,layer='text',align='center',font='body',rotation=0,color=INK):self.items.append(dict(kind='text',p=p,s=s,h=h,layer=layer,align=align,font=font,rotation=rotation,color=color))
 def ellipse(self,c,w,h,layer='furn',fill='white',lw=.7,color=INK):self.items.append(dict(kind='ellipse',c=c,w=w,h=h,layer=layer,fill=fill,lw=lw,color=color))
 def arc(self,c,r,a,b,layer='door',lw=.55):self.items.append(dict(kind='arc',c=c,r=r,a=a,b=b,layer=layer,lw=lw,color=INK))
 def dim(self,a,b,offset,axis='x',h=110):self.items.append(dict(kind='dim',a=a,b=b,offset=offset,axis=axis,h=h,layer='dim'))
 def leader(self,p,elbow,end,label,h=115,align='left'):
  self.line(p,elbow,lw=.45,color=MUTED);self.line(elbow,end,lw=.45,color=MUTED);self.text((end[0],end[1]+100),label,h=h,align=align)

def obj_layer(o):
 if o['kind'] in ['vitrine','pedestal']:return 'vitrine'
 if o['kind']=='open_shelf':return 'shelf'
 if o['kind']=='rack':return 'rack'
 if o['kind'] in ['sink','toilet']:return 'service'
 if o['zone']=='03':return 'vip'
 return 'furn'

def plan(g):
 s=Scene();s.poly(g['boundary_mm'],layer='floor',fill='#fcfbf8',lw=.45)
 tints={'01':'#fbf8f1','02':'#f4f0e6','03':'#eee6d8','04':'#eeeae3','05':'#f0ede6'}
 for z in g['zones']:
  for p in z['polygons_mm']:s.poly(p,layer='floor',fill=tints[z['id']],lw=0)
 for room in g['service_core']['rooms']:
  s.rect(room['bounds_mm'],layer='floor',fill='#f0efeb',lw=.2)
 # Calm, wide-joint flooring only in main gallery, light enough for legibility.
 for y in range(5500,14200,1200):s.line((2150,y),(8250,y),'floor',.18,'#d6d0c3')
 for x in range(2400,8250,1200):s.line((x,5500),(x,14200),'floor',.18,'#d6d0c3')
 for w in g['walls']:
  if w['z_mm'][0]!=0 or 'SILL' in w['id']:continue
  s.rect(w['bounds_mm'],layer='wall' if w['status']=='existing' else 'new',fill='#77736b' if w['status']=='existing' else '#bfb7a8',lw=.9)
 for win in g['glazing']:
  x,y,X,Y=win['bounds_mm'];vert=Y-y>X-x
  for a in [.2,.5,.8]:
   s.line((x+(X-x)*a,y),(x+(X-x)*a,Y),'glass',.55) if vert else s.line((x,y+(Y-y)*a),(X,y+(Y-y)*a),'glass',.55)
  n=math.ceil((Y-y if vert else X-x)/win['mullion_spacing_max_mm'])
  for i in range(n+1):
   v=i/n;s.line((x,y+(Y-y)*v),(X,y+(Y-y)*v),'glass',.6) if vert else s.line((x+(X-x)*v,y),(x+(X-x)*v,Y),'glass',.6)
 for o in sorted(g['fixtures'],key=lambda o:0 if o['kind']=='rug' else 1):
  x,y,X,Y=o['bounds_mm'];cx=(x+X)/2;cy=(y+Y)/2;k=o['kind'];layer=obj_layer(o)
  if k=='rug':
   s.rect([x,y,X,Y],layer=layer,fill='#d9cbb7',lw=.3)
   for xx in np.arange(x+50,X,90):s.line((xx,y+45),(xx,Y-45),layer,.16,'#c7b9a3')
   s.rect([x+40,y+40,X-40,Y-40],layer=layer,lw=.35,color='#a89679')
  elif k=='sofa':
   s.rect([x,y,X,Y],layer=layer,fill='#e8ddcb',lw=1)
   s.rect([x+80,Y-210,X-80,Y-60],layer=layer,fill='#f5eee1',lw=.6)
   s.rect([x+55,y+55,x+210,Y-55],layer=layer,fill='#f1e7d8',lw=.6);s.rect([X-210,y+55,X-55,Y-55],layer=layer,fill='#f1e7d8',lw=.6)
   for j in range(4):s.rect([x+230+j*(X-x-460)/4,y+80,x+230+(j+1)*(X-x-460)/4-25,Y-240],layer=layer,fill='#f5eee1',lw=.5)
  elif k in ['stool','task_chair','armchair','chair']:
   s.ellipse((cx,cy),X-x,Y-y,layer,fill='#eee3d3',lw=.8)
   if k!='stool':s.arc((cx,cy-30),(X-x)*.42,5,175,layer,.8)
  elif k=='toilet':
   s.rect([x,Y-180,X,Y],layer=layer,fill='white',lw=.5);s.ellipse((cx,y+240),(X-x)*.7,450,layer,fill='white',lw=.6);s.ellipse((cx,y+230),(X-x)*.45,300,layer,fill=None,lw=.4)
  elif k=='sink':
   s.rect([x,y,X,Y],layer=layer,fill='#e6e0d5');s.rect([x+65,y+100,X-65,Y-100],layer=layer,fill='white',lw=.5);s.ellipse((cx,cy),35,35,layer,fill=INK,lw=.3)
  elif k in ['vitrine','pedestal']:
   s.rect([x,y,X,Y],layer=layer,fill=GLASS,lw=.9,color='#806b49');s.rect([x+30,y+30,X-30,Y-30],layer=layer,lw=.45,color=BRONZE)
   if k=='vitrine':
    s.line((x+75,y+50),(x+75,Y-50),layer,1.1,'#c7ad6d')
    for v in [.28,.5,.72]:s.ellipse((cx,y+(Y-y)*v),110,110,layer,fill='#fcfbf3',lw=.4)
   else:s.poly([(cx-130,cy-90),(cx+80,cy-160),(cx+150,cy+90),(cx-70,cy+140)],layer,fill='#fbf9f0',lw=.5)
  elif k in ['open_shelf','rack']:
   s.rect([x,y,X,Y],layer=layer,fill='#dfd7c8',lw=.75)
   if k=='open_shelf':
    for yy in np.arange(y+100,Y-100,350):s.rect([x+80,yy,X-60,yy+230],layer=layer,fill='#bfad91',lw=.4)
   elif X-x>Y-y:
    for xx in np.arange(x+400,X,500):s.line((xx,y),(xx,Y),layer,.4)
   else:
    for yy in np.arange(y+400,Y,450):s.line((x,yy),(X,yy),layer,.4)
  else:
   s.rect([x,y,X,Y],layer=layer,fill='#ded2bc' if k in ['reception','discovery'] else '#e9e2d6',lw=.85)
   if k=='discovery':
    for xx in [x+220,x+860,x+1500]:
     s.rect([xx,y+250,xx+480,Y-250],layer=layer,fill='#eee9de',lw=.45)
     for tx in [xx+130,xx+330]:s.ellipse((tx,cy),95,95,layer,fill='#c4ac7d',lw=.4)
   if k=='reception':
    s.line((x+180,y+150),(X-180,y+150),layer,.45);s.rect([X-570,Y-300,X-180,Y-120],layer=layer,fill='#9a9180',lw=.4)
   if k=='desk':s.rect([x+450,y+220,x+1050,y+470],layer=layer,fill='#bdb4a5',lw=.45)
 for c in g['columns']:s.rect(c['bounds_mm'],layer='column',fill='#b4afa4',hatch='////',lw=1.05)
 for d in g['doors']:
  hx,hy=d['hinge_mm'];r=d['width_mm'];a=math.radians(d['leaf_open_deg']);s.line((hx,hy),(hx+r*math.cos(a),hy+r*math.sin(a)),'door',.85);s.arc((hx,hy),r,*d['arc_deg'])
 # Fixture tags stay away from detailed product symbols.
 for o in g['fixtures']:
  x,y,X,Y=o['bounds_mm'];k=o['kind'];cx=(x+X)/2;cy=(y+Y)/2
  if k=='vitrine':s.text((x-110,cy),o['id'],115,align='right',font='bold')
  elif k=='pedestal':s.text((cx,y-450),o['id'],115,font='bold')
  elif k=='open_shelf':s.text((X+150,cy),o['id'],115,align='left',font='bold')
  elif k=='rack':s.text((cx,cy),o['id'],100,font='mono',rotation=90 if X-x<Y-y else 0)
  elif k in ['reception','discovery','desk','packing_table']:s.text((cx,y-150 if k=='reception' else y+110 if k=='discovery' else cy),o['id'],120,font='bold')
 for id,xy,title,sub in [('01',(5100,7300),'01  RECEPTION','SCENT DISCOVERY'),('02',(5000,10800),'02  CRYSTAL GALLERY','SECURE + TACTILE DISPLAY'),('03',(4850,4250),'03  VIP SALON',''),('04',(5350,2770),'04  PRIVATE OFFICE',''),('05',(3150,900),'05  HIDDEN\nSTORE','')]:
  s.text(xy,title,160,font='title');
  if sub:s.text((xy[0],xy[1]-230),sub,105)
 for room in g['service_core']['rooms']:
  x,y,X,Y=room['bounds_mm'];name=room['id'].replace('-',' ');s.text((850,(y+Y)/2),name,110,font='bold')
 s.line((0,9350),(1599,10100),'service',.45,MUTED,True);s.line((1599,9350),(0,10100),'service',.45,MUTED,True)
 s.text((7300,4730),'ENTRY 1100',120,font='bold')
 s.line((3300,3750),(4400,4150),'text',.45,MUTED)
 # Original dimension strings are true, native CAD dimensions.
 s.dim((0,0),(6450,0),-620,h=155)
 s.dim((6450,0),(6450,4999),9600,axis='y',h=155)
 s.dim((8800,4999),(8800,14200),9600,axis='y',h=155)
 s.dim((1699,14200),(8800,14200),14920,h=155)
 s.dim((0,14200),(8800,14200),15400,h=125)
 s.dim((0,0),(0,14200),-1150,axis='y',h=130)
 for a,b in [(0,1699),(1699,2150),(2150,8250),(8250,8800)]:
  if b-a>1000:s.dim((a,14200),(b,14200),14500,h=105)
 for a,b in [(0,2100),(2100,5500),(5500,7450),(7450,9350),(9350,10100),(10100,12100),(12100,14200)]:s.dim((0,a),(0,b),-590,axis='y',h=105)
 for a,b in [(0,3800),(3800,6450)]:s.dim((a,0),(b,0),-260,h=115)
 s.dim((3800,0),(3800,2500),6640,axis='y',h=105)
 s.dim((3800,8200),(6200,8200),8050,h=105)
 s.dim((6200,8200),(6200,9300),6400,axis='y',h=105)
 s.dim((5400,6850),(7600,6850),7080,h=110)
 s.dim((5400,6100),(5400,6850),5160,axis='y',h=100)
 s.dim((500,5150),(3300,5150),5310,h=105)
 s.dim((4450,850),(6050,850),730,h=100)
 s.dim((4450,850),(4450,1600),4270,axis='y',h=100)
 s.dim((3075,11875),(3725,11875),11650,h=100)
 s.dim((3725,11875),(3725,12525),3890,axis='y',h=100)
 s.dim((1699,8000),(2119,8000),7800,h=95)
 s.dim((8300,5850),(8800,5850),5780,h=95)
 s.dim((3300,4200),(3300,5150),3480,axis='y',h=100)
 s.dim((1150,3000),(2650,3000),3200,h=95)
 s.dim((900,850),(2300,850),680,h=95)
 s.dim((2300,850),(2300,1450),2460,axis='y',h=95)
 # External leaders intentionally replace bubble callouts.
 for a,b,c,tx in [((6000,14200),(9300,14100),(10050,14100),'CONTINUOUS\nNORTH WINDOW'),((8800,13000),(9300,12900),(10050,12900),'V-05 / V-06\nFLAGSHIP DISPLAY'),((8250,9150),(9300,9400),(10050,9400),'LOCKABLE\nLOW-IRON GLASS'),((8800,11300),(9300,11500),(10050,11500),'COL-3\n450 x 700'),((6200,8750),(9200,8000),(10050,8000),'I-01\n2400 x 1100'),((7600,6450),(9300,6450),(10050,6450),'R-01\n2200 x 750'),((6450,2300),(9200,3100),(10050,3100),'ACOUSTIC\nGLASS FRONT')]:s.leader(a,b,c,tx,105)
 s.text((4200,15780),'FURNITURE + DISPLAY PLAN',205,font='title')
 s.text((4200,16080),'CRYSTAL / PERFUME BOUTIQUE',120)
 s.line((8200,-450),(8200,400),'text',.8);s.poly([(8200,500),(8080,200),(8320,200)],fill=INK);s.text((8200,760),'N',160,font='bold')
 s.text((1200,-1050),'0',100,font='mono');s.text((3200,-1050),'2 m',100,font='mono')
 for j in range(4):s.rect([1200+j*500,-1370,1700+j*500,-1260],fill=INK if j%2==0 else '#ffffff',lw=.5)
 s.text((6450,-1280),'DIMENSIONS IN mm',110,font='mono')
 return s

def render_scene(ax,s):
 ax.set_aspect('equal');ax.axis('off')
 scale=ax.get_position().width*ax.figure.get_figwidth()*72/(ax.get_xlim()[1]-ax.get_xlim()[0])
 for i in s.items:
  k=i['kind'];color=i.get('color',INK);lw=i.get('lw',.6)
  if k=='line':ax.plot([i['a'][0],i['b'][0]],[i['a'][1],i['b'][1]],color=color,lw=lw,ls=(0,(4,3)) if i.get('dash') else '-',solid_capstyle='butt')
  elif k=='poly':ax.add_patch(Polygon(i['p'],closed=True,facecolor=i['fill'] or 'none',edgecolor=color if lw else 'none',lw=lw,hatch=i.get('hatch'),linestyle='--' if i.get('dash') else '-'))
  elif k=='ellipse':ax.add_patch(Ellipse(i['c'],i['w'],i['h'],facecolor=i['fill'] or 'none',edgecolor=color,lw=lw))
  elif k=='arc':ax.add_patch(Arc(i['c'],2*i['r'],2*i['r'],theta1=i['a'],theta2=i['b'],color=color,lw=lw))
  elif k=='text':ax.text(*i['p'],i['s'],ha=i['align'],va='center',fontproperties=FONTS[i['font']],fontsize=i['h']*scale*1.25,rotation=i['rotation'],color=color,linespacing=1.35)
  elif k=='dim':
   a,b=i['a'],i['b'];off=i['offset'];hor=i['axis']=='x';h=i['h'];c=MUTED
   if hor:
    for p in [a,b]:ax.plot([p[0],p[0]],[p[1]+math.copysign(55,off-p[1]),off+math.copysign(60,off-p[1])],c=c,lw=.35)
    ax.plot([a[0],b[0]],[off,off],c=c,lw=.4)
    for x in [a[0],b[0]]:ax.plot([x-35,x+35],[off-50,off+50],c=c,lw=.65)
    ax.text((a[0]+b[0])/2,off+90,f'{abs(b[0]-a[0]):g}',ha='center',va='bottom',fontproperties=FONTS['mono'],fontsize=h*scale*1.15,color=INK,bbox=dict(facecolor='white',edgecolor='none',pad=.6))
   else:
    for p in [a,b]:ax.plot([p[0]+math.copysign(55,off-p[0]),off+math.copysign(60,off-p[0])],[p[1],p[1]],c=c,lw=.35)
    ax.plot([off,off],[a[1],b[1]],c=c,lw=.4)
    for y in [a[1],b[1]]:ax.plot([off-50,off+50],[y-35,y+35],c=c,lw=.65)
    ax.text(off-85,(a[1]+b[1])/2,f'{abs(b[1]-a[1]):g}',ha='right',va='center',rotation=90,fontproperties=FONTS['mono'],fontsize=h*scale*1.15,color=INK,bbox=dict(facecolor='white',edgecolor='none',pad=.6))

def save_scene(s,path,pixels,limits):
 w,h=pixels;fig=plt.figure(figsize=(w/200,h/200),dpi=200,facecolor='white');ax=fig.add_axes([.025,.025,.95,.95]);ax.set_xlim(*limits[0]);ax.set_ylim(*limits[1]);render_scene(ax,s);fig.savefig(path,dpi=200,facecolor='white');plt.close(fig)
