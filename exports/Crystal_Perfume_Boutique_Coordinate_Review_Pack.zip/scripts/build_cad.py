"""Emit native dimensions/text plus auditable 1:1 plan and elevations."""
import json,math
from pathlib import Path
from collections import Counter
import ezdxf
from ezdxf.enums import TextEntityAlignment
from drawing import ROOT,LAYERS,plan,save_scene
from elevations import elevation,elevations_sheet

def emit(m,s,dx=0,dy=0):
 def p(a):return (a[0]+dx,a[1]+dy)
 for i in s.items:
  k=i['kind'];attr={'layer':LAYERS[i['layer']]}
  if i.get('dash'):attr['linetype']='DASHED'
  if k=='line':m.add_line(p(i['a']),p(i['b']),dxfattribs=attr)
  elif k=='poly':
   pts=[p(q) for q in i['p']];m.add_lwpolyline(pts,close=True,dxfattribs=attr)
   if i.get('fill') and i['layer'] in ['wall','new','column']:
    h=m.add_hatch(dxfattribs=attr)
    if i.get('hatch'):h.set_pattern_fill('ANSI31',scale=30)
    else:h.set_solid_fill(color=8 if i['layer']=='wall' else 9)
    h.paths.add_polyline_path(pts,is_closed=True)
  elif k=='ellipse':
   w,h=i['w'],i['h'];major=(w/2,0,0) if w>=h else (0,h/2,0);m.add_ellipse(p(i['c']),major_axis=major,ratio=min(w,h)/max(w,h),dxfattribs=attr)
  elif k=='arc':m.add_arc(p(i['c']),i['r'],i['a'],i['b'],dxfattribs=attr)
  elif k=='text':
   lines=i['s'].split('\n')
   for j,tx in enumerate(lines):
    tx=tx.replace('→','>').replace('≥','>=').replace('×','x').replace('–','-')
    t=m.add_text(tx,dxfattribs={**attr,'height':i['h'],'rotation':i['rotation'],'style':'MONO' if i['font']=='mono' else 'TITLE' if i['font'] in ['title','bold'] else 'BODY'})
    xy=p(i['p']);t.set_placement((xy[0],xy[1]+((len(lines)-1)/2-j)*i['h']*1.35),align={'center':TextEntityAlignment.MIDDLE_CENTER,'left':TextEntityAlignment.MIDDLE_LEFT,'right':TextEntityAlignment.MIDDLE_RIGHT}[i['align']])
  elif k=='dim':
   hor=i['axis']=='x';a,b=p(i['a']),p(i['b']);base=(a[0],i['offset']+dy) if hor else (i['offset']+dx,a[1]);d=m.add_linear_dim(base=base,p1=a,p2=b,angle=0 if hor else 90,dimstyle='CRYSTAL-MM',override={'dimtxt':i['h']},dxfattribs=attr);d.render()

def build(g):
 d=ezdxf.new('R2010',setup=True);d.units=4
 d.header['$MEASUREMENT']=1;d.header['$LUNITS']=2;d.header['$LUPREC']=0
 for k,name in LAYERS.items():d.layers.new(name,dxfattribs={'color':7,'lineweight':35 if k in ['wall','column'] else 25 if k=='new' else 13})
 for name,font in [('BODY','IBMPlexSans-400.ttf'),('TITLE','SpaceGrotesk-600.ttf'),('MONO','JetBrainsMono-400.ttf')]:d.styles.new(name,dxfattribs={'font':font})
 d.dimstyles.new('CRYSTAL-MM',dxfattribs={'dimtxsty':'MONO','dimtxt':115,'dimasz':60,'dimexo':55,'dimexe':60,'dimgap':55,'dimdec':0,'dimtad':1,'dimclrd':7,'dimclre':7,'dimclrt':7})
 m=d.modelspace();p=plan(g);emit(m,p)
 for side,y in [('East',10000),('West',5000),('South',0)]:emit(m,elevation(g,side),15000,y)
 # Reflected lighting lines are toggleable and do not pollute the PNG plan.
 for lt in g['lighting']:
  a,b=lt['start_mm'],lt['end_mm'];m.add_line(a,b,dxfattribs={'layer':'A-LIGHT-TRACK','linetype':'DASHED'})
 d.set_modelspace_vport(height=18500,center=(5000,7000))
 path=ROOT/'exports/Crystal_Perfume_Boutique_99sqm.dxf';d.saveas(path);r=ezdxf.readfile(path);au=r.audit()
 report=dict(dxf_version=r.dxfversion,units=r.units,audit_errors=len(au.errors),audit_fixes=len(au.fixes),entities=dict(Counter(e.dxftype() for e in r.modelspace())),layers=[l.dxf.name for l in r.layers],plan_origin_mm=[0,0],elevation_origins_mm=dict(East=[15000,10000],West=[15000,5000],South=[15000,0]),native_dimensions=len(r.modelspace().query('DIMENSION')))
 assert not au.errors and not au.fixes,report
 (ROOT/'exports/cad_validation.json').write_text(json.dumps(report,indent=2)+'\n')
 save_scene(p,ROOT/'assets/cad_floorplan_99sqm.png',(2200,2800),((-1500,11700),(-1550,16500)))
 save_scene(elevations_sheet(g),ROOT/'assets/cad_elevations_vitrines.png',(2400,1500),((-800,15700),(-650,12300)))
 return report
if __name__=='__main__':print(json.dumps(build(json.loads((ROOT/'layout_geometry.json').read_text())),indent=2))
